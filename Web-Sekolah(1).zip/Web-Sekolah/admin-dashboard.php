<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
$user = require_role('admin');

// --- Proses form "Tambah Data" ---
$tambahMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['jenis_data'])) {
    $jenis = $_POST['jenis_data'];
    try {
        if ($jenis === 'siswa') {
            $stmt = $pdo->prepare('INSERT INTO siswa (nisn, nama, kelas, jk) VALUES (?, ?, ?, ?)');
            $stmt->execute([$_POST['nisn'], $_POST['nama'], $_POST['kelas'], $_POST['jk']]);
            $tambahMsg = 'Data siswa "' . $_POST['nama'] . '" berhasil ditambahkan.';
        } elseif ($jenis === 'guru') {
            $stmt = $pdo->prepare('INSERT INTO guru (nama, mapel, no_hp) VALUES (?, ?, ?)');
            $stmt->execute([$_POST['nama'], $_POST['mapel'], $_POST['no_hp']]);
            $tambahMsg = 'Data guru "' . $_POST['nama'] . '" berhasil ditambahkan.';
        } elseif ($jenis === 'ortu') {
            $stmt = $pdo->prepare('INSERT INTO orang_tua (siswa_id, nama, telepon) VALUES (?, ?, ?)');
            $stmt->execute([$_POST['siswa_id'], $_POST['nama'], $_POST['telepon']]);
            $tambahMsg = 'Data orang tua "' . $_POST['nama'] . '" berhasil ditambahkan.';
        } elseif ($jenis === 'kelas') {
            $stmt = $pdo->prepare('INSERT INTO kelas (nama_kelas, wali_kelas, jumlah_siswa) VALUES (?, ?, ?)');
            $stmt->execute([$_POST['nama_kelas'], $_POST['wali_kelas'], $_POST['jumlah_siswa']]);
            $tambahMsg = 'Data kelas "' . $_POST['nama_kelas'] . '" berhasil ditambahkan.';
        }
    } catch (PDOException $e) {
        $tambahMsg = 'Gagal menyimpan: ' . $e->getMessage();
    }
}

// --- Ambil data ringkasan untuk dashboard ---
$totalSiswa = (int) $pdo->query('SELECT COUNT(*) c FROM siswa')->fetch()['c'];
$totalGuru  = (int) $pdo->query('SELECT COUNT(*) c FROM guru')->fetch()['c'];

$hariIni = date('Y-m-d');
$rekap = $pdo->prepare("SELECT status, COUNT(*) c FROM absensi WHERE tanggal = ? GROUP BY status");
$rekap->execute([$hariIni]);
$rekapRows = $rekap->fetchAll();
$totalAbsenHariIni = array_sum(array_column($rekapRows, 'c'));
$hadirCount = 0;
foreach ($rekapRows as $r) { if ($r['status'] === 'Hadir') $hadirCount = (int)$r['c']; }
$persenHadirHariIni = $totalAbsenHariIni > 0 ? round($hadirCount / $totalAbsenHariIni * 100, 1) : 0;

$siswaList = $pdo->query('SELECT id, nama FROM siswa ORDER BY nama')->fetchAll();

$statusPct = ['Hadir' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0, 'Terlambat' => 0];
foreach ($rekapRows as $r) {
    if ($totalAbsenHariIni > 0) {
        $statusPct[$r['status']] = round($r['c'] / $totalAbsenHariIni * 100, 1);
    }
}
$cHadir = $statusPct['Hadir'];
$cIzin  = $cHadir + $statusPct['Izin'];
$cSakit = $cIzin + $statusPct['Sakit'];
$cAlpa  = $cSakit + $statusPct['Alpa'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Admin | SMK Infokom Bogor</title>
<meta name="description" content="Dashboard admin sekolah SMK Infokom Bogor (contoh tampilan).">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="admin-body">
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>

<aside class="admin-sidebar" aria-label="Navigasi admin">
  <a href="admin-dashboard.php" class="admin-sidebar-brand"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"><span>SMK Infokom<br>Admin</span></a>
  <div class="admin-sidebar-label">Workspace</div>
  <a href="admin-dashboard.php" class="active"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/></svg><span>Dashboard</span></a>
  <a href="admin-penerimaan.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 5h16v14H4zM4 7l8 6 8-6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Penerimaan</span></a>
  <a href="admin-kelola.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Kelola Konten</span></a>
  <a href="admin-absensi.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="15" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3v4m8-4v4M7 11h10M8 15h3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Absensi</span></a>
  <a href="admin-bkk.php"><svg viewBox="0 0 24 24" fill="none"><path d="M3 8h18v12H3zM7 8V5h10v3M8 13h8M8 16h5" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/></svg><span>BKK</span></a>
  <div class="admin-sidebar-label">Aplikasi</div>
  <a href="index.php"><svg viewBox="0 0 24 24" fill="none"><path d="m4 11 8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>Lihat Situs</span></a>
  <div class="admin-sidebar-footer"><a href="logout.php"><svg viewBox="0 0 24 24" fill="none"><path d="M10 5H5v14h5m5-4 4-3-4-3m4 3H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Keluar</span></a></div>
</aside>

<div class="dash-topbar">
  <div class="wrap">
    <a href="index.php" style="display:flex;align-items:center;gap:10px;font-family:'Libre Franklin',sans-serif;font-weight:700;font-size:14.5px;color:var(--navy);"><span class="brand-mark" style="width:32px;height:32px;font-size:13px;"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span> Dashboard Admin</a>
    <div class="dash-search"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M21 21l-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg><input type="text" id="dashboardSearch" placeholder="Cari aktivitas atau informasi..." aria-label="Cari di dashboard"></div>
    <div style="display:flex;align-items:center;gap:16px;"><a href="admin-kelola.php" style="font-size:13px;color:var(--muted);font-weight:600;">Kelola Konten</a><a href="index.php" style="font-size:13px;color:var(--muted);font-weight:600;">Kembali ke Situs</a><a href="logout.php" style="font-size:13px;color:var(--muted);font-weight:600;">Keluar</a><div class="dash-avatar"><?= h(strtoupper(substr($user['nama'],0,2))) ?></div></div>
  </div>
</div>

<div class="dash-wrap">
  <div class="wrap">
    <div class="horizon-toolbar">
      <button class="admin-mobile-toggle" id="adminMobileToggle" type="button" aria-label="Buka menu admin" aria-expanded="false"><span></span><span></span><span></span></button>
      <div class="dash-search">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M21 21l-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
        <input type="text" id="dashboardSearch" placeholder="Cari data siswa, guru, atau absensi" aria-label="Cari data sekolah">
      </div>
      <div class="horizon-profile"><button type="button" class="notification-btn" aria-label="Notifikasi"><svg viewBox="0 0 24 24" fill="none"><path d="M18 9a6 6 0 00-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></button><div class="dash-avatar"><?= h(strtoupper(substr($user['nama'],0,2))) ?></div><div><strong><?= h($user['nama']) ?></strong><small>Admin</small></div><span class="profile-chevron">⌄</span></div>
    </div>
    <div class="horizon-welcome"><div><span class="horizon-kicker">SMK Infokom Bogor / Dashboard</span><h1>Selamat datang, <?= h($user['nama']) ?></h1><p>Pantau aktivitas sekolah dan kehadiran siswa hari ini.</p></div><button class="btn btn-gold" type="button" onclick="bukaTambahData()">+ Tambah data</button></div>
    <div class="horizon-stat-grid">
      <section class="horizon-card results-card"><div class="horizon-card-head"><div><span class="horizon-label">Ringkasan sekolah</span><h3>Data sekolah saat ini</h3></div><a href="admin-kelola.php">Kelola data <span>→</span></a></div><div class="result-grid"><div><span>Siswa aktif</span><strong><?= number_format($totalSiswa, 0, ',', '.') ?></strong><em class="positive">↗ Terdata</em></div><div><span>Guru &amp; staf</span><strong><?= number_format($totalGuru, 0, ',', '.') ?></strong><em class="positive">↗ Aktif</em></div><div><span>Kehadiran hari ini</span><strong><?= h((string)$persenHadirHariIni) ?>%</strong><em class="positive">↗ Hadir</em></div><div><span>Total presensi</span><strong><?= number_format($totalAbsenHariIni, 0, ',', '.') ?></strong><em class="positive">↗ Hari ini</em></div></div></section>
      <section class="horizon-card chart-card"><div class="horizon-card-head"><div><span class="horizon-label">Last 7 days</span><h3>Delivery time</h3></div><button class="chart-menu" type="button" aria-label="Opsi grafik">•••</button></div><div class="delivery-chart"><div class="chart-tooltip">7h, 25 min</div><svg viewBox="0 0 520 170" preserveAspectRatio="none" aria-label="Grafik waktu pengiriman"><defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="#C9A227" stop-opacity=".28"/><stop offset="1" stop-color="#C9A227" stop-opacity="0"/></linearGradient></defs><path class="chart-area" d="M0 136 C35 130 42 106 78 112 S124 134 155 102 S204 40 235 72 S278 113 312 82 S355 43 385 61 S431 112 463 65 S493 35 520 44 V170 H0Z"/><path class="chart-line" d="M0 136 C35 130 42 106 78 112 S124 134 155 102 S204 40 235 72 S278 113 312 82 S355 43 385 61 S431 112 463 65 S493 35 520 44"/><circle cx="463" cy="65" r="5" class="chart-point"/></svg><div class="chart-days"><span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span></div></div></section>
    </div>
    <section class="orders-panel" id="orders"><div class="orders-heading"><div><span class="horizon-label">Delivery management</span><h2>Orders</h2></div><div class="order-tabs"><button type="button">Pending <b>14</b></button><button type="button">Responded <b>8</b></button><button type="button" class="active">Assigned <b>4</b></button><button type="button">Completed <b>93</b></button></div></div><div class="orders-scroll"><table class="horizon-orders"><thead><tr><th>Order ID</th><th>Order assigned to</th><th>Pickup address</th><th>Delivery address</th><th>Expire at</th><th>Status</th><th>Action</th></tr></thead><tbody><tr><td class="order-id">#783456901</td><td><span class="order-person"><i>MS</i>Mia Sanchez</span></td><td>🇪🇸 Madrid, ES</td><td>🇵🇹 Lisbon, PT</td><td>08 May, 2025</td><td><span class="order-status picked"><b></b>Picked up</span></td><td><div class="order-actions"><button type="button">See more</button><button type="button" aria-label="Opsi pesanan">•••</button></div></td></tr><tr><td class="order-id">#902348776</td><td><span class="order-person"><i>JB</i>John Becker</span></td><td>🇺🇸 New York, US</td><td>🇨🇦 Toronto, CA</td><td>29 Jun, 2025</td><td><span class="order-status transit"><b></b>In transit</span></td><td><div class="order-actions"><button type="button">See more</button><button type="button" aria-label="Opsi pesanan">•••</button></div></td></tr><tr><td class="order-id">#663409823</td><td><span class="order-person"><i>SD</i>Sophie Dubois</span></td><td>🇫🇷 Marseille, FR</td><td>🇩🇪 Hamburg, DE</td><td>01 Jul, 2025</td><td><span class="order-status picked"><b></b>Picked up</span></td><td><div class="order-actions"><button type="button">See more</button><button type="button" aria-label="Opsi pesanan">•••</button></div></td></tr><tr><td class="order-id">#384756299</td><td><span class="order-person"><i>AK</i>Ahmed Khan</span></td><td>🇮🇹 Milan, IT</td><td>🇯🇵 Tokyo, JP</td><td>16 May, 2025</td><td><span class="order-status transit"><b></b>In transit</span></td><td><div class="order-actions"><button type="button">See more</button><button type="button" aria-label="Opsi pesanan">•••</button></div></td></tr></tbody></table></div></section>
    <div class="dash-head">
      <div>
        <h2>Selamat datang kembali, <?= h($user['nama']) ?></h2>
        <p>Berikut ringkasan aktivitas sekolah hari ini, <?= date('d F Y') ?>.</p>
      </div>
      <div style="display:flex;gap:12px;">
        <a href="admin-absensi.php" class="btn btn-gold" style="padding:11px 20px;">Kelola Absensi</a>
      </div>
    </div>

    <div class="stat-card-row reveal" data-stagger>
      <div class="stat-card dashboard-item" data-search="siswa aktif jumlah siswa">
        <div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M8 21h8M12 17v4M6 4h12l-1 8a5 5 0 01-10 0L6 4z" stroke="#1B6B6B" stroke-width="1.6" stroke-linejoin="round"/></svg></div>
        <b><?= number_format($totalSiswa, 0, ',', '.') ?></b><span>Siswa Aktif</span>
      </div>
      <div class="stat-card dashboard-item" data-search="guru staf jumlah guru">
        <div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="9" cy="8" r="3.2" stroke="#C9832A" stroke-width="1.6"/><path d="M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6" stroke="#C9832A" stroke-width="1.6" stroke-linecap="round"/><circle cx="17" cy="9" r="2.6" stroke="#C9832A" stroke-width="1.6"/></svg></div>
        <b><?= number_format($totalGuru, 0, ',', '.') ?></b><span>Guru &amp; Staff</span>
      </div>
      <div class="stat-card dashboard-item" data-search="kehadiran hari ini presensi">
        <div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4 10-10" stroke="#1B6B6B" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
        <b><?= h((string)$persenHadirHariIni) ?>%</b><span>Kehadiran Hari Ini</span>
      </div>
      <div class="stat-card dashboard-item" data-search="prestasi tahun ini">
        <div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 2l3 7 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z" stroke="#C9832A" stroke-width="1.6" stroke-linejoin="round"/></svg></div>
        <b>4</b><span>Prestasi Tahun Ini</span>
      </div>
    </div>

    <div class="dash-grid">
      <div>
        <div class="dash-panel reveal dashboard-item" data-search="perkembangan akademik nilai kehadiran siswa">
          <h4>Perkembangan Akademik <span style="float:right;font-size:12px;color:var(--muted);font-weight:400;">Rata-rata nilai &amp; kehadiran siswa</span></h4>
          <div class="ap-bars" style="height:160px;">
            <div class="ap-bar" style="height:78%;"><span>Feb</span></div>
            <div class="ap-bar" style="height:82%;"><span>Mar</span></div>
            <div class="ap-bar" style="height:75%;"><span>Apr</span></div>
            <div class="ap-bar" style="height:88%;"><span>Mei</span></div>
            <div class="ap-bar" style="height:91%;"><span>Jun</span></div>
            <div class="ap-bar" style="height:85%;"><span>Jul</span></div>
            <div class="ap-bar" style="height:94%;"><span>Agu</span></div>
          </div>
        </div>
        <div class="dash-panel reveal dashboard-item" data-search="aktivitas terbaru pembelajaran absensi berita nilai">
          <h4>Aktivitas Terbaru</h4>
          <div class="activity-item"><span class="dot2"></span><div><strong>Rina Amelia</strong> menambahkan pembelajaran baru di RPP Pemrograman Web <br><span style="color:var(--muted);font-size:12px;">5 menit lalu</span></div></div>
          <div class="activity-item"><span class="dot2"></span><div><strong>Cahyadi Rozi</strong> memperbarui data absensi kelas XI TKJ 1 <br><span style="color:var(--muted);font-size:12px;">28 menit lalu</span></div></div>
          <div class="activity-item"><span class="dot2"></span><div><strong>Admin Sekolah</strong> menambahkan berita baru "Upacara Peringatan Hari Pendidikan" <br><span style="color:var(--muted);font-size:12px;">1 jam lalu</span></div></div>
          <div class="activity-item"><span class="dot2"></span><div><strong>Muhammad Ibnu Arif</strong> mengunggah nilai praktik DKV kelas XII <br><span style="color:var(--muted);font-size:12px;">2 jam lalu</span></div></div>
        </div>
      </div>
      <div>
        <div class="dash-panel reveal dashboard-item" data-search="kehadiran hari ini hadir izin sakit alpa terlambat">
          <h4>Kehadiran Hari Ini</h4>
          <div class="donut" style="background:conic-gradient(#1B6B6B 0% <?= $cHadir ?>%, #C9832A <?= $cHadir ?>% <?= $cIzin ?>%, #A6192E <?= $cIzin ?>% <?= $cSakit ?>%, #8C1526 <?= $cSakit ?>% <?= $cAlpa ?>%, #E6E9ED <?= $cAlpa ?>% 100%);"></div>
          <div class="donut-legend">
            <div><span class="dot" style="background:#1B6B6B;"></span> Hadir <strong style="margin-left:auto;"><?= $statusPct['Hadir'] ?>%</strong></div>
            <div><span class="dot" style="background:#C9832A;"></span> Izin <strong style="margin-left:auto;"><?= $statusPct['Izin'] ?>%</strong></div>
            <div><span class="dot" style="background:#A6192E;"></span> Sakit <strong style="margin-left:auto;"><?= $statusPct['Sakit'] ?>%</strong></div>
            <div><span class="dot" style="background:#8C1526;"></span> Alpa <strong style="margin-left:auto;"><?= $statusPct['Alpa'] ?>%</strong></div>
          </div>
        </div>
        <div class="dash-panel reveal dashboard-item" data-search="jadwal hari ini upacara rapat praktik kelas">
          <h4>Jadwal Hari Ini</h4>
          <div class="activity-item"><span class="dot2" style="background:var(--gold);"></span><div>07.00 — Upacara Bendera<br><span style="color:var(--muted);font-size:12px;">Seluruh siswa &amp; guru</span></div></div>
          <div class="activity-item"><span class="dot2" style="background:var(--gold);"></span><div>09.30 — Rapat Koordinasi Kaprog<br><span style="color:var(--muted);font-size:12px;">Ruang Rapat Utama</span></div></div>
          <div class="activity-item"><span class="dot2" style="background:var(--gold);"></span><div>13.00 — Uji Praktik Kelas XII RPL<br><span style="color:var(--muted);font-size:12px;">Lab Komputer 2</span></div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal-overlay admin-add-modal<?= $tambahMsg ? ' open' : '' ?>" id="tambahDataModal" role="dialog" aria-modal="true" aria-labelledby="tambahDataTitle">
  <div class="modal-box">
    <button class="modal-close" type="button" aria-label="Tutup dialog" onclick="tutupTambahData()">&times;</button>
    <h4 id="tambahDataTitle">Tambah Data Sekolah</h4>
    <p>Pilih jenis data, isi formnya, lalu simpan &mdash; data akan langsung tersimpan ke database.</p>
    <div class="modal-options">
      <button type="button" class="modal-opt" onclick="pilihTambahData('siswa', this)"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" style="margin:0 auto;"><path d="M8 21h8M12 17v4M6 4h12l-1 8a5 5 0 01-10 0L6 4z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg><span>Data Siswa</span></button>
      <button type="button" class="modal-opt" onclick="pilihTambahData('guru', this)"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" style="margin:0 auto;"><circle cx="12" cy="8" r="3.2" stroke="currentColor" stroke-width="1.6"/><path d="M5 20c0-3.5 3-6 7-6s7 2.5 7 6" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg><span>Data Guru</span></button>
      <button type="button" class="modal-opt" onclick="pilihTambahData('ortu', this)"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" style="margin:0 auto;"><path d="M12 21s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z" stroke="currentColor" stroke-width="1.6"/></svg><span>Data Orang Tua</span></button>
      <button type="button" class="modal-opt" onclick="pilihTambahData('kelas', this)"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" style="margin:0 auto;"><rect x="4" y="4" width="16" height="16" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M8 9h8M8 13h5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg><span>Data Kelas</span></button>
    </div>

    <?php if ($tambahMsg): ?>
      <p style="margin-top:16px;margin-bottom:0;font-size:13px;color:#1B6B6B;font-weight:600;"><?= h($tambahMsg) ?></p>
    <?php endif; ?>

    <form method="post" style="margin-top:18px;">
      <input type="hidden" name="jenis_data" id="jenisDataInput" value="">

      <div class="form-grid tambah-fields" data-for="siswa" style="display:none;">
        <div class="form-field"><label>NISN</label><input type="text" name="nisn"></div>
        <div class="form-field"><label>Nama Siswa</label><input type="text" name="nama"></div>
        <div class="form-field"><label>Kelas</label><input type="text" name="kelas" placeholder="Contoh: X RPL 1"></div>
        <div class="form-field"><label>Jenis Kelamin</label>
          <select name="jk"><option value="Laki-laki">Laki-laki</option><option value="Perempuan">Perempuan</option></select>
        </div>
      </div>

      <div class="form-grid tambah-fields" data-for="guru" style="display:none;">
        <div class="form-field"><label>Nama Guru</label><input type="text" name="nama"></div>
        <div class="form-field"><label>Mata Pelajaran</label><input type="text" name="mapel"></div>
        <div class="form-field"><label>No. HP</label><input type="text" name="no_hp"></div>
      </div>

      <div class="form-grid tambah-fields" data-for="ortu" style="display:none;">
        <div class="form-field"><label>Nama Orang Tua</label><input type="text" name="nama"></div>
        <div class="form-field"><label>No. Telepon</label><input type="text" name="telepon"></div>
        <div class="form-field full"><label>Siswa (Anak)</label>
          <select name="siswa_id">
            <?php foreach ($siswaList as $s): ?>
              <option value="<?= (int)$s['id'] ?>"><?= h($s['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="form-grid tambah-fields" data-for="kelas" style="display:none;">
        <div class="form-field"><label>Nama Kelas</label><input type="text" name="nama_kelas" placeholder="Contoh: X RPL 3"></div>
        <div class="form-field"><label>Wali Kelas</label><input type="text" name="wali_kelas"></div>
        <div class="form-field"><label>Jumlah Siswa</label><input type="number" name="jumlah_siswa" value="0"></div>
      </div>

      <button type="submit" class="btn btn-navy" id="tambahSubmitBtn" style="margin-top:14px;display:none;">Simpan Data</button>
    </form>
  </div>
</div>
<script>
function bukaTambahData(){
  document.getElementById('tambahDataModal').classList.add('open');
  document.querySelector('.admin-add-modal .modal-opt')?.focus();
}
function tutupTambahData(){
  document.getElementById('tambahDataModal').classList.remove('open');
}
function pilihTambahData(jenis, el){
  document.querySelectorAll('.modal-opt').forEach(function(o){ o.classList.remove('selected'); o.setAttribute('aria-pressed', 'false'); });
  el.classList.add('selected');
  el.setAttribute('aria-pressed', 'true');
  document.getElementById('jenisDataInput').value = jenis;
  document.querySelectorAll('.tambah-fields').forEach(function(f){
    f.style.display = (f.dataset.for === jenis) ? 'grid' : 'none';
  });
  document.getElementById('tambahSubmitBtn').style.display = 'inline-flex';
}
document.querySelector('.admin-add-modal')?.addEventListener('click', function(event){
  if (event.target === this) tutupTambahData();
});
document.addEventListener('keydown', function(event){
  if (event.key === 'Escape') tutupTambahData();
});
document.getElementById('dashboardSearch')?.addEventListener('input', function(){
  const query = this.value.trim().toLowerCase();
  document.querySelectorAll('.dashboard-item').forEach(function(item){
    const matches = !query || item.dataset.search.includes(query);
    item.classList.toggle('search-hidden', !matches);
  });
});
</script>

<script src="assets/main.js"></script>
</body>
</html>
