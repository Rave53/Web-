<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/videos.php';
if (!function_exists('h')) {
    function h(?string $value): string
    {
        return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
    }
}
$japanGalleryItems = $pdo->query("SELECT title, description, item_type, image_path, video_path, youtube_id FROM japan_gallery WHERE status = 'aktif' ORDER BY created_at DESC, id DESC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Magang Jepang | SMK Infokom Bogor</title>
<meta name="description" content="Informasi program Magang Jepang SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="magang-jepang-page">
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility"><div class="wrap"><a href="profil.php">Kunjungi Kami</a><a href="ppdb.php">Daftar PPDB</a><a href="portal.php">Portal Siswa &amp; Orang Tua</a></div></div>
<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand"><span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span><span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span></a>
    <div class="nav-links">
      <a href="profil.php" class="nav-link">Profil</a>
      <a href="guru.php" class="nav-link">Guru</a>
      <a href="akademik.php" class="nav-link">Akademik</a>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta"><a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a><a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a><button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button></div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div><a href="profil.php">Profil &amp; Sejarah</a><a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  <div class="m-group">Akademik</div><a href="akademik.php">Program Keahlian</a><a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  <div class="m-group">Lainnya</div><a href="ppdb.php">PPDB</a><a href="info.php">Info &amp; Berita</a><a href="kontak.php">Kontak</a>
</div>
<header class="page-hero page-hero-centered">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / <a href="bkk.php">BKK</a> / Program Magang Jepang</div>
    <h1 class="split">Program Magang Jepang</h1>
    <p>Informasi persiapan dan pendampingan program pengalaman kerja di Jepang.</p>
  </div>
</header>
<main>
  <section class="explore">
    <div class="wrap">
      <div class="japan-section-heading reveal">
        <div class="eyebrow" style="justify-content:center;">Program BKK</div>
        <h2 class="split">Persiapan program dilakukan bertahap</h2>
        <p style="margin:14px auto 0;color:var(--muted);font-size:15px;">Informasi kuota, persyaratan, mitra, jadwal, dan biaya akan dikonfirmasi oleh sekolah saat program dibuka.</p>
      </div>
      <div class="portal-grid reveal" data-stagger>
        <article class="mock-card"><h3 style="font-size:16px;">Pembekalan</h3><p style="margin-top:10px;font-size:14px;line-height:1.7;">Persiapan bahasa, budaya, keselamatan, dan kebiasaan kerja sebelum keberangkatan.</p></article>
        <article class="mock-card"><h3 style="font-size:16px;">Seleksi dan administrasi</h3><p style="margin-top:10px;font-size:14px;line-height:1.7;">Tahapan dan dokumen mengikuti ketentuan resmi program serta mitra yang bekerja sama dengan sekolah.</p></article>
        <article class="mock-card"><h3 style="font-size:16px;">Pendampingan</h3><p style="margin-top:10px;font-size:14px;line-height:1.7;">Peserta memperoleh informasi kontak dan arahan pendampingan dari sekolah sebelum mengikuti program.</p></article>
      </div>
      <section class="japan-gallery" aria-labelledby="japan-gallery-title">
        <div class="japan-section-heading reveal">
          <div class="eyebrow" style="justify-content:center;">Cerita dan kegiatan</div>
          <h2 id="japan-gallery-title">Galeri Magang Jepang</h2>
          <p>Dokumentasi peserta dan kegiatan persiapan program.</p>
        </div>
        <div class="japan-photo-grid">
          <figure class="japan-photo-card reveal">
            <img src="<?= site_media_html('assets/img/Jepang2.jpeg') ?>" alt="Peserta program Magang Jepang di bandara" loading="lazy">
            <figcaption>Pengalaman peserta program di Jepang</figcaption>
          </figure>
          <figure class="japan-photo-card reveal">
            <img src="<?= site_media_html('assets/Aktivitas/Kunjungan jepun.jpeg') ?>" alt="Siswa mengikuti kegiatan bersama" loading="lazy">
            <figcaption>Kegiatan dan kebersamaan peserta</figcaption>
          </figure>
          <figure class="japan-photo-card reveal">
            <img src="<?= site_media_html('assets/img/Jepang1.jpeg') ?>" alt="Cerita inspiratif peserta yang mengikuti program magang di Jepang" loading="lazy">
            <figcaption>Cerita inspiratif peserta Magang Jepang</figcaption>
          </figure>
          <?php foreach ($japanGalleryItems as $item): ?>
            <?php if ($item['item_type'] !== 'image' || !is_string($item['image_path']) || !preg_match('~^uploads/japan-gallery/[a-f0-9]{32}\.(?:jpg|png|webp)$~', $item['image_path'])) { continue; } ?>
            <figure class="japan-photo-card reveal">
              <img src="<?= h($item['image_path']) ?>" alt="<?= h($item['title']) ?>" loading="lazy">
              <figcaption><?= h($item['title']) ?><?= $item['description'] ? ' — ' . h($item['description']) : '' ?></figcaption>
            </figure>
          <?php endforeach; ?>
        </div>
      </section>
      <?php
      $managedVideoItems = array_values(array_filter($japanGalleryItems, static fn(array $item): bool => in_array($item['item_type'], ['upload', 'youtube', 'text'], true)));
      ?>
      <?php if ($managedVideoItems): ?>
      <section class="japan-videos" aria-labelledby="japan-gallery-videos-title">
        <div class="japan-section-heading reveal">
          <div class="eyebrow" style="justify-content:center;">Konten dari panel admin</div>
          <h2 id="japan-gallery-videos-title">Video dan Cerita Peserta</h2>
          <p>Video dan teks yang dikelola melalui Galeri Magang Jepang.</p>
        </div>
        <div class="japan-video-grid">
          <?php foreach ($managedVideoItems as $item): ?>
            <?php
            $youtubeId = $item['item_type'] === 'youtube'
                ? video_youtube_id('https://youtu.be/' . (string) $item['youtube_id'])
                : null;
            $videoPath = is_string($item['video_path']) && preg_match('~^uploads/videos/[a-f0-9]{32}\.(?:mp4|webm|ogv)$~', $item['video_path'])
                ? $item['video_path']
                : null;
            if (($item['item_type'] === 'youtube' && $youtubeId === null) || ($item['item_type'] === 'upload' && $videoPath === null)) {
                continue;
            }
            ?>
            <article class="japan-video-card reveal">
              <?php if ($item['item_type'] === 'youtube' || $item['item_type'] === 'upload'): ?>
                <div class="japan-video-player">
                  <?php if ($item['item_type'] === 'youtube'): ?>
                    <iframe src="https://www.youtube-nocookie.com/embed/<?= h($youtubeId) ?>" title="<?= h($item['title']) ?>" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                  <?php else: ?>
                    <video controls preload="metadata">
                      <source src="<?= h($videoPath) ?>" type="<?= str_ends_with($videoPath, '.webm') ? 'video/webm' : (str_ends_with($videoPath, '.ogv') ? 'video/ogg' : 'video/mp4') ?>">
                      Browser Anda tidak mendukung pemutar video.
                    </video>
                  <?php endif; ?>
                </div>
              <?php endif; ?>
              <div class="japan-video-copy">
                <h3><?= h($item['title']) ?></h3>
                <?php if (!empty($item['description'])): ?><p><?= nl2br(h($item['description'])) ?></p><?php endif; ?>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      </section>
      <?php endif; ?>
      <div class="reveal" style="margin-top:32px;text-align:center;"><a href="kontak.php" class="btn btn-navy">Hubungi Sekolah</a></div>
    </div>
  </section>
</main>
<footer class="footer"><div class="wrap"><div class="foot-top"><div class="foot-logo"><div class="brand"><span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span><span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span></div><p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p></div><a href="kontak.php" class="btn btn-line">Kontak Kami</a></div><div class="foot-sub"><span>&copy; SMK Infokom Bogor</span><a href="ketentuan.php">Ketentuan</a><a href="privasi.php">Privasi</a></div></div></footer>
<script src="assets/main.js"></script>
</body>
</html>
