<?php
require_once __DIR__ . '/includes/media.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Praktik Kerja Lapangan (PKL) | SMK Infokom Bogor</title>
<meta name="description" content="Informasi Praktik Kerja Lapangan (PKL) bagi siswa SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Tentang Kami</a>
    <a href="ppdb.php">Pendaftaran PPDB</a>
    <a href="portal.php">Portal Siswa dan Orang Tua</a>
  </div>
</div>
<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika dan Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil dan Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi dan Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer dan Jaringan</a>
            <a href="akademik.php">Desain Komunikasi Visual</a>
            <a href="akademik.php">Produksi dan Siaran Program Televisi</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas dan Laboratorium</a>
            <a href="portal.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info dan Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil dan Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi dan Misi</a>
  <a href="guru.php">Guru dan Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  <a href="karier.php">Karier dan Kerja Sama Industri</a>
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info dan Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / Praktik Kerja Lapangan (PKL)</div>
    <h1 class="split">Praktik Kerja Lapangan (PKL)</h1>
    <p>Pengalaman belajar di lingkungan kerja untuk menerapkan kompetensi keahlian dan mempersiapkan siswa SMK Infokom Bogor memasuki dunia profesional.</p>
  </div>
</header>
<main>
  <section class="explore">
    <div class="wrap">
      <div class="section-head reveal pkl-intro-head">
        <div class="eyebrow" style="justify-content:center;">Belajar melalui pengalaman</div>
        <h2 class="split">Menerapkan pembelajaran dalam lingkungan kerja</h2>
        <p>PKL membantu siswa mengembangkan keterampilan, portofolio, kedisiplinan, dan pemahaman terhadap budaya kerja melalui pengalaman praktik yang relevan dengan kompetensi keahlian.</p>
      </div>
      <div class="portal-grid reveal" data-stagger>
        <article class="mock-card">
          <h3 style="font-size:16px;">Persiapan siswa</h3>
          <p style="margin-top:10px;font-size:14px;line-height:1.7;">Siswa mempersiapkan kompetensi keahlian, portofolio, komunikasi, dan sikap profesional sebelum menjalani kegiatan praktik.</p>
        </article>
        <article class="mock-card">
          <h3 style="font-size:16px;">Pengalaman praktik</h3>
          <p style="margin-top:10px;font-size:14px;line-height:1.7;">Kegiatan PKL memberi kesempatan untuk menerapkan pengetahuan sekolah dan mengenal proses kerja yang sesuai dengan bidang keahlian.</p>
        </article>
        <article class="mock-card">
          <h3 style="font-size:16px;">Pendampingan dan evaluasi</h3>
          <p style="margin-top:10px;font-size:14px;line-height:1.7;">Pelaksanaan dan evaluasi dilakukan melalui koordinasi sekolah dengan pihak terkait agar pengalaman praktik mendukung perkembangan kompetensi siswa.</p>
        </article>
      </div>
      <div class="reveal" style="margin-top:32px;text-align:center;">
        <p style="margin:0 auto 18px;max-width:700px;color:var(--muted);font-size:14px;line-height:1.7;">Persyaratan, jadwal, penempatan, dan mitra mengikuti informasi resmi sekolah sesuai program yang berjalan. Silakan hubungi sekolah untuk memperoleh informasi terbaru.</p>
        <a href="kontak.php" class="btn btn-navy">Hubungi Sekolah</a>
      </div>
    </div>
  </section>
</main>
<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika dan Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami</a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita dan Kabar</a></li><li><a href="info-darurat.php">Informasi Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
