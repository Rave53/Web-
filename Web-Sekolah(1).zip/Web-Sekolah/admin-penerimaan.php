<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/requests.php';
$user = require_role('admin');

$flash = $_SESSION['penerimaan_flash'] ?? null;
unset($_SESSION['penerimaan_flash']);
$tables = [
    'ppdb' => ['table' => 'ppdb_pendaftar', 'label' => 'Pendaftaran PPDB'],
    'kontak' => ['table' => 'pesan_kontak', 'label' => 'Pesan Kontak'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        request_verify_csrf();
        $type = $_POST['type'] ?? '';
        $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);
        $status = $_POST['status'] ?? '';
        if (!isset($tables[$type]) || !$id || $id < 1) {
            throw new RuntimeException('Data yang dipilih tidak valid.');
        }
        if (!in_array($status, ['Diterima', 'Ditolak'], true)) {
            throw new RuntimeException('Pilih status diterima atau ditolak.');
        }

        $table = $tables[$type]['table'];
        $exists = $pdo->prepare("SELECT id FROM `$table` WHERE id = ?");
        $exists->execute([$id]);
        if (!$exists->fetch()) {
            throw new RuntimeException('Data tidak ditemukan.');
        }
        $update = $pdo->prepare("UPDATE `$table` SET status = ? WHERE id = ?");
        $update->execute([$status, $id]);
        $_SESSION['penerimaan_flash'] = ['type' => 'success', 'text' => $tables[$type]['label'] . ' berhasil diperbarui menjadi ' . $status . '.'];
    } catch (RuntimeException $e) {
        $_SESSION['penerimaan_flash'] = ['type' => 'error', 'text' => $e->getMessage()];
    }

    header('Location: admin-penerimaan.php');
    exit;
}

$pendaftar = $pdo->query('SELECT * FROM ppdb_pendaftar ORDER BY created_at DESC LIMIT 200')->fetchAll();
$pesanKontak = $pdo->query('SELECT * FROM pesan_kontak ORDER BY created_at DESC LIMIT 200')->fetchAll();
$menunggu = count(array_filter($pendaftar, static fn($row) => $row['status'] === 'Menunggu Verifikasi'))
    + count(array_filter($pesanKontak, static fn($row) => $row['status'] === 'Menunggu Verifikasi'));
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Penerimaan PPDB &amp; Pesan | Admin SMK Infokom Bogor</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<style>
.request-panel{margin-bottom:28px;background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:24px;box-shadow:var(--shadow);}
.request-panel h2{margin-bottom:18px;font-size:20px;color:var(--navy);}
.request-table-wrap{overflow-x:auto;}
.request-table{width:100%;border-collapse:collapse;font-size:13px;}
.request-table th,.request-table td{padding:12px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;}
.request-table th{background:var(--sky);color:var(--navy);white-space:nowrap;}
.request-table td{color:var(--ink);}
.request-table details{min-width:190px;max-width:360px;}
.request-table details summary{cursor:pointer;color:var(--navy);font-weight:700;}
.request-table details p{margin-top:8px;white-space:pre-wrap;overflow-wrap:anywhere;}
.request-actions{display:flex;gap:7px;min-width:200px;}
.request-actions form{display:inline-flex;}
.request-actions button{border:0;border-radius:7px;padding:8px 10px;font:600 12px Inter,sans-serif;cursor:pointer;}
.request-actions .accept{background:#E1F3EE;color:#1B6B6B;}
.request-actions .reject{background:#FDEBEC;color:var(--crimson);}
.request-status{display:inline-block;padding:5px 9px;border-radius:12px;background:#FDF3DC;color:#9A6814;font-size:11px;font-weight:700;white-space:nowrap;}
.request-status.accepted{background:#E1F3EE;color:#1B6B6B;}
.request-status.rejected{background:#FDEBEC;color:var(--crimson);}
.request-flash{margin-bottom:20px;padding:13px 16px;border-radius:8px;font-weight:600;font-size:13px;}
.request-flash.success{background:#E1F3EE;color:#1B6B6B;}
.request-flash.error{background:#FDEBEC;color:var(--crimson);}
.request-count{margin:0 0 20px;color:var(--muted);font-size:14px;}
@media(max-width:700px){.request-panel{padding:16px;}.request-table{min-width:760px;}}
</style>
</head>
<body class="admin-body">
<aside class="admin-sidebar" aria-label="Navigasi admin">
  <a href="admin-dashboard.php" class="admin-sidebar-brand"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"><span>SMK Infokom<br>Admin</span></a>
  <div class="admin-sidebar-label">Workspace</div>
  <a href="admin-dashboard.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/></svg><span>Dashboard</span></a>
  <a href="admin-penerimaan.php" class="active"><svg viewBox="0 0 24 24" fill="none"><path d="M4 5h16v14H4zM4 7l8 6 8-6M8 10v5m8-5v5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Penerimaan</span></a>
  <a href="admin-kelola.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Kelola Konten</span></a>
  <a href="admin-absensi.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="15" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3v4m8-4v4M7 11h10" stroke="currentColor" stroke-width="1.7"/></svg><span>Absensi</span></a>
  <a href="admin-bkk.php"><svg viewBox="0 0 24 24" fill="none"><path d="M3 8h18v12H3zM7 8V5h10v3M8 13h8M8 16h5" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/></svg><span>BKK</span></a>
  <div class="admin-sidebar-label">Aplikasi</div>
  <a href="index.php"><svg viewBox="0 0 24 24" fill="none"><path d="m4 11 8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>Lihat Situs</span></a>
  <div class="admin-sidebar-footer"><a href="logout.php"><svg viewBox="0 0 24 24" fill="none"><path d="M10 5H5v14h5m5-4 4-3-4-3m4 3H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Keluar</span></a></div>
</aside>
<div class="dash-topbar"><div class="wrap">
  <a href="admin-dashboard.php" style="font-family:'Libre Franklin',sans-serif;font-weight:700;color:var(--navy);">Dashboard Admin</a>
  <div style="display:flex;align-items:center;gap:16px;"><a href="admin-dashboard.php" style="font-size:13px;color:var(--muted);font-weight:600;">Dashboard</a><a href="logout.php" style="font-size:13px;color:var(--muted);font-weight:600;">Keluar</a><div class="dash-avatar"><?= h(strtoupper(substr($user['nama'], 0, 2))) ?></div></div>
</div></div>
<main class="dash-wrap"><div class="wrap">
  <header class="dash-head"><div><h2>Penerimaan &amp; Pesan Masuk</h2><p>Tinjau pendaftaran PPDB dan pesan dari formulir Kontak.</p></div></header>
  <?php if ($flash): ?><div class="request-flash <?= h($flash['type']) ?>" role="status"><?= h($flash['text']) ?></div><?php endif; ?>
  <p class="request-count"><?= number_format($menunggu, 0, ',', '.') ?> data menunggu verifikasi (maksimal 200 data terbaru per bagian).</p>
  <section class="request-panel">
    <h2>Pendaftaran PPDB</h2>
    <?php if ($pendaftar): ?>
    <div class="request-table-wrap"><table class="request-table"><thead><tr><th>Calon siswa</th><th>Kontak</th><th>Pilihan &amp; jalur</th><th>Data lainnya</th><th>Status</th><th>Tanggal</th><th>Tindakan</th></tr></thead><tbody>
    <?php foreach ($pendaftar as $row): ?>
      <?php $statusClass = $row['status'] === 'Diterima' ? 'accepted' : ($row['status'] === 'Ditolak' ? 'rejected' : ''); ?>
      <tr>
        <td><strong><?= h($row['nama']) ?></strong><br>NISN: <?= h($row['nisn']) ?><br>NIK: <?= h($row['nik']) ?></td>
        <td><?= h($row['email']) ?><br>WA: <?= h($row['wa_ortu']) ?></td>
        <td><?= h($row['pilihan1']) ?><br><?= h($row['jalur']) ?><?= $row['pilihan2'] ? '<br>Pilihan 2: ' . h($row['pilihan2']) : '' ?></td>
        <td><details><summary>Lihat biodata</summary><p>Tempat/tanggal lahir: <?= h($row['tempat_lahir']) ?>, <?= h($row['tanggal_lahir']) ?><br>Jenis kelamin: <?= h($row['jk']) ?><br>Asal sekolah: <?= h($row['asal_sekolah']) ?><br>Alamat: <?= h($row['alamat']) ?></p></details></td>
        <td><span class="request-status <?= $statusClass ?>"><?= h($row['status']) ?></span></td>
        <td><?= h($row['created_at']) ?></td>
        <td><?php if ($row['status'] === 'Menunggu Verifikasi'): ?><div class="request-actions"><?php foreach (['Diterima' => 'accept', 'Ditolak' => 'reject'] as $status => $class): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= h(request_csrf_token()) ?>"><input type="hidden" name="type" value="ppdb"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>"><button class="<?= $class ?>" name="status" value="<?= h($status) ?>"><?= h($status) ?></button></form><?php endforeach; ?></div><?php else: ?>—<?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <?php else: ?><p>Belum ada pendaftaran PPDB.</p><?php endif; ?>
  </section>
  <section class="request-panel">
    <h2>Pesan Kontak</h2>
    <?php if ($pesanKontak): ?>
    <div class="request-table-wrap"><table class="request-table"><thead><tr><th>Pengirim</th><th>Pesan</th><th>Status</th><th>Tanggal</th><th>Tindakan</th></tr></thead><tbody>
    <?php foreach ($pesanKontak as $row): ?>
      <?php $statusClass = $row['status'] === 'Diterima' ? 'accepted' : ($row['status'] === 'Ditolak' ? 'rejected' : ''); ?>
      <tr>
        <td><strong><?= h($row['nama']) ?></strong><br><?= h($row['email']) ?></td>
        <td><details><summary>Baca pesan</summary><p><?= h($row['pesan']) ?></p></details></td>
        <td><span class="request-status <?= $statusClass ?>"><?= h($row['status']) ?></span></td>
        <td><?= h($row['created_at']) ?></td>
        <td><?php if ($row['status'] === 'Menunggu Verifikasi'): ?><div class="request-actions"><?php foreach (['Diterima' => 'accept', 'Ditolak' => 'reject'] as $status => $class): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= h(request_csrf_token()) ?>"><input type="hidden" name="type" value="kontak"><input type="hidden" name="id" value="<?= (int) $row['id'] ?>"><button class="<?= $class ?>" name="status" value="<?= h($status) ?>"><?= h($status) ?></button></form><?php endforeach; ?></div><?php else: ?>—<?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
    <?php else: ?><p>Belum ada pesan dari formulir Kontak.</p><?php endif; ?>
  </section>
</div></main>
<script src="assets/main.js"></script>
</body>
</html>
