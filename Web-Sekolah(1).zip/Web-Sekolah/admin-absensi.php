<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
$user = require_role('admin');

$saveMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah_absensi'])) {
    $stmt = $pdo->prepare(
        'INSERT INTO absensi (siswa_id, tanggal, jam_masuk, status, keterangan) VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->execute([
        $_POST['siswa_id'],
        $_POST['tanggal'] ?: date('Y-m-d'),
        $_POST['jam_masuk'] ?: null,
        $_POST['status'],
        $_POST['keterangan'] ?: null,
    ]);
    $saveMsg = 'Data absensi berhasil disimpan.';
}

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');

$stmt = $pdo->prepare(
    'SELECT a.*, s.nama, s.kelas FROM absensi a
     JOIN siswa s ON s.id = a.siswa_id
     WHERE a.tanggal = ?
     ORDER BY a.jam_masuk IS NULL, a.jam_masuk ASC'
);
$stmt->execute([$tanggal]);
$rows = $stmt->fetchAll();

$total = count($rows);
$countBy = ['Hadir' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0, 'Terlambat' => 0];
foreach ($rows as $r) { $countBy[$r['status']] = ($countBy[$r['status']] ?? 0) + 1; }
$pct = fn($n) => $total > 0 ? round($n / $total * 100, 1) : 0;

$kelasList = $pdo->query('SELECT DISTINCT kelas FROM siswa ORDER BY kelas')->fetchAll(PDO::FETCH_COLUMN);
$siswaList = $pdo->query('SELECT id, nama, kelas FROM siswa ORDER BY nama')->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Absensi Siswa | Dashboard Admin SMK Infokom Bogor</title>
<meta name="description" content="Kelola data absensi siswa SMK Infokom Bogor (contoh tampilan admin).">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="admin-body">
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>

<aside class="admin-sidebar" aria-label="Navigasi admin">
  <a href="admin-dashboard.php" class="admin-sidebar-brand"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"><span>SMK Infokom<br>Admin</span></a>
  <div class="admin-sidebar-label">Workspace</div>
  <a href="admin-dashboard.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/></svg><span>Dashboard</span></a><a href="admin-kelola.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Kelola Konten</span></a><a href="admin-absensi.php" class="active"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="15" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3v4m8-4v4M7 11h10M8 15h3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Absensi</span></a><a href="admin-bkk.php"><svg viewBox="0 0 24 24" fill="none"><path d="M3 8h18v12H3zM7 8V5h10v3M8 13h8M8 16h5" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/></svg><span>BKK</span></a>
  <div class="admin-sidebar-label">Aplikasi</div><a href="index.php"><svg viewBox="0 0 24 24" fill="none"><path d="m4 11 8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>Lihat Situs</span></a><div class="admin-sidebar-footer"><a href="logout.php"><svg viewBox="0 0 24 24" fill="none"><path d="M10 5H5v14h5m5-4 4-3-4-3m4 3H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Keluar</span></a></div>
</aside>

<div class="dash-topbar">
  <div class="wrap">
    <a href="admin-dashboard.php" style="display:flex;align-items:center;gap:10px;font-family:'Libre Franklin',sans-serif;font-weight:700;font-size:14.5px;color:var(--navy);">
      <span class="brand-mark" style="width:32px;height:32px;font-size:13px;"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span> Dashboard Admin
    </a>
    <div class="dash-search">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M21 21l-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      <input type="text" id="absensiSearch" placeholder="Cari nama siswa...">
    </div>
    <div style="display:flex;align-items:center;gap:16px;">
      <a href="admin-dashboard.php" style="font-size:13px;color:var(--muted);font-weight:600;">&larr; Dashboard</a>
      <a href="admin-kelola.php" style="font-size:13px;color:var(--muted);font-weight:600;">Kelola Konten</a>
      <a href="logout.php" style="font-size:13px;color:var(--muted);font-weight:600;">Keluar</a>
      <div class="dash-avatar"><?= h(strtoupper(substr($user['nama'],0,2))) ?></div>
    </div>
  </div>
</div>

<div class="dash-wrap">
  <div class="wrap">
    <div class="dash-head">
      <div>
        <h2>Absensi Siswa</h2>
        <p>Rekap kehadiran tanggal <?= date('d F Y', strtotime($tanggal)) ?>.</p>
      </div>
      <form method="get" style="display:flex;gap:10px;align-items:center;">
        <input type="date" name="tanggal" value="<?= h($tanggal) ?>" onchange="this.form.submit()" style="padding:9px 12px;border:1px solid var(--line);border-radius:8px;">
        <button type="button" class="btn btn-navy" style="padding:11px 20px;" onclick="document.getElementById('tambahAbsenModal').classList.add('open')">+ Tambah Absensi</button>
      </form>
    </div>

    <?php if ($saveMsg): ?>
      <p style="margin:-6px 0 18px;padding:12px 14px;border-radius:8px;background:#EAF6F1;color:#1B6B6B;font-size:13.5px;font-weight:600;"><?= h($saveMsg) ?></p>
    <?php endif; ?>

    <div class="stat-card-row reveal" data-stagger>
      <div class="stat-card"><div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4 10-10" stroke="#1B6B6B" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></div><b><?= $pct($countBy['Hadir']) ?>%</b><span>Hadir</span></div>
      <div class="stat-card"><div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 8v4l3 2" stroke="#C9832A" stroke-width="1.6" stroke-linecap="round"/><circle cx="12" cy="12" r="9" stroke="#C9832A" stroke-width="1.6"/></svg></div><b><?= $pct($countBy['Izin']) ?>%</b><span>Izin</span></div>
      <div class="stat-card"><div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 2c3 4 6 7 6 11a6 6 0 01-12 0c0-4 3-7 6-11z" stroke="#A6192E" stroke-width="1.6"/></svg></div><b><?= $pct($countBy['Sakit']) ?>%</b><span>Sakit</span></div>
      <div class="stat-card"><div class="ic"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="#8C1526" stroke-width="1.6"/><path d="M9 9l6 6M15 9l-6 6" stroke="#8C1526" stroke-width="1.6" stroke-linecap="round"/></svg></div><b><?= $pct($countBy['Alpa']) ?>%</b><span>Alpa</span></div>
    </div>

    <div class="dash-panel reveal">
      <div class="table-filters">
        <select id="filterKelas">
          <option value="all">Semua Kelas</option>
          <?php foreach ($kelasList as $k): ?>
            <option value="<?= h($k) ?>"><?= h($k) ?></option>
          <?php endforeach; ?>
        </select>
        <select id="filterStatus">
          <option value="all">Semua Status</option>
          <option value="Hadir">Hadir</option>
          <option value="Izin">Izin</option>
          <option value="Sakit">Sakit</option>
          <option value="Terlambat">Terlambat</option>
          <option value="Alpa">Alpa</option>
        </select>
      </div>
      <div style="overflow-x:auto;">
        <table class="data-table" id="absensiTable">
          <thead><tr><th>Nama</th><th>Kelas</th><th>Jam Masuk</th><th>Status</th><th>Keterangan</th></tr></thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="5" style="text-align:center;color:var(--muted);">Belum ada data absensi untuk tanggal ini.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $r):
              $statusClass = ['Hadir'=>'status-hadir','Izin'=>'status-izin','Sakit'=>'status-izin','Terlambat'=>'status-telat','Alpa'=>'status-alpa'][$r['status']] ?? '';
            ?>
            <tr data-kelas="<?= h($r['kelas']) ?>" data-status="<?= h($r['status']) ?>">
              <td><?= h($r['nama']) ?></td>
              <td><?= h($r['kelas']) ?></td>
              <td><?= $r['jam_masuk'] ? h(substr($r['jam_masuk'],0,5)) : '—' ?></td>
              <td><span class="status-pill <?= $statusClass ?>"><?= h($r['status']) ?></span></td>
              <td><?= $r['keterangan'] ? h($r['keterangan']) : '—' ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<div class="modal-overlay" id="tambahAbsenModal">
  <div class="modal-box">
    <button class="modal-close" onclick="document.getElementById('tambahAbsenModal').classList.remove('open')">&times;</button>
    <h4>Tambah Absensi</h4>
    <form method="post">
      <input type="hidden" name="tambah_absensi" value="1">
      <div class="form-grid">
        <div class="form-field full">
          <label>Siswa</label>
          <select name="siswa_id" required>
            <?php foreach ($siswaList as $s): ?>
              <option value="<?= (int)$s['id'] ?>"><?= h($s['nama']) ?> — <?= h($s['kelas']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-field"><label>Tanggal</label><input type="date" name="tanggal" value="<?= h($tanggal) ?>"></div>
        <div class="form-field"><label>Jam Masuk</label><input type="time" name="jam_masuk"></div>
        <div class="form-field">
          <label>Status</label>
          <select name="status" required>
            <option value="Hadir">Hadir</option>
            <option value="Izin">Izin</option>
            <option value="Sakit">Sakit</option>
            <option value="Terlambat">Terlambat</option>
            <option value="Alpa">Alpa</option>
          </select>
        </div>
        <div class="form-field full"><label>Keterangan</label><input type="text" name="keterangan" placeholder="Opsional"></div>
      </div>
      <button type="submit" class="btn btn-gold ppdb-submit" style="margin-top:16px;">Simpan</button>
    </form>
  </div>
</div>

<script src="assets/main.js"></script>
<script>
function applyAbsensiFilter(){
  const kelas = document.getElementById('filterKelas').value;
  const status = document.getElementById('filterStatus').value;
  const q = document.getElementById('absensiSearch').value.trim().toLowerCase();
  document.querySelectorAll('#absensiTable tbody tr').forEach(function(row){
    if (!row.dataset.kelas) return;
    const matchKelas = kelas === 'all' || row.dataset.kelas === kelas;
    const matchStatus = status === 'all' || row.dataset.status === status;
    const matchName = row.children[0].textContent.toLowerCase().includes(q);
    row.style.display = (matchKelas && matchStatus && matchName) ? '' : 'none';
  });
}
document.getElementById('filterKelas').addEventListener('change', applyAbsensiFilter);
document.getElementById('filterStatus').addEventListener('change', applyAbsensiFilter);
document.getElementById('absensiSearch').addEventListener('input', applyAbsensiFilter);
</script>
</body>
</html>
