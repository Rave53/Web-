<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/requests.php';
$pesanSukses = false;
$pesanError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        request_verify_csrf();
    } catch (RuntimeException $e) {
        $pesanError = $e->getMessage();
    }

    $nama = trim((string) ($_POST['nama_kontak'] ?? ''));
    $email = trim((string) ($_POST['email_kontak'] ?? ''));
    $pesan = trim((string) ($_POST['pesan_kontak'] ?? ''));
    if ($pesanError === '' && ($nama === '' || $pesan === '' || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
        $pesanError = 'Nama, email yang valid, dan pesan wajib diisi.';
    }
    if ($pesanError === '') {
        $stmt = $pdo->prepare("INSERT INTO pesan_kontak (nama, email, pesan, status) VALUES (?, ?, ?, 'Menunggu Verifikasi')");
        $stmt->execute([$nama, $email, $pesan]);
        $pesanSukses = true;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kontak Kami | SMK Infokom Bogor</title>
<meta name="description" content="Alamat, telepon, email, jam operasional, dan lokasi SMK Infokom Bogor di Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Kunjungi Kami</a>
    <a href="ppdb.php">Daftar PPDB</a>
    <a href="portal.php">Portal Siswa &amp; Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil &amp; Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi &amp; Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer &amp; Jaringan</a>
            <a href="akademik.php">DKV (Desain Komunikasi Visual)</a>
            <a href="akademik.php">PSPT</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas &amp; Laboratorium</a>
            
            
            
  <a href="portal-siswa-login.php">Portal Siswa</a>
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil &amp; Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi &amp; Misi</a>
  <a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info &amp; Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / Kontak</div>
    <h1 class="split">Kontak Kami</h1>
    <p>Hubungi kami untuk informasi pendaftaran, kunjungan sekolah, atau pertanyaan lainnya.</p>
  </div>
</header>

<section class="explore">
  <div class="wrap" style="display:grid;grid-template-columns:.85fr 1.15fr;gap:50px;align-items:start;">
    <div class="reveal">
      <div class="eyebrow">Informasi Kontak</div>
      <h2 class="split" style="font-size:clamp(24px,2.8vw,30px);margin-bottom:24px;">Kami siap membantu</h2>

      <div style="display:flex;gap:16px;padding:18px 0;border-top:1px solid var(--line);">
        <div style="width:38px;height:38px;border-radius:8px;background:var(--sky);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 22s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z" stroke="#1B6B6B" stroke-width="1.6"/><circle cx="12" cy="10" r="2.5" stroke="#1B6B6B" stroke-width="1.6"/></svg></div>
        <div><h4 style="font-size:14.5px;">Alamat</h4><p style="margin-top:4px;font-size:14px;color:var(--muted);line-height:1.6;">Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p></div>
      </div>
      <div style="display:flex;gap:16px;padding:18px 0;border-top:1px solid var(--line);">
        <div style="width:38px;height:38px;border-radius:8px;background:var(--sky);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 5h4l2 5-2.5 1.5a11 11 0 005 5L14 14l5 2v4a2 2 0 01-2 2C9.5 22 2 14.5 2 7a2 2 0 012-2z" stroke="#C9832A" stroke-width="1.6" stroke-linejoin="round"/></svg></div>
        <div><h4 style="font-size:14.5px;">Telepon</h4><p style="margin-top:4px;font-size:14px;color:var(--muted);">(0251) 837-2210</p></div>
      </div>
      <div style="display:flex;gap:16px;padding:18px 0;border-top:1px solid var(--line);">
        <div style="width:38px;height:38px;border-radius:8px;background:var(--sky);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="#1B6B6B" stroke-width="1.6"/><path d="M3 7l9 6 9-6" stroke="#1B6B6B" stroke-width="1.6"/></svg></div>
        <div><h4 style="font-size:14.5px;">Email</h4><p style="margin-top:4px;font-size:14px;color:var(--muted);">smk.infokom@gmail.com</p></div>
      </div>
      <div style="display:flex;gap:16px;padding:18px 0;border-top:1px solid var(--line);border-bottom:1px solid var(--line);">
        <div style="width:38px;height:38px;border-radius:8px;background:var(--sky);display:flex;align-items:center;justify-content:center;flex-shrink:0;"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9" stroke="#C9832A" stroke-width="1.6"/><path d="M12 7v5l3.5 2" stroke="#C9832A" stroke-width="1.6" stroke-linecap="round"/></svg></div>
        <div><h4 style="font-size:14.5px;">Jam Operasional</h4><p style="margin-top:4px;font-size:14px;color:var(--muted);">Senin – Jumat, 07.00 – 16.00 WIB</p></div>
      </div>

      <h4 style="font-size:14px;margin-top:28px;margin-bottom:14px;">Ikuti Kami</h4>
      <div class="foot-social" style="justify-content:flex-start;">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram" style="border-color:var(--line);"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#5C6B7A" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#5C6B7A" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube" style="border-color:var(--line);"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#5C6B7A" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#5C6B7A"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok" style="border-color:var(--line);"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#5C6B7A" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#5C6B7A" stroke-width="1.5"/></svg></a>
      </div>
    </div>

    <div class="reveal-right">
      <div style="border-radius:var(--r);overflow:hidden;border:1px solid var(--line);box-shadow:var(--shadow);">
        <iframe
          src="https://maps.google.com/maps?q=Bogor%2C%20Jawa%20Barat&t=&z=14&ie=UTF8&iwloc=&output=embed"
          width="100%" height="420" style="border:0;display:block;" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
          title="Peta lokasi SMK Infokom Bogor"></iframe>
      </div>
      <div class="ppdb-form-card" style="margin-top:24px;padding:32px;">
        <h3 style="font-size:17px;">Kirim Pesan</h3>
        <p style="margin-bottom:20px;">Ada pertanyaan? Isi form ini dan tim kami akan membalas lewat email.</p>
        <?php if ($pesanSukses): ?>
          <p style="margin-bottom:16px;padding:12px 14px;border-radius:8px;background:#EAF6F1;color:#1B6B6B;font-size:13.5px;font-weight:600;">Terima kasih, pesan Anda sudah diterima dan menunggu tindak lanjut admin.</p>
        <?php elseif ($pesanError !== ''): ?>
          <p role="alert" style="margin-bottom:16px;padding:12px 14px;border-radius:8px;background:#FDEBEC;color:var(--crimson);font-size:13.5px;font-weight:600;"><?= h($pesanError) ?></p>
        <?php endif; ?>
        <form method="post" action="kontak.php">
          <input type="hidden" name="csrf_token" value="<?= h(request_csrf_token()) ?>">
          <div class="form-field full"><label>Nama *</label><input type="text" name="nama_kontak" required placeholder="Nama lengkap"></div>
          <div class="form-field full"><label>Email *</label><input type="email" name="email_kontak" required placeholder="nama@email.com"></div>
          <div class="form-field full"><label>Pesan *</label><textarea name="pesan_kontak" required placeholder="Tulis pertanyaan atau pesan..."></textarea></div>
          <button type="submit" class="btn btn-gold ppdb-submit">Kirim Pesan</button>
        </form>
      </div>
    </div>
  </div>
</section>
<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
