<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/crud.php';
require_once __DIR__ . '/includes/videos.php';
require_once __DIR__ . '/includes/gallery.php';
require_once __DIR__ . '/includes/page_media.php';
require_once __DIR__ . '/includes/akademik_images.php';
$user = require_role('admin');

$entities = crud_entities();
$entityKey = $_GET['entity'] ?? 'guru';
$isVideo = $entityKey === 'video';
$isJapanGallery = $entityKey === 'japan_gallery';
$isPageImages = $entityKey === 'page_images';
$isAkademikImages = $entityKey === 'akademik_images';
$isMedia = $entityKey === 'media';
if (!$isVideo && !$isJapanGallery && !$isPageImages && !$isAkademikImages && !$isMedia && !isset($entities[$entityKey])) {
    $entityKey = 'guru';
}
$entity = ($isVideo || $isJapanGallery || $isPageImages || $isAkademikImages || $isMedia) ? null : $entities[$entityKey];
$table = $entity['table'] ?? '';
$msg = '';
$videoError = '';
$cleanupWarning = '';

if ($isAkademikImages) {
    $akademikImageSlots = akademik_image_slots();
    $newImages = [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            video_verify_csrf();
            if (($_POST['aksi'] ?? '') !== 'simpan_gambar_akademik') {
                throw new RuntimeException('Aksi pengaturan gambar Akademik tidak dikenali.');
            }

            $oldImages = [];
            foreach ($akademikImageSlots as $slotKey => $_slot) {
                $file = $_FILES['image_' . $slotKey] ?? [];
                $newImage = video_store_upload($file, 'akademik_image');
                if ($newImage === null) {
                    continue;
                }
                $newImages[$slotKey] = $newImage['path'];

                $lookup = $pdo->prepare('SELECT image_path FROM akademik_images WHERE slot_key = ?');
                $lookup->execute([$slotKey]);
                $oldImage = $lookup->fetchColumn();
                if (is_string($oldImage)) {
                    $oldImages[$slotKey] = $oldImage;
                }
            }
            if ($newImages === []) {
                throw new RuntimeException('Pilih minimal satu foto untuk diganti.');
            }

            $pdo->beginTransaction();
            $save = $pdo->prepare(
                'INSERT INTO akademik_images (slot_key, image_path) VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE image_path = VALUES(image_path)'
            );
            foreach ($newImages as $slotKey => $imagePath) {
                $save->execute([$slotKey, $imagePath]);
            }
            $pdo->commit();

            foreach ($oldImages as $oldImage) {
                try {
                    video_delete_upload($oldImage);
                } catch (RuntimeException $exception) {
                    error_log('Gagal menghapus foto Akademik lama: ' . $exception->getMessage());
                    $cleanupWarning = 'Foto berhasil disimpan, tetapi file foto lama gagal dibersihkan.';
                }
            }
            $newImages = [];
            $msg = 'Foto Akademik berhasil diperbarui.';
        } catch (RuntimeException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            foreach ($newImages as $imagePath) {
                video_delete_upload($imagePath);
            }
            $videoError = $exception->getMessage();
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            foreach ($newImages as $imagePath) {
                video_delete_upload($imagePath);
            }
            error_log('Gagal menyimpan foto Akademik: ' . $exception->getMessage());
            $videoError = 'Foto Akademik gagal disimpan. Periksa database lalu coba lagi.';
        }
    }
    $akademikImagePaths = akademik_image_paths();
} elseif ($isMedia) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newImage = null;
        try {
            video_verify_csrf();
            $action = $_POST['aksi'] ?? '';
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

            if ($action === 'hapus') {
                if (!$id || $id < 1) {
                    throw new RuntimeException('Media yang dipilih tidak valid.');
                }
                $lookup = $pdo->prepare('SELECT image_path FROM page_media WHERE id = ?');
                $lookup->execute([$id]);
                $old = $lookup->fetch();
                if (!$old) {
                    throw new RuntimeException('Media tidak ditemukan.');
                }
                $delete = $pdo->prepare('DELETE FROM page_media WHERE id = ?');
                $delete->execute([$id]);
                video_delete_upload($old['image_path']);
                $msg = 'Media berhasil dihapus.';
            } elseif (in_array($action, ['tambah', 'edit'], true)) {
                $title = trim(is_string($_POST['title'] ?? null) ? $_POST['title'] : '');
                $pageKey = $_POST['page_key'] ?? '';
                $status = $_POST['status'] ?? '';
                if ($title === '' || !preg_match('//u', $title) || preg_match_all('/./us', $title) > 200) {
                    throw new RuntimeException('Judul foto wajib diisi dan maksimal 200 karakter.');
                }
                if (!in_array($pageKey, ['kunjungan_industri', 'mitra_kerja'], true)) {
                    throw new RuntimeException('Pilih halaman tujuan media yang valid.');
                }
                if (!in_array($status, ['aktif', 'nonaktif'], true)) {
                    throw new RuntimeException('Pilih status publikasi yang valid.');
                }

                $old = null;
                if ($action === 'edit') {
                    if (!$id || $id < 1) {
                        throw new RuntimeException('Media yang dipilih tidak valid.');
                    }
                    $lookup = $pdo->prepare('SELECT image_path FROM page_media WHERE id = ?');
                    $lookup->execute([$id]);
                    $old = $lookup->fetch();
                    if (!$old) {
                        throw new RuntimeException('Media tidak ditemukan.');
                    }
                }

                $newImage = video_store_upload($_FILES['image'] ?? [], 'page_media');
                $imagePath = $newImage['path'] ?? ($old['image_path'] ?? null);
                if ($imagePath === null) {
                    throw new RuntimeException('Pilih gambar JPG, PNG, atau WebP (maksimal 5 MB).');
                }

                try {
                    if ($action === 'tambah') {
                        $save = $pdo->prepare('INSERT INTO page_media (page_key, title, image_path, status) VALUES (?, ?, ?, ?)');
                        $save->execute([$pageKey, $title, $imagePath, $status]);
                        $msg = 'Media berhasil ditambahkan.';
                    } else {
                        $save = $pdo->prepare('UPDATE page_media SET page_key = ?, title = ?, image_path = ?, status = ? WHERE id = ?');
                        $save->execute([$pageKey, $title, $imagePath, $status, $id]);
                        $msg = 'Media berhasil diperbarui.';
                    }
                } catch (Throwable $exception) {
                    if ($newImage !== null) {
                        video_delete_upload($newImage['path']);
                    }
                    throw $exception;
                }

                $newImage = null;
                if ($old && $old['image_path'] !== $imagePath) {
                    video_delete_upload($old['image_path']);
                }
            } else {
                throw new RuntimeException('Aksi media tidak dikenali.');
            }
        } catch (RuntimeException $exception) {
            if ($newImage !== null) {
                video_delete_upload($newImage['path']);
            }
            $videoError = $exception->getMessage();
        } catch (PDOException $exception) {
            if ($newImage !== null) {
                video_delete_upload($newImage['path']);
            }
            error_log('Gagal mengelola media halaman: ' . $exception->getMessage());
            $videoError = 'Media gagal disimpan. Periksa database lalu coba lagi.';
        }
    }
    $pageMediaItems = page_media_items();
} elseif ($isPageImages) {
    $pageImageSlots = gallery_image_slots();
    $galleryImages = gallery_images();
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        try {
            video_verify_csrf();
            if (($_POST['aksi'] ?? '') !== 'simpan_gambar_halaman') {
                throw new RuntimeException('Aksi pengaturan gambar tidak dikenali.');
            }

            $submittedImages = $_POST['images'] ?? [];
            if (!is_array($submittedImages)) {
                throw new RuntimeException('Pilihan gambar tidak valid.');
            }

            $availableImageIds = array_fill_keys(array_map(
                static fn(array $image): string => (string) $image['id'],
                $galleryImages
            ), true);
            $selections = [];
            foreach ($pageImageSlots as $slotKey => $_slot) {
                $value = $submittedImages[$slotKey] ?? '';
                if (!is_string($value)) {
                    throw new RuntimeException('Pilihan gambar tidak valid.');
                }
                if ($value === '') {
                    $selections[$slotKey] = null;
                    continue;
                }
                if (!ctype_digit($value) || !isset($availableImageIds[$value])) {
                    throw new RuntimeException('Pilih gambar yang tersedia dari Galeri.');
                }
                $selections[$slotKey] = (int) $value;
            }

            $pdo->beginTransaction();
            $save = $pdo->prepare(
                'INSERT INTO page_image_slots (slot_key, gallery_id) VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE gallery_id = VALUES(gallery_id)'
            );
            foreach ($selections as $slotKey => $galleryId) {
                $save->execute([$slotKey, $galleryId]);
            }
            $pdo->commit();
            $msg = 'Pengaturan gambar Beranda dan Profil berhasil disimpan.';
        } catch (RuntimeException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $videoError = $exception->getMessage();
        } catch (PDOException $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            error_log('Gagal menyimpan pengaturan gambar halaman: ' . $exception->getMessage());
            $videoError = 'Pengaturan gambar gagal disimpan. Periksa database lalu coba lagi.';
        }
    }
    $pageImageSelections = gallery_page_image_selections();
} elseif ($isVideo) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newVideo = null;
        $newThumbnail = null;
        try {
            video_verify_csrf();
            $action = $_POST['aksi'] ?? '';
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

            if ($action === 'hapus') {
                if (!$id || $id < 1) {
                    throw new RuntimeException('Video yang dipilih tidak valid.');
                }
                $lookup = $pdo->prepare('SELECT video_path, thumbnail_path FROM videos WHERE id = ?');
                $lookup->execute([$id]);
                $old = $lookup->fetch();
                if (!$old) {
                    throw new RuntimeException('Video tidak ditemukan.');
                }
                $delete = $pdo->prepare('DELETE FROM videos WHERE id = ?');
                $delete->execute([$id]);
                video_delete_upload($old['video_path']);
                video_delete_upload($old['thumbnail_path']);
                $msg = 'Video berhasil dihapus.';
            } elseif (in_array($action, ['tambah', 'edit'], true)) {
                $title = trim(is_string($_POST['title'] ?? null) ? $_POST['title'] : '');
                $description = trim(is_string($_POST['description'] ?? null) ? $_POST['description'] : '');
                $sourceType = $_POST['source_type'] ?? '';
                $status = $_POST['status'] ?? '';
                if ($title === '' || !preg_match('//u', $title) || preg_match_all('/./us', $title) > 200) {
                    throw new RuntimeException('Judul wajib diisi dan maksimal 200 karakter.');
                }
                if (!preg_match('//u', $description) || preg_match_all('/./us', $description) > 5000) {
                    throw new RuntimeException('Deskripsi maksimal 5.000 karakter.');
                }
                if (!in_array($sourceType, ['upload', 'youtube'], true)) {
                    throw new RuntimeException('Pilih sumber video yang valid.');
                }
                if (!in_array($status, ['aktif', 'nonaktif'], true)) {
                    throw new RuntimeException('Pilih status publikasi yang valid.');
                }

                $old = null;
                if ($action === 'edit') {
                    if (!$id || $id < 1) {
                        throw new RuntimeException('Video yang dipilih tidak valid.');
                    }
                    $lookup = $pdo->prepare('SELECT video_path, youtube_id, thumbnail_path, source_type FROM videos WHERE id = ?');
                    $lookup->execute([$id]);
                    $old = $lookup->fetch();
                    if (!$old) {
                        throw new RuntimeException('Video tidak ditemukan.');
                    }
                }

                $youtubeId = null;
                $videoPath = null;
                if ($sourceType === 'youtube') {
                    $youtubeUrl = trim(is_string($_POST['youtube_url'] ?? null) ? $_POST['youtube_url'] : '');
                    $youtubeId = video_youtube_id($youtubeUrl);
                    if ($youtubeId === null) {
                        throw new RuntimeException('Masukkan URL video YouTube yang valid.');
                    }
                } else {
                    $newVideo = video_store_upload($_FILES['video'] ?? [], 'video');
                    if ($newVideo !== null) {
                        $videoPath = $newVideo['path'];
                    } elseif ($old && $old['source_type'] === 'upload') {
                        $videoPath = $old['video_path'];
                    } else {
                        throw new RuntimeException('Pilih file video MP4, WebM, atau Ogg (maksimal 100 MB).');
                    }
                }

                $newThumbnail = video_store_upload($_FILES['thumbnail'] ?? [], 'thumbnail');
                $thumbnailPath = $newThumbnail['path'] ?? ($old['thumbnail_path'] ?? null);

                try {
                    if ($action === 'tambah') {
                        $save = $pdo->prepare('INSERT INTO videos (title, description, source_type, video_path, youtube_id, thumbnail_path, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
                        $save->execute([$title, $description !== '' ? $description : null, $sourceType, $videoPath, $youtubeId, $thumbnailPath, $status]);
                        $msg = 'Video berhasil ditambahkan.';
                    } else {
                        $save = $pdo->prepare('UPDATE videos SET title = ?, description = ?, source_type = ?, video_path = ?, youtube_id = ?, thumbnail_path = ?, status = ? WHERE id = ?');
                        $save->execute([$title, $description !== '' ? $description : null, $sourceType, $videoPath, $youtubeId, $thumbnailPath, $status, $id]);
                        $msg = 'Video berhasil diperbarui.';
                    }
                } catch (Throwable $exception) {
                    if ($newVideo !== null) {
                        video_delete_upload($newVideo['path']);
                    }
                    if ($newThumbnail !== null) {
                        video_delete_upload($newThumbnail['path']);
                    }
                    throw $exception;
                }

                $newVideo = null;
                $newThumbnail = null;
                if ($old) {
                    if ($old['video_path'] !== $videoPath) {
                        video_delete_upload($old['video_path']);
                    }
                    if ($old['thumbnail_path'] !== $thumbnailPath) {
                        video_delete_upload($old['thumbnail_path']);
                    }
                }
            } else {
                throw new RuntimeException('Aksi video tidak dikenali.');
            }
        } catch (RuntimeException $exception) {
            if ($newVideo !== null) {
                video_delete_upload($newVideo['path']);
            }
            if ($newThumbnail !== null) {
                video_delete_upload($newThumbnail['path']);
            }
            $videoError = $exception->getMessage();
        }
    }

    $videos = $pdo->query('SELECT * FROM videos ORDER BY created_at DESC, id DESC')->fetchAll();
} elseif ($isJapanGallery) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $newMedia = null;
        try {
            video_verify_csrf();
            $action = $_POST['aksi'] ?? '';
            $id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT);

            if ($action === 'hapus') {
                if (!$id || $id < 1) {
                    throw new RuntimeException('Item galeri yang dipilih tidak valid.');
                }
                $lookup = $pdo->prepare('SELECT image_path, video_path FROM japan_gallery WHERE id = ?');
                $lookup->execute([$id]);
                $old = $lookup->fetch();
                if (!$old) {
                    throw new RuntimeException('Item galeri tidak ditemukan.');
                }
                $delete = $pdo->prepare('DELETE FROM japan_gallery WHERE id = ?');
                $delete->execute([$id]);
                video_delete_upload($old['image_path']);
                video_delete_upload($old['video_path']);
                $msg = 'Item galeri Magang Jepang berhasil dihapus.';
            } elseif (in_array($action, ['tambah', 'edit'], true)) {
                $title = trim(is_string($_POST['title'] ?? null) ? $_POST['title'] : '');
                $description = trim(is_string($_POST['description'] ?? null) ? $_POST['description'] : '');
                $itemType = $_POST['item_type'] ?? '';
                $status = $_POST['status'] ?? '';
                if ($title === '' || !preg_match('//u', $title) || preg_match_all('/./us', $title) > 200) {
                    throw new RuntimeException('Judul wajib diisi dan maksimal 200 karakter.');
                }
                if (!preg_match('//u', $description) || preg_match_all('/./us', $description) > 5000) {
                    throw new RuntimeException('Teks/deskripsi maksimal 5.000 karakter.');
                }
                if (!in_array($itemType, ['image', 'upload', 'youtube', 'text'], true)) {
                    throw new RuntimeException('Pilih jenis konten yang valid.');
                }
                if (!in_array($status, ['aktif', 'nonaktif'], true)) {
                    throw new RuntimeException('Pilih status publikasi yang valid.');
                }

                $old = null;
                if ($action === 'edit') {
                    if (!$id || $id < 1) {
                        throw new RuntimeException('Item galeri yang dipilih tidak valid.');
                    }
                    $lookup = $pdo->prepare('SELECT image_path, video_path, youtube_id, item_type FROM japan_gallery WHERE id = ?');
                    $lookup->execute([$id]);
                    $old = $lookup->fetch();
                    if (!$old) {
                        throw new RuntimeException('Item galeri tidak ditemukan.');
                    }
                }

                $imagePath = null;
                $videoPath = null;
                $youtubeId = null;
                if ($itemType === 'image') {
                    $newMedia = video_store_upload($_FILES['image'] ?? [], 'gallery_image');
                    $imagePath = $newMedia['path'] ?? ($old && $old['item_type'] === 'image' ? $old['image_path'] : null);
                    if ($imagePath === null) {
                        throw new RuntimeException('Pilih gambar JPG, PNG, atau WebP (maksimal 5 MB).');
                    }
                } elseif ($itemType === 'upload') {
                    $newMedia = video_store_upload($_FILES['video'] ?? [], 'video');
                    $videoPath = $newMedia['path'] ?? ($old && $old['item_type'] === 'upload' ? $old['video_path'] : null);
                    if ($videoPath === null) {
                        throw new RuntimeException('Pilih video MP4, WebM, atau Ogg (maksimal 100 MB).');
                    }
                } elseif ($itemType === 'youtube') {
                    $youtubeUrl = trim(is_string($_POST['youtube_url'] ?? null) ? $_POST['youtube_url'] : '');
                    $youtubeId = video_youtube_id($youtubeUrl);
                    if ($youtubeId === null) {
                        throw new RuntimeException('Masukkan URL video YouTube yang valid.');
                    }
                } elseif ($description === '') {
                    throw new RuntimeException('Isi teks untuk item jenis teks.');
                }

                try {
                    if ($action === 'tambah') {
                        $save = $pdo->prepare('INSERT INTO japan_gallery (title, description, item_type, image_path, video_path, youtube_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)');
                        $save->execute([$title, $description !== '' ? $description : null, $itemType, $imagePath, $videoPath, $youtubeId, $status]);
                        $msg = 'Konten Galeri Magang Jepang berhasil ditambahkan.';
                    } else {
                        $save = $pdo->prepare('UPDATE japan_gallery SET title = ?, description = ?, item_type = ?, image_path = ?, video_path = ?, youtube_id = ?, status = ? WHERE id = ?');
                        $save->execute([$title, $description !== '' ? $description : null, $itemType, $imagePath, $videoPath, $youtubeId, $status, $id]);
                        $msg = 'Konten Galeri Magang Jepang berhasil diperbarui.';
                    }
                } catch (Throwable $exception) {
                    if ($newMedia !== null) {
                        video_delete_upload($newMedia['path']);
                    }
                    throw $exception;
                }

                $newMedia = null;
                if ($old) {
                    if ($old['image_path'] !== $imagePath) {
                        video_delete_upload($old['image_path']);
                    }
                    if ($old['video_path'] !== $videoPath) {
                        video_delete_upload($old['video_path']);
                    }
                }
            } else {
                throw new RuntimeException('Aksi galeri tidak dikenali.');
            }
        } catch (RuntimeException $exception) {
            if ($newMedia !== null) {
                video_delete_upload($newMedia['path']);
            }
            $videoError = $exception->getMessage();
        }
    }

    $japanGalleryItems = $pdo->query('SELECT * FROM japan_gallery ORDER BY created_at DESC, id DESC')->fetchAll();
} else {
    // --- Hapus ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && $_POST['aksi'] === 'hapus') {
        $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
        $stmt->execute([(int) $_POST['id']]);
        $msg = h($entity['label_singular']) . ' berhasil dihapus.';
    }

    // --- Tambah / Edit ---
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aksi']) && in_array($_POST['aksi'], ['tambah', 'edit'], true)) {
        $cols = [];
        $vals = [];
        foreach ($entity['fields'] as $key => $def) {
            if ($def['type'] === 'image') {
                if (!empty($_FILES[$key]['name'])) {
                    $path = crud_upload_image($_FILES[$key]);
                    if ($path) {
                        $cols[] = $key;
                        $vals[] = $path;
                    }
                }
                continue;
            }
            $cols[] = $key;
            $vals[] = $_POST[$key] ?? '';
        }

        if ($_POST['aksi'] === 'tambah') {
            $placeholders = implode(',', array_fill(0, count($cols), '?'));
            $colList = implode(',', array_map(fn($c) => "`$c`", $cols));
            $stmt = $pdo->prepare("INSERT INTO `$table` ($colList) VALUES ($placeholders)");
            $stmt->execute($vals);
            $msg = h($entity['label_singular']) . ' baru berhasil ditambahkan.';
        } else {
            $id = (int) $_POST['id'];
            $setSql = implode(',', array_map(fn($c) => "`$c` = ?", $cols));
            $vals[] = $id;
            $stmt = $pdo->prepare("UPDATE `$table` SET $setSql WHERE id = ?");
            $stmt->execute($vals);
            $msg = h($entity['label_singular']) . ' berhasil diperbarui.';
        }
    }

    $rows = $pdo->query("SELECT * FROM `$table` ORDER BY {$entity['order_by']}")->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kelola Konten | Dashboard Admin SMK Infokom Bogor</title>
<meta name="description" content="Kelola konten website SMK Infokom Bogor (guru, berita, galeri, ekstrakurikuler, dan data akademik).">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="admin-body">
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>

<aside class="admin-sidebar" aria-label="Navigasi admin">
  <a href="admin-dashboard.php" class="admin-sidebar-brand"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"><span>SMK Infokom<br>Admin</span></a>
  <div class="admin-sidebar-label">Workspace</div>
  <a href="admin-dashboard.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/></svg><span>Dashboard</span></a><a href="admin-penerimaan.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 5h16v14H4zM4 7l8 6 8-6" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Penerimaan</span></a><a href="admin-kelola.php" class="active"><svg viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Kelola Konten</span></a><a href="admin-absensi.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="15" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3v4m8-4v4M7 11h10M8 15h3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Absensi</span></a><a href="admin-bkk.php"><svg viewBox="0 0 24 24" fill="none"><path d="M3 8h18v12H3zM7 8V5h10v3M8 13h8M8 16h5" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/></svg><span>BKK</span></a>
  <div class="admin-sidebar-label">Aplikasi</div><a href="index.php"><svg viewBox="0 0 24 24" fill="none"><path d="m4 11 8-7 8 7v8a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-8Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>Lihat Situs</span></a><div class="admin-sidebar-footer"><a href="logout.php"><svg viewBox="0 0 24 24" fill="none"><path d="M10 5H5v14h5m5-4 4-3-4-3m4 3H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Keluar</span></a></div>
</aside>

<div class="dash-topbar">
  <div class="wrap">
    <a href="admin-dashboard.php" style="display:flex;align-items:center;gap:10px;font-family:'Libre Franklin',sans-serif;font-weight:700;font-size:14.5px;color:var(--navy);">
      <span class="brand-mark" style="width:32px;height:32px;font-size:13px;"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span> Dashboard Admin
    </a>
    <div style="flex:1;"></div>
    <div style="display:flex;align-items:center;gap:16px;">
      <a href="admin-dashboard.php" style="font-size:13px;color:var(--muted);font-weight:600;">&larr; Dashboard</a>
      <a href="admin-absensi.php" style="font-size:13px;color:var(--muted);font-weight:600;">Absensi</a>
      <a href="index.php" style="font-size:13px;color:var(--muted);font-weight:600;">Lihat Situs</a>
      <a href="logout.php" style="font-size:13px;color:var(--muted);font-weight:600;">Keluar</a>
      <div class="dash-avatar"><?= h(strtoupper(substr($user['nama'],0,2))) ?></div>
    </div>
  </div>
</div>

<div class="dash-wrap">
  <div class="wrap">
    <div class="dash-head">
      <div>
        <h2>Kelola Konten Website</h2>
        <p>Tambah, ubah, atau hapus data yang tampil di halaman publik website.</p>
      </div>
    </div>

    <div class="table-filters" style="margin-bottom:20px;flex-wrap:wrap;">
      <?php foreach ($entities as $key => $ent):
          if ($key === 'ekstrakurikuler') {
              continue;
          }
      ?>
        <a href="admin-kelola.php?entity=<?= h($key) ?>" class="filter-chip <?= $key === $entityKey ? 'active' : '' ?>" style="text-decoration:none;display:inline-flex;"><?= h($ent['label']) ?></a>
      <?php endforeach; ?>
      <a href="admin-kelola.php?entity=video" class="filter-chip <?= $isVideo ? 'active' : '' ?>" style="text-decoration:none;display:inline-flex;">Video</a>
      <a href="admin-kelola.php?entity=japan_gallery" class="filter-chip <?= $isJapanGallery ? 'active' : '' ?>" style="text-decoration:none;display:inline-flex;">Galeri Magang Jepang</a>
      <a href="admin-kelola.php?entity=page_images" class="filter-chip <?= $isPageImages ? 'active' : '' ?>" style="text-decoration:none;display:inline-flex;">Foto Beranda &amp; Profil</a>
      <a href="admin-kelola.php?entity=akademik_images" class="filter-chip <?= $isAkademikImages ? 'active' : '' ?>" style="text-decoration:none;display:inline-flex;">Foto Akademik</a>
      <a href="admin-kelola.php?entity=media" class="filter-chip <?= $isMedia ? 'active' : '' ?>" style="text-decoration:none;display:inline-flex;">Media</a>
    </div>

    <?php if ($msg): ?>
      <p style="margin:-6px 0 18px;padding:12px 14px;border-radius:8px;background:#EAF6F1;color:#1B6B6B;font-size:13.5px;font-weight:600;"><?= h($msg) ?></p>
    <?php endif; ?>
    <?php if ($videoError !== ''): ?>
      <p class="media-error" role="alert"><?= h($videoError) ?></p>
    <?php endif; ?>
    <?php if ($cleanupWarning !== ''): ?>
      <p class="media-error" role="alert"><?= h($cleanupWarning) ?></p>
    <?php endif; ?>

    <?php if ($isAkademikImages): ?>
    <section class="video-admin-panel">
      <div class="dash-panel">
        <h4>Foto Halaman Akademik</h4>
        <p class="video-admin-note">Ganti foto program keahlian dan logo Teaching Factory. Pilih foto JPG, PNG, atau WebP maksimal 5 MB. Bagian yang tidak diunggah akan tetap menggunakan foto saat ini.</p>
        <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=akademik_images" class="video-admin-form">
          <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
          <input type="hidden" name="aksi" value="simpan_gambar_akademik">
          <div class="video-admin-list">
            <?php foreach ($akademikImageSlots as $slotKey => $slot): ?>
              <?php $previewPath = $akademikImagePaths[$slotKey] ?? $slot['default']; ?>
              <article class="video-admin-card">
                <div class="video-admin-thumbnail"><img src="<?= site_media_html($previewPath) ?>" alt="<?= h($slot['label']) ?>"></div>
                <div class="video-admin-card-body">
                  <h5><?= h($slot['label']) ?></h5>
                  <label>Ganti foto (kosongkan untuk mempertahankan foto saat ini)
                    <input type="file" name="image_<?= h($slotKey) ?>" accept="image/jpeg,image/png,image/webp">
                  </label>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
          <button type="submit" class="btn btn-gold">Simpan Foto Akademik</button>
        </form>
      </div>
    </section>
    <?php elseif ($isMedia): ?>
    <section class="video-admin-panel">
      <div class="dash-panel">
        <h4>Tambah Media Halaman</h4>
        <p class="video-admin-note">Unggah foto untuk halaman Kunjungan Industri atau Mitra Kerja Sama. Format JPG, PNG, atau WebP maksimal 5 MB. Foto aktif langsung tampil pada halaman tujuan.</p>
        <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=media" class="video-admin-form">
          <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
          <input type="hidden" name="aksi" value="tambah">
          <div class="video-form-grid">
            <label>Judul / keterangan foto *
              <input type="text" name="title" maxlength="200" required>
            </label>
            <label>Halaman tujuan *
              <select name="page_key" required>
                <option value="kunjungan_industri">Kunjungan Industri</option>
                <option value="mitra_kerja">Mitra Kerja Sama</option>
              </select>
            </label>
            <label>Foto *
              <input type="file" name="image" accept="image/jpeg,image/png,image/webp" required>
            </label>
            <label>Status publikasi *
              <select name="status"><option value="aktif">Aktif</option><option value="nonaktif">Nonaktif</option></select>
            </label>
          </div>
          <button type="submit" class="btn btn-gold">Simpan Media</button>
        </form>
      </div>

      <div class="dash-panel">
        <h4>Daftar Media (<?= count($pageMediaItems) ?>)</h4>
        <?php if (!$pageMediaItems): ?>
          <p class="video-admin-note">Belum ada media. Tambahkan foto menggunakan formulir di atas.</p>
        <?php else: ?>
          <div class="video-admin-list">
            <?php foreach ($pageMediaItems as $item): ?>
              <article class="video-admin-card">
                <div class="video-admin-thumbnail"><img src="<?= site_media_html($item['image_path']) ?>" alt=""></div>
                <div class="video-admin-card-body">
                  <h5><?= h($item['title']) ?></h5>
                  <div class="video-admin-meta">
                    <span><?= $item['page_key'] === 'kunjungan_industri' ? 'Kunjungan Industri' : 'Mitra Kerja Sama' ?></span>
                    <span class="<?= $item['status'] === 'aktif' ? 'video-status-active' : 'video-status-inactive' ?>"><?= $item['status'] === 'aktif' ? 'Aktif' : 'Nonaktif' ?></span>
                  </div>
                  <details class="video-edit-details">
                    <summary>Edit Media</summary>
                    <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=media" class="video-admin-form">
                      <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
                      <input type="hidden" name="aksi" value="edit">
                      <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                      <div class="video-form-grid">
                        <label>Judul / keterangan foto *
                          <input type="text" name="title" maxlength="200" value="<?= h($item['title']) ?>" required>
                        </label>
                        <label>Halaman tujuan *
                          <select name="page_key">
                            <option value="kunjungan_industri" <?= $item['page_key'] === 'kunjungan_industri' ? 'selected' : '' ?>>Kunjungan Industri</option>
                            <option value="mitra_kerja" <?= $item['page_key'] === 'mitra_kerja' ? 'selected' : '' ?>>Mitra Kerja Sama</option>
                          </select>
                        </label>
                        <label>Ganti foto (kosongkan untuk mempertahankan foto saat ini)
                          <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
                        </label>
                        <label>Status publikasi *
                          <select name="status"><option value="aktif" <?= $item['status'] === 'aktif' ? 'selected' : '' ?>>Aktif</option><option value="nonaktif" <?= $item['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option></select>
                        </label>
                      </div>
                      <button type="submit" class="btn btn-gold">Simpan Perubahan</button>
                    </form>
                    <form method="post" action="admin-kelola.php?entity=media" class="video-delete-form" onsubmit="return confirm('Hapus media ini?');">
                      <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
                      <input type="hidden" name="aksi" value="hapus">
                      <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                      <button type="submit">Hapus Media</button>
                    </form>
                  </details>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <?php elseif ($isPageImages): ?>
    <section class="video-admin-panel">
      <div class="dash-panel">
        <h4>Foto Beranda &amp; Profil</h4>
        <p class="video-admin-note">Pilih foto yang sudah ada di Galeri untuk setiap bagian. Pilihan disimpan dan akan langsung tampil di situs. Pilih “Otomatis sesuai judul” untuk kembali ke pemilihan foto otomatis.</p>
        <?php if (!$galleryImages): ?>
          <p class="video-admin-note">Belum ada foto di Galeri. Tambahkan foto melalui tab Galeri Foto terlebih dahulu.</p>
        <?php else: ?>
          <form method="post" action="admin-kelola.php?entity=page_images" class="video-admin-form">
            <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
            <input type="hidden" name="aksi" value="simpan_gambar_halaman">
            <?php foreach (['home' => 'Halaman Beranda', 'profile' => 'Halaman Profil'] as $group => $groupLabel): ?>
              <h4 style="margin:24px 0 14px;"><?= h($groupLabel) ?></h4>
              <div class="video-admin-list">
                <?php foreach ($pageImageSlots as $slotKey => $slot):
                    if (!str_starts_with($slotKey, $group . '_')) {
                        continue;
                    }
                    $selectedId = $pageImageSelections[$slotKey] ?? null;
                    $previewPath = gallery_image_for_display($galleryImages, $pageImageSelections, $slotKey, $slot['category'], $slot['keywords'], 'assets/img/gedung-infokom.jpg');
                ?>
                  <article class="video-admin-card">
                    <div class="video-admin-thumbnail">
                      <img src="<?= site_media_html($previewPath) ?>" alt="">
                    </div>
                    <div class="video-admin-card-body">
                      <h5><?= h($slot['label']) ?></h5>
                      <label>Foto Galeri
                        <select name="images[<?= h($slotKey) ?>]">
                          <option value="">Otomatis sesuai judul</option>
                          <?php foreach ($galleryImages as $image): ?>
                            <option value="<?= (int) $image['id'] ?>" <?= $selectedId === (int) $image['id'] ? 'selected' : '' ?>>
                              <?= h($image['judul']) ?> (<?= h(ucfirst($image['kategori'])) ?>)
                            </option>
                          <?php endforeach; ?>
                        </select>
                      </label>
                    </div>
                  </article>
                <?php endforeach; ?>
              </div>
            <?php endforeach; ?>
            <button type="submit" class="btn btn-gold" style="margin-top:20px;">Simpan Pengaturan Foto</button>
          </form>
        <?php endif; ?>
      </div>
    </section>
    <?php elseif ($isJapanGallery): ?>
    <section class="video-admin-panel japan-gallery-admin">
      <div class="dash-panel">
        <h4>Tambah Konten Galeri Magang Jepang</h4>
        <p class="video-admin-note">Tambahkan foto, video lokal, video YouTube, atau teks. Gambar maksimal 5 MB dan video lokal maksimal 100 MB.</p>
        <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=japan_gallery" class="video-admin-form japan-gallery-form">
          <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
          <input type="hidden" name="aksi" value="tambah">
          <div class="video-form-grid">
            <label>Judul / heading *
              <input type="text" name="title" maxlength="200" required>
            </label>
            <label>Jenis konten *
              <select name="item_type" class="japan-gallery-type">
                <option value="image">Gambar</option>
                <option value="upload">Video dari komputer</option>
                <option value="youtube">Video YouTube</option>
                <option value="text">Teks saja</option>
              </select>
            </label>
            <label class="japan-gallery-image">Gambar *
              <input type="file" name="image" accept="image/jpeg,image/png,image/webp" required>
            </label>
            <label class="japan-gallery-video" hidden>File video *
              <input type="file" name="video" accept="video/mp4,video/webm,video/ogg" disabled>
            </label>
            <label class="japan-gallery-youtube" hidden>URL YouTube *
              <input type="url" name="youtube_url" placeholder="https://www.youtube.com/watch?v=..." disabled>
            </label>
            <label class="video-description-field">Teks / deskripsi
              <textarea name="description" rows="3" maxlength="5000"></textarea>
            </label>
            <label>Status publikasi *
              <select name="status"><option value="aktif">Aktif</option><option value="nonaktif">Nonaktif</option></select>
            </label>
          </div>
          <button type="submit" class="btn btn-gold">Simpan Konten</button>
        </form>
      </div>

      <div class="dash-panel">
        <h4>Konten Galeri Magang Jepang (<?= count($japanGalleryItems) ?>)</h4>
        <?php if (!$japanGalleryItems): ?>
          <p class="video-admin-note">Belum ada konten tambahan pada galeri Magang Jepang.</p>
        <?php else: ?>
          <div class="video-admin-list">
            <?php foreach ($japanGalleryItems as $item): ?>
              <article class="video-admin-card">
                <div class="video-admin-thumbnail">
                  <?php if ($item['item_type'] === 'image' && $item['image_path']): ?>
                    <img src="<?= h($item['image_path']) ?>" alt="">
                  <?php elseif ($item['item_type'] === 'youtube' && $item['youtube_id']): ?>
                    <img src="<?= h('https://img.youtube.com/vi/' . rawurlencode($item['youtube_id']) . '/hqdefault.jpg') ?>" alt="">
                  <?php else: ?>
                    <span><?= ['upload' => 'Video lokal', 'youtube' => 'Video YouTube', 'text' => 'Konten teks'][$item['item_type']] ?? 'Gambar' ?></span>
                  <?php endif; ?>
                </div>
                <div class="video-admin-card-body">
                  <h5><?= h($item['title']) ?></h5>
                  <p><?= h($item['description'] ?: 'Tanpa deskripsi') ?></p>
                  <div class="video-admin-meta">
                    <span><?= ['image' => 'Gambar', 'upload' => 'Video lokal', 'youtube' => 'YouTube', 'text' => 'Teks'][$item['item_type']] ?? 'Konten' ?></span>
                    <span class="<?= $item['status'] === 'aktif' ? 'video-status-active' : 'video-status-inactive' ?>"><?= $item['status'] === 'aktif' ? 'Aktif' : 'Nonaktif' ?></span>
                  </div>
                  <details class="video-edit-details">
                    <summary>Edit Konten</summary>
                    <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=japan_gallery" class="video-admin-form japan-gallery-form">
                      <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
                      <input type="hidden" name="aksi" value="edit">
                      <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                      <div class="video-form-grid">
                        <label>Judul / heading *
                          <input type="text" name="title" maxlength="200" value="<?= h($item['title']) ?>" required>
                        </label>
                        <label>Jenis konten *
                          <select name="item_type" class="japan-gallery-type" data-existing-type="<?= h($item['item_type']) ?>">
                            <option value="image" <?= $item['item_type'] === 'image' ? 'selected' : '' ?>>Gambar</option>
                            <option value="upload" <?= $item['item_type'] === 'upload' ? 'selected' : '' ?>>Video dari komputer</option>
                            <option value="youtube" <?= $item['item_type'] === 'youtube' ? 'selected' : '' ?>>Video YouTube</option>
                            <option value="text" <?= $item['item_type'] === 'text' ? 'selected' : '' ?>>Teks saja</option>
                          </select>
                        </label>
                        <label class="japan-gallery-image">Ganti gambar (kosongkan untuk mempertahankan)
                          <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
                        </label>
                        <label class="japan-gallery-video" hidden>Ganti video (kosongkan untuk mempertahankan)
                          <input type="file" name="video" accept="video/mp4,video/webm,video/ogg" disabled>
                        </label>
                        <label class="japan-gallery-youtube" hidden>URL YouTube *
                          <input type="url" name="youtube_url" value="<?= $item['item_type'] === 'youtube' ? h('https://www.youtube.com/watch?v=' . $item['youtube_id']) : '' ?>" placeholder="https://www.youtube.com/watch?v=..." disabled>
                        </label>
                        <label class="video-description-field">Teks / deskripsi
                          <textarea name="description" rows="3" maxlength="5000"><?= h($item['description']) ?></textarea>
                        </label>
                        <label>Status publikasi *
                          <select name="status"><option value="aktif" <?= $item['status'] === 'aktif' ? 'selected' : '' ?>>Aktif</option><option value="nonaktif" <?= $item['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option></select>
                        </label>
                      </div>
                      <button type="submit" class="btn btn-gold">Simpan Perubahan</button>
                    </form>
                    <form method="post" action="admin-kelola.php?entity=japan_gallery" class="video-delete-form" onsubmit="return confirm('Hapus konten galeri ini?');">
                      <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
                      <input type="hidden" name="aksi" value="hapus">
                      <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                      <button type="submit">Hapus Konten</button>
                    </form>
                  </details>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <?php elseif ($isVideo): ?>
    <section class="video-admin-panel">
      <div class="dash-panel">
        <h4>Tambah Video</h4>
        <p class="video-admin-note">Unggah MP4, WebM, atau Ogg hingga 100 MB, atau gunakan URL YouTube. Thumbnail JPG, PNG, atau WebP hingga 5 MB. Video dan thumbnail yang diunggah disimpan di server dan tetap tersedia setelah browser ditutup.</p>
        <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=video" class="video-admin-form">
          <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
          <input type="hidden" name="aksi" value="tambah">
          <div class="video-form-grid">
            <label>Judul video *
              <input type="text" name="title" maxlength="200" required>
            </label>
            <label>Sumber video *
              <select name="source_type" class="video-source-select">
                <option value="upload">Unggah file video</option>
                <option value="youtube">URL YouTube</option>
              </select>
            </label>
            <label class="video-source-upload">File video *
              <input type="file" name="video" accept="video/mp4,video/webm,video/ogg" required>
            </label>
            <label class="video-source-youtube" hidden>URL YouTube *
              <input type="url" name="youtube_url" placeholder="https://www.youtube.com/watch?v=..." disabled>
            </label>
            <label>Thumbnail (opsional)
              <input type="file" name="thumbnail" accept="image/jpeg,image/png,image/webp">
            </label>
            <label>Status publikasi *
              <select name="status"><option value="nonaktif">Nonaktif</option><option value="aktif">Aktif</option></select>
            </label>
            <label class="video-description-field">Deskripsi (opsional)
              <textarea name="description" rows="3" maxlength="5000"></textarea>
            </label>
          </div>
          <button type="submit" class="btn btn-gold">Simpan Video</button>
        </form>
      </div>

      <div class="dash-panel">
        <h4>Daftar Video (<?= count($videos) ?>)</h4>
        <?php if (!$videos): ?>
          <p class="video-admin-note">Belum ada video. Video berstatus aktif akan ditampilkan di halaman Galeri.</p>
        <?php else: ?>
          <div class="video-admin-list">
            <?php foreach ($videos as $video): ?>
              <article class="video-admin-card">
                <div class="video-admin-thumbnail">
                  <?php if ($video['thumbnail_path']): ?>
                    <img src="<?= h($video['thumbnail_path']) ?>" alt="">
                  <?php else: ?>
                    <span>Video <?= $video['source_type'] === 'youtube' ? 'YouTube' : 'lokal' ?></span>
                  <?php endif; ?>
                </div>
                <div class="video-admin-card-body">
                  <h5><?= h($video['title']) ?></h5>
                  <p><?= h($video['description'] ?: 'Tanpa deskripsi') ?></p>
                  <div class="video-admin-meta">
                    <span><?= $video['source_type'] === 'youtube' ? 'YouTube' : 'Video lokal' ?></span>
                    <span class="<?= $video['status'] === 'aktif' ? 'video-status-active' : 'video-status-inactive' ?>"><?= $video['status'] === 'aktif' ? 'Aktif' : 'Nonaktif' ?></span>
                  </div>
                  <details class="video-edit-details">
                    <summary>Edit Video</summary>
                    <form method="post" enctype="multipart/form-data" action="admin-kelola.php?entity=video" class="video-admin-form">
                      <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
                      <input type="hidden" name="aksi" value="edit">
                      <input type="hidden" name="id" value="<?= (int) $video['id'] ?>">
                      <div class="video-form-grid">
                        <label>Judul video *
                          <input type="text" name="title" maxlength="200" value="<?= h($video['title']) ?>" required>
                        </label>
                        <label>Sumber video *
                          <select name="source_type" class="video-source-select">
                            <option value="upload" <?= $video['source_type'] === 'upload' ? 'selected' : '' ?>>Unggah file video</option>
                            <option value="youtube" <?= $video['source_type'] === 'youtube' ? 'selected' : '' ?>>URL YouTube</option>
                          </select>
                        </label>
                        <label class="video-source-upload">Ganti file video (kosongkan untuk mempertahankan file saat ini)
                          <input type="file" name="video" accept="video/mp4,video/webm,video/ogg">
                        </label>
                        <label class="video-source-youtube" hidden>URL YouTube *
                          <input type="url" name="youtube_url" value="<?= $video['source_type'] === 'youtube' ? h('https://www.youtube.com/watch?v=' . $video['youtube_id']) : '' ?>" placeholder="https://www.youtube.com/watch?v=..." disabled>
                        </label>
                        <label>Ganti thumbnail (kosongkan untuk mempertahankan)
                          <input type="file" name="thumbnail" accept="image/jpeg,image/png,image/webp">
                        </label>
                        <label>Status publikasi *
                          <select name="status"><option value="nonaktif" <?= $video['status'] === 'nonaktif' ? 'selected' : '' ?>>Nonaktif</option><option value="aktif" <?= $video['status'] === 'aktif' ? 'selected' : '' ?>>Aktif</option></select>
                        </label>
                        <label class="video-description-field">Deskripsi (opsional)
                          <textarea name="description" rows="3" maxlength="5000"><?= h($video['description']) ?></textarea>
                        </label>
                      </div>
                      <button type="submit" class="btn btn-gold">Simpan Perubahan</button>
                    </form>
                    <form method="post" action="admin-kelola.php?entity=video" class="video-delete-form" onsubmit="return confirm('Hapus video ini? File video dan thumbnail yang diunggah juga akan dihapus.');">
                      <input type="hidden" name="csrf_token" value="<?= h(video_csrf_token()) ?>">
                      <input type="hidden" name="aksi" value="hapus">
                      <input type="hidden" name="id" value="<?= (int) $video['id'] ?>">
                      <button type="submit">Hapus Video</button>
                    </form>
                  </details>
                </div>
              </article>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </section>
    <?php else: ?>
    <div class="dash-panel reveal">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
        <h4 style="margin:0;font-size:16px;"><?= h($entity['label']) ?> (<?= count($rows) ?>)</h4>
        <button type="button" class="btn btn-navy" style="padding:10px 18px;" onclick="openAddModal()">+ Tambah <?= h($entity['label_singular']) ?></button>
      </div>
      <div style="overflow-x:auto;">
        <table class="data-table">
          <thead>
            <tr>
              <?php foreach ($entity['list_cols'] as $col): ?>
                <th><?= h($entity['fields'][$col]['label'] ?? ucfirst($col)) ?></th>
              <?php endforeach; ?>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if (!$rows): ?>
              <tr><td colspan="<?= count($entity['list_cols']) + 1 ?>" style="text-align:center;color:var(--muted);">Belum ada data.</td></tr>
            <?php endif; ?>
            <?php foreach ($rows as $row): ?>
              <tr>
                <?php foreach ($entity['list_cols'] as $col):
                    $def = $entity['fields'][$col] ?? null;
                ?>
                  <td>
                    <?php if ($def && $def['type'] === 'image'): ?>
                      <?php if (!empty($row[$col])): ?>
                        <img src="<?= site_media_html((string) $row[$col]) ?>" style="width:44px;height:44px;object-fit:cover;border-radius:6px;">
                      <?php else: ?>
                        <span style="color:var(--muted);font-size:12px;">&mdash;</span>
                      <?php endif; ?>
                    <?php elseif ($def && $def['type'] === 'select_query'):
                        $stmt2 = $pdo->prepare('SELECT nama FROM siswa WHERE id = ?');
                        $stmt2->execute([$row[$col]]);
                        echo h($stmt2->fetchColumn() ?: '-');
                    else:
                        echo h((string)($row[$col] ?? '-'));
                    endif; ?>
                  </td>
                <?php endforeach; ?>
                <td style="white-space:nowrap;">
                  <a href="#" onclick='openEditModal(<?= json_encode($row) ?>); return false;' style="color:var(--navy);font-weight:600;font-size:13px;margin-right:12px;">Edit</a>
                  <form method="post" style="display:inline;" onsubmit="return confirm('Hapus data ini?');">
                    <input type="hidden" name="aksi" value="hapus">
                    <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                    <button type="submit" style="color:#A6192E;font-weight:600;font-size:13px;background:none;border:none;cursor:pointer;padding:0;">Hapus</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
    <?php endif; ?>
  </div>
</div>

<?php if (!$isVideo && !$isJapanGallery && !$isPageImages && !$isMedia): ?>
<div class="modal-overlay" id="crudModal">
  <div class="modal-box">
    <button class="modal-close" onclick="document.getElementById('crudModal').classList.remove('open')">&times;</button>
    <h4 id="crudFormTitle">Tambah <?= h($entity['label_singular']) ?></h4>
    <form id="crudForm" method="post" enctype="multipart/form-data" style="margin-top:16px;">
      <input type="hidden" name="aksi" id="crudAksi" value="tambah">
      <input type="hidden" name="id" id="crudId" value="">
      <?php foreach ($entity['fields'] as $key => $def):
          $required = !empty($def['required']) ? 'required' : '';
      ?>
        <div class="form-field full">
          <label><?= h($def['label']) ?><?= $required ? ' *' : '' ?></label>
          <?php if ($def['type'] === 'textarea'): ?>
            <textarea name="<?= h($key) ?>" <?= $required ?> placeholder="<?= h($def['placeholder'] ?? '') ?>"></textarea>
          <?php elseif ($def['type'] === 'select'): ?>
            <select name="<?= h($key) ?>" <?= $required ?>>
              <?php foreach ($def['options'] as $optVal => $optLabel): ?>
                <option value="<?= h($optVal) ?>"><?= h($optLabel) ?></option>
              <?php endforeach; ?>
            </select>
          <?php elseif ($def['type'] === 'select_query'):
              $opts = $pdo->query($def['query'])->fetchAll();
          ?>
            <select name="<?= h($key) ?>" <?= $required ?>>
              <?php foreach ($opts as $opt): ?>
                <option value="<?= h((string)$opt['id']) ?>"><?= h($opt['nama']) ?></option>
              <?php endforeach; ?>
            </select>
          <?php elseif ($def['type'] === 'image'): ?>
            <input type="file" name="<?= h($key) ?>" accept="image/*">
          <?php elseif ($def['type'] === 'number'): ?>
            <input type="number" step="<?= h($def['step'] ?? '1') ?>" name="<?= h($key) ?>" <?= $required ?>>
          <?php elseif ($def['type'] === 'date'): ?>
            <input type="date" name="<?= h($key) ?>" <?= $required ?>>
          <?php elseif ($isVideo || $isJapanGallery): ?>
            <input type="text" name="<?= h($key) ?>" <?= $required ?> placeholder="<?= h($def['placeholder'] ?? '') ?>">
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
      <button type="submit" class="btn btn-gold ppdb-submit" style="margin-top:14px;">Simpan</button>
    </form>
  </div>
</div>

<script src="assets/main.js"></script>
<script>
function openAddModal(){
  document.getElementById('crudModal').classList.add('open');
  document.getElementById('crudFormTitle').textContent = 'Tambah <?= h($entity['label_singular']) ?>';
  document.getElementById('crudAksi').value = 'tambah';
  document.getElementById('crudId').value = '';
  document.getElementById('crudForm').reset();
}
function openEditModal(row){
  document.getElementById('crudModal').classList.add('open');
  document.getElementById('crudFormTitle').textContent = 'Edit <?= h($entity['label_singular']) ?>';
  document.getElementById('crudAksi').value = 'edit';
  document.getElementById('crudId').value = row.id;
  const form = document.getElementById('crudForm');
  Object.keys(row).forEach(function(key){
    const field = form.elements[key];
    if (!field || field.type === 'file') return;
    field.value = row[key] ?? '';
  });
}
</script>
<?php else: ?>
<script>
document.querySelectorAll('.video-source-select').forEach(function(select) {
  function updateSourceFields() {
    const form = select.closest('form');
    const isYouTube = select.value === 'youtube';
    form.querySelectorAll('.video-source-upload').forEach(function(field) {
      field.hidden = isYouTube;
      const input = field.querySelector('input[type="file"]');
      input.required = !isYouTube && input.dataset.required === 'true';
      input.disabled = isYouTube;
    });
    form.querySelectorAll('.video-source-youtube').forEach(function(field) {
      field.hidden = !isYouTube;
      const input = field.querySelector('input');
      input.disabled = !isYouTube;
      input.required = isYouTube;
    });
  }
  const videoInput = select.closest('form').querySelector('.video-source-upload input[type="file"]');
  videoInput.dataset.required = videoInput.required ? 'true' : 'false';
  select.addEventListener('change', updateSourceFields);
  updateSourceFields();
});

document.querySelectorAll('.japan-gallery-type').forEach(function(select) {
  const form = select.closest('form');
  const existingType = select.dataset.existingType || '';
  const isNew = form.elements.aksi.value === 'tambah';
  const fields = {
    image: form.querySelector('.japan-gallery-image input[type="file"]'),
    upload: form.querySelector('.japan-gallery-video input[type="file"]'),
    youtube: form.querySelector('.japan-gallery-youtube input')
  };
  Object.keys(fields).forEach(function(type) {
    if (fields[type]) fields[type].dataset.requiredOnSelect = fields[type].required ? 'true' : 'false';
  });
  function updateGalleryFields() {
    const selectedType = select.value;
    ['image', 'upload', 'youtube'].forEach(function(type) {
      const wrapper = form.querySelector('.japan-gallery-' + (type === 'upload' ? 'video' : type));
      const input = fields[type];
      if (!wrapper || !input) return;
      const active = selectedType === type;
      wrapper.hidden = !active;
      input.disabled = !active;
      if (type === 'youtube') {
        input.required = active;
      } else {
        input.required = active && (isNew || (existingType !== '' && existingType !== selectedType));
      }
    });
    const description = form.elements.description;
    description.required = selectedType === 'text';
  }
  select.addEventListener('change', updateGalleryFields);
  updateGalleryFields();
});
</script>
<?php endif; ?>
</body>
</html>
