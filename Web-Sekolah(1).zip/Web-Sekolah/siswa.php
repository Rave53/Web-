<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';

$achievementsQuery = $pdo->prepare(
    "SELECT judul, ringkasan, tanggal, foto FROM berita WHERE kategori = ? ORDER BY tanggal DESC, id DESC LIMIT 12"
);
$achievementsQuery->execute(['prestasi']);
$achievements = $achievementsQuery->fetchAll();
$alumniCount = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'alumni'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Alumni &amp; Prestasi Siswa | SMK Infokom Bogor</title>
<meta name="description" content="Berita prestasi siswa dan informasi alumni SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="portal-login-header">
  <div class="wrap">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <a href="portal.php" class="portal-back-link">Portal</a>
  </div>
</header>
<main class="portal-public-page">
  <section class="portal-public-hero">
    <div class="wrap">
      <span class="eyebrow">Keluarga Besar Infokom</span>
      <h1>Alumni &amp; Prestasi Siswa</h1>
      <p>Merayakan pencapaian siswa dan menjaga hubungan dengan alumni SMK Infokom Bogor.</p>
      <div class="portal-alumni-count"><strong><?= $alumniCount ?></strong><span>akun alumni terdaftar</span></div>
    </div>
  </section>
  <section class="portal-public-content">
    <div class="wrap">
      <div class="portal-panel-heading"><div><span class="eyebrow">Kabar sekolah</span><h2>Prestasi Siswa</h2></div></div>
      <?php if ($achievements === []): ?>
        <section class="portal-panel portal-empty-copy">Belum ada berita prestasi yang dipublikasikan.</section>
      <?php else: ?>
        <div class="portal-achievement-grid">
          <?php foreach ($achievements as $achievement): ?>
            <article class="portal-achievement-card">
              <?php if ($achievement['foto'] !== null && $achievement['foto'] !== ''): ?>
                <img src="<?= site_media_html($achievement['foto']) ?>" alt="" loading="lazy">
              <?php endif; ?>
              <div class="portal-achievement-copy">
                <span class="portal-label"><?= h(date('d M Y', strtotime($achievement['tanggal']))) ?></span>
                <h3><?= h($achievement['judul']) ?></h3>
                <p><?= h($achievement['ringkasan'] ?? '') ?></p>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
      <section class="portal-panel portal-alumni-panel">
        <div><span class="eyebrow">Tetap terhubung</span><h2>Untuk Alumni</h2><p>Alumni dapat masuk ke layanan Bursa Kerja Khusus untuk melengkapi profil dan menemukan informasi karier.</p></div>
        <a class="btn btn-gold" href="bkk.php">Kunjungi BKK</a>
      </section>
    </div>
  </section>
</main>
</body>
</html>
