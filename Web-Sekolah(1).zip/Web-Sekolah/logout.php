<?php
require_once __DIR__ . '/includes/auth.php';

$role = current_user()['role'] ?? null;
$_SESSION = [];
session_destroy();

$target = match ($role) {
    'admin', 'admin_bkk' => 'admin-login.php',
    'siswa', 'alumni' => 'portal-siswa-login.php',
    'ortu'  => 'portal-ortu-login.php',
    default => 'portal.php',
};
header('Location: ' . $target);
exit;
