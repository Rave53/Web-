<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/page_media.php';
function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

$kunjunganMedia = page_media_items('kunjungan_industri');
$mitraMedia = page_media_items('mitra_kerja');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Kunjungan Industri | SMK Infokom Bogor</title>
<meta name="description" content="Dokumentasi kegiatan Kunjungan Industri SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility"><div class="wrap"><a href="profil.php">Kunjungi Kami</a><a href="ppdb.php">Daftar PPDB</a><a href="portal.php">Portal Siswa &amp; Orang Tua</a></div></div>
<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand"><span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span><span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span></a>
    <div class="nav-links">
      <a href="profil.php" class="nav-link">Profil</a><a href="guru.php" class="nav-link">Guru</a><a href="akademik.php" class="nav-link">Akademik</a><a href="bkk.php" class="nav-link">BKK</a><a href="info.php" class="nav-link">Info &amp; Berita</a><a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta"><a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a><a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a><button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button></div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div><a href="profil.php">Profil &amp; Sejarah</a><a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  <div class="m-group">Akademik</div><a href="akademik.php">Program Keahlian</a><a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  <div class="m-group">Lainnya</div><a href="ppdb.php">PPDB</a><a href="info.php">Info &amp; Berita</a><a href="kontak.php">Kontak</a>
</div>
<header class="page-hero"><div class="wrap"><div class="crumb"><a href="index.php">Beranda</a> / <a href="bkk.php">BKK</a> / Kunjungan Industri</div><h1 class="split">Kunjungan Industri</h1></div></header>
<main>
  <section class="mitra-list-section">
    <div class="wrap">
      <div class="section-head reveal"><div><div class="eyebrow">Dokumentasi</div><h2 class="split">Kegiatan Kunjungan Industri</h2></div></div>
      <div class="kunjungan-gallery reveal" data-stagger>
        <?php if ($kunjunganMedia): ?>
          <?php foreach ($kunjunganMedia as $item): ?>
            <figure class="page-media-card"><img src="<?= site_media_html($item['image_path']) ?>" alt="<?= h($item['title']) ?>" loading="lazy"><figcaption><?= h($item['title']) ?></figcaption></figure>
          <?php endforeach; ?>
        <?php else: ?>
          <figure><img src="<?= site_media_html('https://images.pexels.com/photos/10638115/pexels-photo-10638115.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=700') ?>" alt="Siswa belajar di lingkungan kerja" loading="lazy"></figure>
          <figure><img src="<?= site_media_html('https://images.pexels.com/photos/17115909/pexels-photo-17115909.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=600') ?>" alt="Kegiatan pembelajaran bersama mitra industri" loading="lazy"></figure>
          <figure><img src="<?= site_media_html('https://images.pexels.com/photos/4818711/pexels-photo-4818711.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=600') ?>" alt="Siswa mengamati kegiatan kerja" loading="lazy"></figure>
          <figure><img src="<?= site_media_html('https://images.pexels.com/photos/10638068/pexels-photo-10638068.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=600') ?>" alt="Pengalaman belajar di tempat kerja" loading="lazy"></figure>
        <?php endif; ?>
      </div>
    </div>
  </section>
  <?php if ($mitraMedia): ?>
  <section class="mitra-list-section" style="padding-top:0;">
    <div class="wrap">
      <div class="section-head reveal"><div><div class="eyebrow">Dokumentasi kemitraan</div><h2 class="split">Foto Mitra Kerja Sama</h2></div></div>
      <div class="kunjungan-gallery reveal" data-stagger>
        <?php foreach ($mitraMedia as $item): ?>
          <figure class="page-media-card"><img src="<?= site_media_html($item['image_path']) ?>" alt="<?= h($item['title']) ?>" loading="lazy"><figcaption><?= h($item['title']) ?></figcaption></figure>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>
</main>
<footer class="footer"><div class="wrap"><div class="foot-top"><div class="foot-logo"><div class="brand"><span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span><span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span></div><p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p></div><a href="kontak.php" class="btn btn-line">Kontak Kami</a></div></div></footer>
<script src="assets/main.js"></script>
</body>
</html>
