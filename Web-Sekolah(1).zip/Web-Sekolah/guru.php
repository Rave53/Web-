<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/config.php';
if (!function_exists('h')) { function h(?string $v): string { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); } }
$guruList = $pdo->query("SELECT * FROM guru ORDER BY
  CASE
    WHEN jabatan LIKE 'Kepala Sekolah%' THEN 1
    WHEN jabatan LIKE 'Wakil Kepala Sekolah%' THEN 2
    WHEN jabatan LIKE 'Ketua Manajemen Mutu%' THEN 3
    WHEN jabatan LIKE 'Kepala Program Keahlian%' THEN 4
    WHEN jabatan LIKE 'Kepala Tata Usaha%' OR jabatan LIKE 'Kepala Perpustakaan%' OR jabatan LIKE 'Kepala Bendahara%' THEN 5
    WHEN jabatan LIKE 'Pembina%' THEN 6
    WHEN jabatan LIKE 'Staf%' THEN 7
    WHEN jabatan LIKE 'Guru%' THEN 8
    ELSE 9
  END, jabatan, nama")->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Guru & Tenaga Pendidik | SMK Infokom Bogor</title>
<meta name="description" content="Profil guru dan tenaga pendidik SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Kunjungi Kami</a>
    <a href="ppdb.php">Daftar PPDB</a>
    <a href="portal.php">Portal Siswa &amp; Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil &amp; Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi &amp; Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer &amp; Jaringan</a>
            <a href="akademik.php">DKV (Desain Komunikasi Visual)</a>
            <a href="akademik.php">PSPT</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas &amp; Laboratorium</a>
            
            
            
  <a href="portal-siswa-login.php">Portal Siswa</a>
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil &amp; Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi &amp; Misi</a>
  <a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info &amp; Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / Tentang Kami</div>
    <h1 class="split">Guru & Tenaga Pendidik</h1>
    <p>Diajar oleh pendidik yang juga aktif di industrinya masing-masing.</p>
  </div>
</header>

<section class="news" id="guru" style="background:var(--sky);">
  <div class="wrap">
    <div class="section-head reveal" style="max-width:640px;margin-bottom:50px;">
      <div class="eyebrow">Guru &amp; Tenaga Pendidik</div>
      <h2 style="font-size:clamp(26px,3vw,36px);" class="split">Diajar oleh pendidik yang juga aktif di industrinya</h2>
      <p style="margin-top:14px;color:var(--muted);font-size:15.5px;">Sebagian besar pengampu mata pelajaran produktif memiliki pengalaman kerja langsung di bidang yang mereka ajarkan.</p>
    </div>
    <div style="max-width:360px;margin-bottom:20px;position:relative;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style="position:absolute;left:14px;top:50%;transform:translateY(-50%);color:var(--muted);"><circle cx="11" cy="11" r="7" stroke="currentColor" stroke-width="1.8"/><path d="M21 21l-4-4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      <input type="text" id="guruSearch" placeholder="Cari nama guru..." style="width:100%;padding:12px 14px 12px 40px;border:1px solid var(--line);border-radius:6px;font-family:'Inter',sans-serif;font-size:14px;">
    </div>
    <div class="filter-bar" data-filter-bar="#guru-grid">
      <button class="filter-chip active" data-filter="all">Semua</button>
      <button class="filter-chip" data-filter="rpl">RPL</button>
      <button class="filter-chip" data-filter="tkj">TKJ</button>
      <button class="filter-chip" data-filter="dkv">DKV</button>
      <button class="filter-chip" data-filter="pspt">PSPT</button>
      <button class="filter-chip" data-filter="umum">Pimpinan &amp; Staf</button>
    </div>
    <div class="reveal" id="guru-grid" data-stagger style="display:grid;grid-template-columns:repeat(4,1fr);gap:22px;">
      <?php foreach ($guruList as $g): ?>
      <div data-category="<?= h($g['kategori'] ?? 'umum') ?>" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;">
        <div class="guru-photo-frame"><img data-lightbox="<?= h($g['nama']) ?>" src="<?= site_media_html($g['foto'] ?: 'https://images.pexels.com/photos/8617840/pexels-photo-8617840.jpeg?auto=compress&cs=tinysrgb&w=400') ?>" alt="Foto <?= h($g['nama']) ?>" loading="lazy"></div>
        <div style="padding:16px;"><h4 style="font-size:15px;"><?= h($g['nama']) ?></h4><span style="display:block;margin-top:4px;font-size:12.5px;color:var(--muted);"><?= h($g['jabatan'] ?: $g['mapel'] ?: '-') ?></span></div>
      </div>
      <?php endforeach; ?>
      <?php if (!$guruList): ?><p style="color:var(--muted);grid-column:1/-1;">Belum ada data guru.</p><?php endif; ?>
    </div>
    </div>
  </div>
</section>


<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
<script>
document.getElementById('guruSearch').addEventListener('input', function(){
  const q = this.value.trim().toLowerCase();
  document.querySelectorAll('#guru-grid > div').forEach(function(card){
    const name = card.querySelector('h4').textContent.toLowerCase();
    card.style.display = name.includes(q) ? '' : 'none';
  });
});
</script>
</body>
</html>
