<?php
require_once __DIR__ . '/includes/bkk.php';

$user = current_user();
if (!$user) {
    http_response_code(401);
    exit('Silakan masuk untuk membuka dokumen.');
}

$applicantId = (int) ($_GET['applicant'] ?? 0);
$kind = $_GET['kind'] ?? '';
if (!in_array($kind, ['cv', 'sertifikat'], true)) {
    http_response_code(400);
    exit('Jenis dokumen tidak valid.');
}

if (in_array($user['role'], ['admin', 'admin_bkk'], true)) {
    $query = $pdo->prepare("SELECT `$kind` FROM bkk_pelamar WHERE id = ?");
    $query->execute([$applicantId]);
} elseif (in_array($user['role'], ['siswa', 'alumni'], true)) {
    $query = $pdo->prepare("SELECT `$kind` FROM bkk_pelamar WHERE id = ? AND user_id = ?");
    $query->execute([$applicantId, (int) $user['id']]);
} else {
    http_response_code(403);
    exit('Anda tidak memiliki akses ke dokumen ini.');
}

$relativePath = $query->fetchColumn();
$privateDirectory = realpath(__DIR__ . '/uploads/bkk/private');
$filePath = $relativePath ? realpath(__DIR__ . '/' . $relativePath) : false;
if (!$privateDirectory || !$filePath || !str_starts_with($filePath, $privateDirectory . DIRECTORY_SEPARATOR) || !is_file($filePath)) {
    http_response_code(404);
    exit('Dokumen tidak ditemukan.');
}

$mime = (new finfo(FILEINFO_MIME_TYPE))->file($filePath) ?: 'application/octet-stream';
$filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($filePath));
header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($filePath));
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('X-Content-Type-Options: nosniff');
readfile($filePath);
exit;
