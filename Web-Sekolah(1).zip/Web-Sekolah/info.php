<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/videos.php';
require_once __DIR__ . '/config.php';
if (!function_exists('h')) { function h(?string $v): string { return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8'); } }
$beritaList = $pdo->query('SELECT * FROM berita ORDER BY tanggal DESC')->fetchAll();
$videoList = $pdo->query("SELECT id, title, description, source_type, video_path, youtube_id, thumbnail_path FROM videos WHERE status = 'aktif' ORDER BY created_at DESC, id DESC")->fetchAll();
$bulanID = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
function tgl_id($tgl) { global $bulanID; $p = explode('-', $tgl); return (int)$p[2] . ' ' . $bulanID[$p[1]] . ' ' . $p[0]; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Info & Berita | SMK Infokom Bogor</title>
<meta name="description" content="Berita, kabar, dan informasi terbaru dari SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Kunjungi Kami</a>
    <a href="ppdb.php">Daftar PPDB</a>
    <a href="portal.php">Portal Siswa &amp; Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil &amp; Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi &amp; Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer &amp; Jaringan</a>
            <a href="akademik.php">DKV (Desain Komunikasi Visual)</a>
            <a href="akademik.php">PSPT</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas &amp; Laboratorium</a>
            
            
            
  <a href="portal-siswa-login.php">Portal Siswa</a>
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil &amp; Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi &amp; Misi</a>
  <a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info &amp; Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / Info & Berita</div>
    <h1 class="split">Info & Berita</h1>
    <p>Kabar terbaru dan cerita dari lingkungan SMK Infokom Bogor.</p>
  </div>
</header>

<section class="news" id="info">
  <div class="wrap">
    <div class="section-head reveal" style="max-width:640px;margin-bottom:50px;">
      <div class="eyebrow">Kabar &amp; Prestasi</div>
      <h2 style="font-size:clamp(26px,3vw,36px);" class="split">Yang sedang terjadi di SMK Infokom Bogor</h2>
    </div>
    <div class="filter-bar" data-filter-bar="#news-grid">
      <button class="filter-chip active" data-filter="all">Semua</button>
      <button class="filter-chip" data-filter="prestasi">Prestasi</button>
      <button class="filter-chip" data-filter="kegiatan">Kegiatan</button>
      <button class="filter-chip" data-filter="pengumuman">Pengumuman</button>
    </div>
    <div class="news-grid reveal" id="news-grid" data-stagger>
      <?php foreach ($beritaList as $i => $b): ?>
      <div class="news-card<?= $i === 0 ? ' tall' : '' ?>" data-category="<?= h($b['kategori']) ?>">
        <div class="news-img"><img src="<?= site_media_html($b['foto'] ?: 'https://images.pexels.com/photos/10638070/pexels-photo-10638070.jpeg?auto=compress&cs=tinysrgb&w=700') ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div class="news-body"><span style="font-size:12px;color:var(--crimson);font-weight:700;"><?= h(tgl_id($b['tanggal'])) ?></span><h4 style="margin-top:8px;"><?= h($b['judul']) ?></h4><?php if ($b['ringkasan']): ?><p style="margin-top:8px;font-size:13.5px;color:var(--muted);"><?= h($b['ringkasan']) ?></p><?php endif; ?></div>
      </div>
      <?php if ($i === 1): ?>
      <div class="quote-card" data-category="prestasi kegiatan pengumuman">
        <svg class="quote-mark" viewBox="0 0 30 24"><path d="M0 24V12C0 5 4 1 11 0v5C7 6 5 8 5 12h6v12H0zm16 0V12c0-7 4-11 11-12v5c-4 1-6 3-6 7h6v12H16z" fill="currentColor"/></svg>
        <p>Kami tidak hanya mengajarkan siswa cara memakai teknologi, tapi cara berpikir seperti orang yang membangunnya.</p>
        <cite>Kepala Sekolah, Ir. Hj. Liliek Rahmaningsih, M.M.Pd.</cite>
      </div>
      <?php endif; ?>
      <?php endforeach; ?>
      <?php if (!$beritaList): ?><p style="color:var(--muted);">Belum ada berita.</p><?php endif; ?>
    </div>
  </div>
</section>

<?php if ($videoList): ?>
<section class="school-video-section" id="video">
  <div class="wrap">
    <div class="section-head">
      <div><span class="eyebrow">Video &amp; dokumentasi</span><h2>Info dalam Video</h2></div>
      <p>Informasi dan dokumentasi terbaru dari SMK Infokom Bogor.</p>
    </div>
    <div class="school-video-grid">
      <?php foreach ($videoList as $video): ?>
        <?php
        $videoId = $video['source_type'] === 'youtube'
            ? video_youtube_id('https://youtu.be/' . (string) $video['youtube_id'])
            : null;
        $videoPath = is_string($video['video_path']) && preg_match('~^uploads/videos/[a-f0-9]{32}\.(?:mp4|webm|ogv)$~', $video['video_path'])
            ? $video['video_path']
            : null;
        $thumbnailPath = is_string($video['thumbnail_path']) && preg_match('~^uploads/video-thumbnails/[a-f0-9]{32}\.(?:jpg|png|webp)$~', $video['thumbnail_path'])
            ? $video['thumbnail_path']
            : null;
        if (($video['source_type'] === 'youtube' && $videoId === null) || ($video['source_type'] === 'upload' && $videoPath === null)) {
            continue;
        }
        ?>
        <article class="school-video-card">
          <div class="school-video-player">
            <?php if ($video['source_type'] === 'youtube'): ?>
              <iframe src="https://www.youtube-nocookie.com/embed/<?= h($videoId) ?>" title="<?= h($video['title']) ?>" loading="lazy" referrerpolicy="strict-origin-when-cross-origin" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
            <?php else: ?>
              <video controls preload="metadata" <?= $thumbnailPath !== null ? 'poster="' . h($thumbnailPath) . '"' : '' ?>>
                <source src="<?= h($videoPath) ?>" type="<?= str_ends_with($videoPath, '.webm') ? 'video/webm' : (str_ends_with($videoPath, '.ogv') ? 'video/ogg' : 'video/mp4') ?>">
                Browser Anda tidak mendukung pemutar video.
              </video>
            <?php endif; ?>
          </div>
          <div class="school-video-copy">
            <h3><?= h($video['title']) ?></h3>
            <?php if ($video['source_type'] === 'youtube' && $thumbnailPath !== null): ?>
              <img src="<?= h($thumbnailPath) ?>" alt="Thumbnail <?= h($video['title']) ?>" loading="lazy" style="display:block;width:100%;max-height:180px;margin-top:12px;border-radius:8px;object-fit:cover;">
            <?php endif; ?>
            <?php if (!empty($video['description'])): ?><p><?= nl2br(h($video['description'])) ?></p><?php endif; ?>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
