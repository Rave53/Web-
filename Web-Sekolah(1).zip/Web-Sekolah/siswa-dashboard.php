<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
$user = require_role('siswa');

$student = null;
$attendance = [];
$attendanceSummary = ['Hadir' => 0, 'Terlambat' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0];
$attendancePercentage = 0;
if ($user['ref_id'] !== null) {
    $studentQuery = $pdo->prepare('SELECT id, nisn, nama, kelas, rata_nilai, peringkat, status_spp FROM siswa WHERE id = ? LIMIT 1');
    $studentQuery->execute([$user['ref_id']]);
    $student = $studentQuery->fetch() ?: null;
    if ($student !== null) {
        $attendanceQuery = $pdo->prepare('SELECT tanggal, jam_masuk, status, keterangan FROM absensi WHERE siswa_id = ? ORDER BY tanggal DESC, id DESC LIMIT 10');
        $attendanceQuery->execute([$student['id']]);
        $attendance = $attendanceQuery->fetchAll();

        $summaryQuery = $pdo->prepare('SELECT status, COUNT(*) AS jumlah FROM absensi WHERE siswa_id = ? GROUP BY status');
        $summaryQuery->execute([$student['id']]);
        $attendanceTotal = 0;
        $attendancePresent = 0;
        foreach ($summaryQuery->fetchAll() as $row) {
            if (array_key_exists($row['status'], $attendanceSummary)) {
                $attendanceSummary[$row['status']] = (int) $row['jumlah'];
                $attendanceTotal += (int) $row['jumlah'];
                if (in_array($row['status'], ['Hadir', 'Terlambat'], true)) {
                    $attendancePresent += (int) $row['jumlah'];
                }
            }
        }
        $attendancePercentage = $attendanceTotal > 0 ? round($attendancePresent / $attendanceTotal * 100, 1) : 0;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard Siswa | SMK Infokom Bogor</title>
<meta name="description" content="Ringkasan akademik dan kehadiran siswa SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="portal-dashboard-body">
<header class="portal-dashboard-header">
  <div class="wrap">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Portal Siswa</span></span>
    </a>
    <div class="portal-header-actions"><span><?= h($user['nama']) ?></span><a class="btn btn-line" href="logout.php">Keluar</a></div>
  </div>
</header>
<main class="portal-dashboard">
  <div class="wrap">
    <div class="portal-welcome">
      <div><span class="eyebrow">Portal Siswa</span><h1>Selamat datang, <?= h($user['nama']) ?></h1><p>Ringkasan akademik dan catatan kehadiran Anda.</p></div>
      <a class="portal-public-link" href="siswa.php">Alumni &amp; Prestasi Siswa <span aria-hidden="true">→</span></a>
    </div>
    <?php if ($student === null): ?>
      <section class="portal-panel portal-empty" role="status">
        <h2>Akun belum terhubung ke data siswa</h2>
        <p>Hubungi administrator sekolah untuk menghubungkan akun ini dengan data siswa.</p>
      </section>
    <?php else: ?>
      <section class="portal-panel portal-student-summary">
        <div><span class="portal-label">Nama</span><strong><?= h($student['nama']) ?></strong></div>
        <div><span class="portal-label">NISN</span><strong><?= h($student['nisn']) ?></strong></div>
        <div><span class="portal-label">Kelas</span><strong><?= h($student['kelas']) ?></strong></div>
        <div><span class="portal-label">Peringkat</span><strong><?= h($student['peringkat']) ?></strong></div>
      </section>
      <section class="portal-stat-grid" aria-label="Ringkasan akademik">
        <article class="portal-stat-card"><span>Rata-rata nilai</span><strong><?= h((string) $student['rata_nilai']) ?></strong></article>
        <article class="portal-stat-card"><span>Kehadiran</span><strong><?= h((string) $attendancePercentage) ?>%</strong></article>
        <article class="portal-stat-card"><span>Status SPP</span><strong><?= h($student['status_spp']) ?></strong></article>
        <article class="portal-stat-card"><span>Total hadir</span><strong><?= $attendanceSummary['Hadir'] ?></strong></article>
      </section>
      <section class="portal-panel">
        <div class="portal-panel-heading"><div><span class="eyebrow">Catatan presensi</span><h2>Riwayat Kehadiran</h2></div><span class="portal-muted">10 catatan terakhir</span></div>
        <?php if ($attendance === []): ?>
          <p class="portal-empty-copy">Belum ada catatan kehadiran untuk akun ini.</p>
        <?php else: ?>
          <div class="portal-table-wrap">
            <table class="portal-table">
              <thead><tr><th>Tanggal</th><th>Jam Masuk</th><th>Status</th><th>Keterangan</th></tr></thead>
              <tbody>
                <?php foreach ($attendance as $record): ?>
                  <tr><td><?= h($record['tanggal']) ?></td><td><?= h($record['jam_masuk'] ?? '-') ?></td><td><span class="portal-status"><?= h($record['status']) ?></span></td><td><?= h($record['keterangan'] ?? '-') ?></td></tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </section>
    <?php endif; ?>
  </div>
</main>
</body>
</html>
