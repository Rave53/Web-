<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/akademik_images.php';
$akademikImageSlots = akademik_image_slots();
$akademikImagePaths = akademik_image_paths();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Akademik | SMK Infokom Bogor</title>
<meta name="description" content="Program keahlian RPL, TKJ, DKV, dan PSPT di SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Kunjungi Kami</a>
    <a href="ppdb.php">Daftar PPDB</a>
    <a href="portal.php">Portal Siswa &amp; Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil &amp; Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi &amp; Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer &amp; Jaringan</a>
            <a href="akademik.php">DKV (Desain Komunikasi Visual)</a>
            <a href="akademik.php">PSPT</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas &amp; Laboratorium</a>
            
            
            
  <a href="portal-siswa-login.php">Portal Siswa</a>
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil &amp; Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi &amp; Misi</a>
  <a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info &amp; Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / Tentang Kami</div>
    <h1 class="split">Akademik & Program Keahlian</h1>
    <p>Empat program keahlian di bidang informatika dan komunikasi, dirancang bersama praktisi industri.</p>
  </div>
</header>

<section class="explore" id="akademik">
  <div class="wrap explore-grid">
    <div class="reveal">
      <div class="eyebrow">Akademik</div>
      <h2 class="split">Jelajahi program keahlian yang tersedia</h2>
      <p>Pilih dari empat program keahlian di bidang informatika dan komunikasi yang dirancang bersama praktisi industri, lengkap dengan jam praktik lebih banyak daripada teori.</p>
      <div class="search-panel">
        <input type="text" placeholder="Cari program keahlian…">
        <button type="button">Cari</button>
      </div>
      <a href="semua-program.php" class="browse-link">Lihat Semua Program <svg width="14" height="14" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="thumb-cluster reveal-right teaching-factory-logo-grid">
      <div class="thumb">
        <img src="<?= site_media_html($akademikImagePaths['factory_rpl'] ?? $akademikImageSlots['factory_rpl']['default']) ?>" alt="Logo Rekayasa Perangkat Lunak" loading="lazy">
      </div>
      <div class="thumb">
        <img src="<?= site_media_html($akademikImagePaths['factory_tkj'] ?? $akademikImageSlots['factory_tkj']['default']) ?>" alt="Logo Teknik Komputer dan Jaringan" loading="lazy">
      </div>
      <div class="thumb">
        <img src="<?= site_media_html($akademikImagePaths['factory_pspt'] ?? $akademikImageSlots['factory_pspt']['default']) ?>" alt="Logo Produksi dan Siaran Program Televisi" loading="lazy">
      </div>
      <div class="thumb">
        <img src="<?= site_media_html($akademikImagePaths['factory_dkv'] ?? $akademikImageSlots['factory_dkv']['default']) ?>" alt="Logo Desain Komunikasi Visual" loading="lazy">
      </div>
    </div>
  </div>
  <div class="wrap" style="margin-top:70px;">
    <div class="filter-bar" data-filter-bar="#jurusan-list">
      <button class="filter-chip active" data-filter="all">Semua Program</button>
      <button class="filter-chip" data-filter="rpl">RPL</button>
      <button class="filter-chip" data-filter="tkj">TKJ</button>
      <button class="filter-chip" data-filter="dkv">DKV</button>
      <button class="filter-chip" data-filter="pspt">PSPT</button>
    </div>
    <div class="jurusan-list reveal" id="jurusan-list" data-stagger>
      <div data-category="rpl" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;transition:transform .3s ease;">
        <div class="reveal-wipe" style="height:150px;overflow:hidden;"><img src="<?= site_media_html($akademikImagePaths['program_rpl'] ?? $akademikImageSlots['program_rpl']['default']) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:26px;">
        <div class="program-logo-frame"><img class="program-logo" src="<?= site_media_html('assets/img/program-rpl.svg') ?>" alt="Icon RPL" width="44" height="44"></div>
        <h3 style="font-size:18px;">Rekayasa Perangkat Lunak</h3>
        <p style="margin-top:8px;font-size:14.5px;color:var(--muted);line-height:1.7;">Merancang basis data, menulis kode, dan merilis aplikasi web &amp; mobile ke pengguna nyata lewat proyek akhir tiap semester.</p>
        </div>
      </div>
      <div data-category="tkj" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;">
        <div class="reveal-wipe" style="height:150px;overflow:hidden;"><img src="<?= site_media_html($akademikImagePaths['program_tkj'] ?? $akademikImageSlots['program_tkj']['default']) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:26px;">
        <div class="program-logo-frame"><img class="program-logo" src="<?= site_media_html('assets/img/program-tkj.svg') ?>" alt="Icon TKJ" width="44" height="44"></div>
        <h3 style="font-size:18px;">Teknik Komputer &amp; Jaringan</h3>
        <p style="margin-top:8px;font-size:14.5px;color:var(--muted);line-height:1.7;">Instalasi, konfigurasi, dan pengamanan jaringan serta server — dari jaringan rumahan hingga simulasi kantor kecil.</p>
        </div>
      </div>
      <div data-category="pspt" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;">
        <div class="reveal-wipe" style="height:150px;overflow:hidden;"><img src="<?= site_media_html($akademikImagePaths['program_pspt'] ?? $akademikImageSlots['program_pspt']['default']) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:26px;">
        <div class="program-logo-frame"><img class="program-logo" src="<?= site_media_html('assets/img/program-pspt.svg') ?>" alt="Icon PSPT" width="44" height="44"></div>
        <h3 style="font-size:18px;">PSPT</h3>
        <p style="margin-top:8px;font-size:14.5px;color:var(--muted);line-height:1.7;">Mengembangkan kemampuan produksi acara televisi, penulisan naskah, penyutradaraan, dan siaran langsung dari pra-produksi hingga pascaproduksi.</p>
        </div>
      </div>
      <div data-category="dkv" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);overflow:hidden;">
        <div class="reveal-wipe" style="height:150px;overflow:hidden;"><img src="<?= site_media_html($akademikImagePaths['program_dkv'] ?? $akademikImageSlots['program_dkv']['default']) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:26px;">
        <div class="program-logo-frame"><img class="program-logo" src="<?= site_media_html('assets/img/program-dkv.svg') ?>" alt="Icon DKV" width="44" height="44"></div>
        <h3 style="font-size:18px;">DKV (Desain Komunikasi Visual)</h3>
        <p style="margin-top:8px;font-size:14.5px;color:var(--muted);line-height:1.7;">Desain grafis, videografi, dan animasi untuk konten yang dipakai brand dan kreator lokal — dari storyboard sampai produk jadi.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
