/* =========================================================
   SMK Eriansyah — shared site script
   Custom entrance-animation engine (not Belmont's own bundle —
   that's proprietary/minified — this is a from-scratch version
   built to match the same "text glides up, images glide in from
   the side" feel you pointed at).
   ========================================================= */

// ---------- nav scroll state ----------
const nav = document.getElementById('mainNav');
if (nav) {
  const updateNav = () => nav.classList.toggle('scrolled', window.scrollY > 40);
  window.addEventListener('scroll', updateNav, { passive: true });
  updateNav();
}

// Upgrade existing BKK links while preserving their URL as a no-JS fallback.
const bkkMenuItems = [
  ['PKL', 'karier.php#pkl'],
  ['Magang Jepang', 'magang-jepang.php'],
  ['Kunjungan Industri', 'kunjungan-industri.php'],
];
const bkkDropdowns = [];

function setBkkDropdownOpen(dropdown, isOpen, restoreFocus = false) {
  const toggle = dropdown.querySelector('button');
  const menu = dropdown.querySelector('.bkk-dropdown-menu');
  if (!toggle || !menu) return;
  dropdown.classList.toggle('is-open', isOpen);
  toggle.setAttribute('aria-expanded', String(isOpen));
  menu.hidden = !isOpen;
  if (restoreFocus) toggle.focus();
}

function createBkkDropdown(sourceLink, isMobile) {
  const dropdown = document.createElement('div');
  dropdown.className = isMobile ? 'bkk-mobile-dropdown' : 'nav-item bkk-dropdown';
  const toggle = document.createElement('button');
  const menuId = isMobile ? 'bkkMobileMenu' : 'bkkDesktopMenu';
  toggle.type = 'button';
  toggle.className = isMobile ? 'bkk-mobile-dropdown-toggle' : 'nav-link bkk-dropdown-toggle';
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-controls', menuId);
  toggle.setAttribute('aria-haspopup', 'true');
  if (sourceLink.classList.contains('active') || sourceLink.getAttribute('aria-current') === 'page') {
    toggle.classList.add('active');
    toggle.setAttribute('aria-current', 'page');
  }
  toggle.innerHTML = 'BKK<svg class="bkk-dropdown-chevron" viewBox="0 0 12 12" aria-hidden="true"><path d="m2.5 4.5 3.5 3 3.5-3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  const menu = document.createElement('ul');
  menu.className = 'bkk-dropdown-menu';
  menu.id = menuId;
  menu.setAttribute('aria-label', 'Pilihan BKK');
  menu.hidden = true;
  bkkMenuItems.forEach(([label, href]) => {
    const item = document.createElement('li');
    const link = document.createElement('a');
    link.href = href;
    link.textContent = label;
    item.append(link);
    menu.append(item);
  });

  dropdown.append(toggle, menu);
  sourceLink.replaceWith(dropdown);
  bkkDropdowns.push(dropdown);
  toggle.addEventListener('click', () => {
    const willOpen = toggle.getAttribute('aria-expanded') !== 'true';
    bkkDropdowns.forEach((item) => setBkkDropdownOpen(item, item === dropdown && willOpen));
  });
}

document.querySelectorAll('.nav-links > a.nav-link[href="bkk.php"]').forEach((link) => createBkkDropdown(link, false));
document.querySelectorAll('.mobile-panel > a[href="bkk.php"]').forEach((link) => createBkkDropdown(link, true));

document.addEventListener('click', (event) => {
  if (!event.target.closest?.('.bkk-dropdown, .bkk-mobile-dropdown')) {
    bkkDropdowns.forEach((dropdown) => setBkkDropdownOpen(dropdown, false));
  }
});

// ---------- mobile menu ----------
const burger = document.getElementById('burger');
const panel = document.getElementById('mobilePanel');
const scrim = document.getElementById('scrim');
const mClose = document.getElementById('mobileClose');
function openMenu(){
  if (!burger || !panel || !scrim) return;
  burger.classList.add('open'); panel.classList.add('open'); scrim.classList.add('show');
  burger.setAttribute('aria-expanded', 'true');
  panel.setAttribute('aria-hidden', 'false');
  document.body.classList.add('menu-open');
}
function closeMenu(){
  if (!burger || !panel || !scrim) return;
  burger.classList.remove('open'); panel.classList.remove('open'); scrim.classList.remove('show');
  burger.setAttribute('aria-expanded', 'false');
  panel.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('menu-open');
}
if (burger && panel) {
  burger.setAttribute('aria-expanded', 'false');
  panel.setAttribute('aria-hidden', 'true');
  burger.addEventListener('click', () => panel.classList.contains('open') ? closeMenu() : openMenu());
  mClose && mClose.addEventListener('click', closeMenu);
  scrim && scrim.addEventListener('click', closeMenu);
  panel.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
  scrim && scrim.addEventListener('transitionend', () => panel.setAttribute('aria-hidden', panel.classList.contains('open') ? 'false' : 'true'));
}
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    const openDropdown = bkkDropdowns.find((dropdown) => dropdown.classList.contains('is-open'));
    if (openDropdown) setBkkDropdownOpen(openDropdown, false, true);
    closeMenu();
  }
});

// ---------- announcement ribbon close ----------
const ribbon = document.getElementById('ribbon');
const ribbonClose = document.getElementById('ribbonClose');
if (ribbon && ribbonClose) {
  if (sessionStorage.getItem('infokom-ribbon-closed') === '1') ribbon.hidden = true;
  ribbonClose.addEventListener('click', () => {
    ribbon.hidden = true;
    sessionStorage.setItem('infokom-ribbon-closed', '1');
  });
}

// ---------- split headings into words for the glide-up effect ----------
document.querySelectorAll('.split').forEach(el => {
  const words = el.textContent.trim().split(/\s+/);
  el.innerHTML = words
    .map((w, i) => `<span style="transition-delay:${i * 45}ms">${w}</span>`)
    .join(' ');
});

// ---------- one IntersectionObserver drives every reveal variant ----------
const revealSelectors = '.reveal, .reveal-left, .reveal-right, .reveal-scale, .split';
const revealIO = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
      revealIO.unobserve(entry.target);
    }
  });
}, { threshold: 0.15, rootMargin: '0px 0px -60px 0px' });
document.querySelectorAll(revealSelectors).forEach(el => revealIO.observe(el));

// ---------- hero: animate in on load, not on scroll (it's already visible) ----------
window.addEventListener('DOMContentLoaded', () => {
  const heroH1 = document.querySelector('.hero h1.split');
  const heroSub = document.querySelector('.hero-sub.load-in');
  const heroActions = document.querySelector('.hero-actions.load-in');
  requestAnimationFrame(() => requestAnimationFrame(() => {
    heroH1 && heroH1.classList.add('in-view');
    heroSub && heroSub.classList.add('in-view');
    heroActions && heroActions.classList.add('in-view');
  }));

  // hero squiggle + circuit draw-in (only present on the home page)
  document.querySelectorAll('#circuitSvg path').forEach((path, i) => {
    path.style.strokeDasharray = '1';
    path.style.strokeDashoffset = '1';
    path.style.transition = `stroke-dashoffset 1.6s cubic-bezier(.2,.7,.3,1) ${i * 0.22}s`;
    requestAnimationFrame(() => requestAnimationFrame(() => { path.style.strokeDashoffset = '0'; }));
  });
});

// ---------- stat counters ----------
const counters = document.querySelectorAll('[data-count]');
const counterIO = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (!e.isIntersecting) return;
    const el = e.target;
    const target = parseInt(el.dataset.count, 10);
    const suffix = el.dataset.suffix || '';
    const dur = 1400; const start = performance.now();
    function tick(now){
      const p = Math.min((now - start) / dur, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      el.textContent = Math.round(eased * target) + suffix;
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
    counterIO.unobserve(el);
  });
}, { threshold: 0.5 });
counters.forEach(el => counterIO.observe(el));

// ---------- horizontal carousels (alumni / testimonial) ----------
function wireCarousel(trackId, leftId, rightId){
  const track = document.getElementById(trackId);
  const left = document.getElementById(leftId);
  const right = document.getElementById(rightId);
  if (!track || !left || !right) return;
  const step = () => track.clientWidth * 0.8;
  left.addEventListener('click', () => track.scrollBy({ left: -step(), behavior: 'smooth' }));
  right.addEventListener('click', () => track.scrollBy({ left: step(), behavior: 'smooth' }));
}
wireCarousel('alumniTrack','alumniLeft','alumniRight');
wireCarousel('testiTrack','testiLeft','testiRight');

/* =========================================================
   SCROLL PROGRESS BAR
   ========================================================= */
const progressBar = document.getElementById('scrollProgress');
if (progressBar) {
  window.addEventListener('scroll', () => {
    const h = document.documentElement;
    const scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
    progressBar.style.width = scrolled + '%';
  });
}

/* =========================================================
   CROSS-PAGE FADE TRANSITION
   (fade to navy, navigate, fade back in — makes moving between
   pages feel like one continuous site instead of a hard reload)
   ========================================================= */
const pageTransition = document.getElementById('pageTransition');
if (pageTransition) {
  pageTransition.classList.add('entering');
  requestAnimationFrame(() => requestAnimationFrame(() => {
    pageTransition.classList.remove('entering');
  }));
  window.addEventListener('pageshow', () => pageTransition.classList.remove('entering'));
  document.querySelectorAll('a[href$=".php"], a[href*=".php#"], a[href$=".html"], a[href*=".html#"]').forEach(a => {
    const href = a.getAttribute('href');
    if (a.target === '_blank' || href.startsWith('http') || href.startsWith('#')) return;
    a.addEventListener('click', (e) => {
      e.preventDefault();
      pageTransition.classList.add('entering');
      setTimeout(() => { window.location.href = href; }, 420);
    });
  });
}

/* =========================================================
   SMALL DIRECT-MANIPULATION DETAILS
   ========================================================= */
document.querySelectorAll('.btn, .filter-chip').forEach(button => {
  button.addEventListener('click', (event) => {
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    ripple.className = 'click-ripple';
    ripple.style.left = `${event.clientX - rect.left}px`;
    ripple.style.top = `${event.clientY - rect.top}px`;
    button.appendChild(ripple);
    ripple.addEventListener('animationend', () => ripple.remove());
  });
});

const topButton = document.createElement('button');
topButton.className = 'back-top';
topButton.type = 'button';
topButton.setAttribute('aria-label', 'Kembali ke atas');
topButton.innerHTML = '&#8593;';
document.body.appendChild(topButton);
const updateTopButton = () => topButton.classList.toggle('visible', window.scrollY > window.innerHeight * 0.7);
window.addEventListener('scroll', updateTopButton, { passive: true });
updateTopButton();
topButton.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

/* Image lightbox for home gallery and any future [data-lightbox] image. */
const lightboxImages = document.querySelectorAll('img[data-lightbox]');
if (lightboxImages.length) {
  const lightbox = document.createElement('div');
  lightbox.className = 'lightbox';
  lightbox.innerHTML = '<button class="lightbox-close" aria-label="Tutup gambar">&times;</button><figure><img alt=""><figcaption></figcaption></figure>';
  document.body.appendChild(lightbox);
  const lightboxImage = lightbox.querySelector('img');
  const lightboxCaption = lightbox.querySelector('figcaption');
  const closeLightbox = () => { lightbox.classList.remove('open'); document.body.classList.remove('menu-open'); };
  lightbox.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
  lightbox.addEventListener('click', event => { if (event.target === lightbox) closeLightbox(); });
  lightboxImages.forEach(image => image.addEventListener('click', () => {
    lightboxImage.src = image.src.replace(/w=300/g, 'w=1200');
    lightboxImage.alt = image.alt;
    lightboxCaption.textContent = image.dataset.lightbox;
    lightbox.classList.add('open');
    document.body.classList.add('menu-open');
  }));
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeLightbox(); });
}

/* Subtle pointer tilt gives the teaser grid a more tactile feel on desktop. */
if (window.matchMedia('(pointer:fine)').matches) {
  document.querySelectorAll('.teaser-card, .gallery-item').forEach(card => {
    card.addEventListener('pointermove', event => {
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width - 0.5;
      const y = (event.clientY - rect.top) / rect.height - 0.5;
      card.style.setProperty('--tilt', `rotateX(${y * -3}deg) rotateY(${x * 3}deg)`);
    });
    card.addEventListener('pointerleave', () => card.style.setProperty('--tilt', 'rotateX(0) rotateY(0)'));
  });
}

/* =========================================================
   HERO PARALLAX (background photo drifts slower than scroll)
   ========================================================= */
const heroScene = document.querySelector('.hero-scene img');
if (heroScene) {
  window.addEventListener('scroll', () => {
    const y = window.scrollY;
    if (y < window.innerHeight) heroScene.style.transform = `translateY(${y * 0.25}px) scale(1.08)`;
  }, { passive: true });
  if (window.matchMedia('(pointer:fine)').matches) {
    const hero = document.querySelector('.hero');
    hero && hero.addEventListener('pointermove', event => {
      const x = (event.clientX / window.innerWidth - 0.5) * 8;
      const y = (event.clientY / window.innerHeight - 0.5) * 5;
      heroScene.style.transform = `translate(${x}px, ${y}px) scale(1.08)`;
    });
  }
}

/* =========================================================
   STAGGERED GRID REVEAL
   any [data-stagger] container: its direct children fade+rise
   in one after another instead of all at once
   ========================================================= */
document.querySelectorAll('[data-stagger]').forEach(container => {
  const kids = Array.from(container.children);
  kids.forEach((kid, i) => {
    kid.classList.add('reveal-scale');
    kid.style.transitionDelay = (i * 0.09) + 's';
  });
  const groupIO = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        kids.forEach(k => k.classList.add('in-view'));
        groupIO.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  groupIO.observe(container);
});

/* =========================================================
   CURTAIN-WIPE IMAGE REVEAL
   images with class "reveal-wipe" slide a curtain away instead
   of a plain fade — closer to the "gliding into place" look
   ========================================================= */
const wipeIO = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('in-view');
      wipeIO.unobserve(entry.target);
    }
  });
}, { threshold: 0.2 });
document.querySelectorAll('.reveal-wipe').forEach(el => wipeIO.observe(el));

/* =========================================================
   MULTI-SELECT FILTER CHIPS
   works on any section with a [data-filter-bar] of buttons
   (data-filter="rpl") and a [data-filter-items] container whose
   children carry data-category="rpl tkj" (space-separated).
   Multiple chips can be active at once; "Semua" resets to all.
   ========================================================= */
document.querySelectorAll('[data-filter-bar]').forEach(bar => {
  const targetSel = bar.dataset.filterBar;
  const wrap = document.querySelector(targetSel);
  if (!wrap) return;
  const items = Array.from(wrap.children).filter(el => el.hasAttribute('data-category'));
  const chips = Array.from(bar.querySelectorAll('[data-filter]'));

  function applyFilter(){
    const active = chips.filter(c => c.classList.contains('active')).map(c => c.dataset.filter);
    const showAll = active.length === 0 || active.includes('all');
    items.forEach(item => {
      const cats = (item.dataset.category || '').split(' ');
      const match = showAll || cats.some(c => active.includes(c));
      item.style.display = match ? '' : 'none';
    });
  }

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      if (chip.dataset.filter === 'all') {
        chips.forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
      } else {
        bar.querySelector('[data-filter="all"]') && bar.querySelector('[data-filter="all"]').classList.remove('active');
        chip.classList.toggle('active');
        const anyActive = chips.some(c => c.classList.contains('active'));
        if (!anyActive) { const allChip = bar.querySelector('[data-filter="all"]'); allChip && allChip.classList.add('active'); }
      }
      applyFilter();
    });
  });
  applyFilter();
});

/* =========================================================
   PPDB FORM — client-side only (this is a static site, so
   there's no server to send data to). Validates required
   fields, then swaps the form for a confirmation panel.
   ========================================================= */
const ppdbForm = document.getElementById('ppdbForm');
if (ppdbForm) {
  ppdbForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const required = ppdbForm.querySelectorAll('[required]');
    let ok = true;
    required.forEach(field => {
      const errorEl = field.closest('.form-field').querySelector('.field-error');
      if (!field.value || (field.type === 'radio' && !ppdbForm.querySelector(`input[name="${field.name}"]:checked`))) {
        if (field.type !== 'radio' || !ppdbForm.querySelector(`input[name="${field.name}"]:checked`)) {
          ok = false;
          field.closest('.form-field').classList.add('has-error');
          if (errorEl) errorEl.style.display = 'block';
        }
      } else {
        field.closest('.form-field').classList.remove('has-error');
        if (errorEl) errorEl.style.display = 'none';
      }
    });
    if (!ok) {
      ppdbForm.querySelector('.has-error')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    const nameField = ppdbForm.querySelector('[name="nama"]');
    document.getElementById('ppdbSuccessName').textContent = nameField ? nameField.value : '';
    ppdbForm.parentElement.querySelector('.ppdb-form-card').style.display = 'none';
    document.getElementById('ppdbSuccess').style.display = 'block';
    document.getElementById('ppdbSuccess').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
}
