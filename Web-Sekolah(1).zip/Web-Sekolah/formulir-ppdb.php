<?php

function ppdb_pdf_literal(string $value): string
{
    return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $value);
}

function ppdb_pdf_text(string $value, int $x, int $top, int $size = 10): string
{
    $y = 842 - $top - $size;
    return "BT /Helv {$size} Tf {$x} {$y} Td (" . ppdb_pdf_literal($value) . ") Tj ET\n";
}

function ppdb_pdf_logo_image(string $path): array
{
    $data = file_get_contents($path);
    if (!is_string($data) || substr($data, 0, 8) !== "\x89PNG\r\n\x1a\n") {
        throw new RuntimeException('Logo SMK Infokom tidak dapat dibaca.');
    }

    $header = unpack('Nwidth/Nheight/Cdepth/Ccolor/Ccompression/Cfilter/Cinterlace', substr($data, 16, 13));
    if (!is_array($header)
        || $header['depth'] !== 8
        || $header['color'] !== 3
        || $header['compression'] !== 0
        || $header['filter'] !== 0
        || $header['interlace'] !== 0) {
        throw new RuntimeException('Format logo SMK Infokom tidak didukung untuk PDF.');
    }

    $palette = '';
    $imageData = '';
    $offset = 8;
    while ($offset + 12 <= strlen($data)) {
        $chunkLength = unpack('N', substr($data, $offset, 4))[1];
        $chunkType = substr($data, $offset + 4, 4);
        $chunkData = substr($data, $offset + 8, $chunkLength);
        if (strlen($chunkData) !== $chunkLength) {
            throw new RuntimeException('Data logo SMK Infokom tidak lengkap.');
        }
        if ($chunkType === 'PLTE') {
            $palette = $chunkData;
        } elseif ($chunkType === 'IDAT') {
            $imageData .= $chunkData;
        } elseif ($chunkType === 'tRNS') {
            throw new RuntimeException('Logo dengan transparansi palet belum didukung.');
        } elseif ($chunkType === 'IEND') {
            break;
        }
        $offset += 12 + $chunkLength;
    }

    if ($palette === '' || strlen($palette) % 3 !== 0 || $imageData === '') {
        throw new RuntimeException('Data gambar logo SMK Infokom tidak valid.');
    }

    return [
        'width' => $header['width'],
        'height' => $header['height'],
        'palette' => $palette,
        'data' => $imageData,
    ];
}

function ppdb_pdf_section(string $title, int $top): string
{
    $y = 842 - $top - 24;
    return "0.12 0.20 0.30 rg 50 {$y} 495 24 re f\n"
        . "1 0.82 0 rg 50 {$y} 4 24 re f\n"
        . "1 1 1 rg\n"
        . ppdb_pdf_text($title, 62, $top + 6, 10);
}

function ppdb_pdf_header(int $top, string $brand, string $subtitle): string
{
    $imageY = 842 - $top - 58;
    $lineY = $imageY - 9;
    $content = "q 58 0 0 58 50 {$imageY} cm /Logo Do Q\n";
    $content .= "0.12 0.20 0.30 rg 50 {$lineY} 495 2 re f\n";
    $content .= ppdb_pdf_text($brand, 120, $top + 8, 15);
    $content .= ppdb_pdf_text($subtitle, 120, $top + 31, 9);

    return $content;
}

function ppdb_pdf_field(
    array &$objects,
    string $name,
    string $label,
    int $pageId,
    int $x,
    int $top,
    int $width,
    int $height = 28,
    bool $multiline = false
): int {
    $bottom = 842 - $top - $height;
    $flags = $multiline ? ' /Ff 4096' : '';
    $objectId = count($objects);
    $objects[] = '<< /Type /Annot /Subtype /Widget /FT /Tx /T (' . ppdb_pdf_literal($name)
        . ') /TU (' . ppdb_pdf_literal($label)
        . ') /V () /DV () /Rect [' . $x . ' ' . $bottom . ' ' . ($x + $width) . ' ' . ($bottom + $height)
        . '] /P ' . $pageId . ' 0 R /F 4 /DA (/Helv 10 Tf 0 g)' . $flags
        . ' /MK << /BC [0.55 0.61 0.68] /BG [1 1 1] >> /BS << /Type /Border /W 1 /S /S >> >>';

    return $objectId;
}

function ppdb_pdf_add_field(
    array &$objects,
    array &$pageFields,
    string &$content,
    string $name,
    string $label,
    int $pageId,
    int $x,
    int $top,
    int $width,
    int $height = 28,
    bool $multiline = false
): void {
    $content .= ppdb_pdf_text($label, $x, $top - 17, 9);
    $content .= "{$x} " . (842 - $top - $height) . " {$width} {$height} re S\n";
    $pageFields[] = ppdb_pdf_field($objects, $name, $label, $pageId, $x, $top, $width, $height, $multiline);
}

$objects = [null];
$catalogId = count($objects);
$objects[] = '';
$pagesId = count($objects);
$objects[] = '';
$fontId = count($objects);
$objects[] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>';
$logo = ppdb_pdf_logo_image(__DIR__ . '/assets/img/logo-infokom.png');
$logoId = count($objects);
$paletteHex = strtoupper(bin2hex($logo['palette']));
$objects[] = '<< /Type /XObject /Subtype /Image /Width ' . $logo['width']
    . ' /Height ' . $logo['height']
    . ' /ColorSpace [/Indexed /DeviceRGB ' . (strlen($logo['palette']) / 3 - 1) . ' <' . $paletteHex . '>]'
    . ' /BitsPerComponent 8 /Filter /FlateDecode /DecodeParms << /Predictor 15 /Colors 1 /BitsPerComponent 8 /Columns '
    . $logo['width'] . ' >> /Length ' . strlen($logo['data']) . " >>\nstream\n"
    . $logo['data'] . "\nendstream";
$acroFormId = count($objects);
$objects[] = '';

$pageIds = [];
for ($page = 0; $page < 2; $page++) {
    $pageIds[] = count($objects);
    $objects[] = '';
}

$allFields = [];
$pageContents = [];
$pageAnnotations = [];
foreach ($pageIds as $pageIndex => $pageId) {
    $content = "0.12 0.20 0.30 rg\n";
    if ($pageIndex === 0) {
        $content .= ppdb_pdf_header(28, 'SMK INFOKOM BOGOR', 'INFORMATIKA DAN TELEKOMUNIKASI');
        $content .= ppdb_pdf_text('FORMULIR PENDAFTARAN SISWA BARU', 50, 103, 17);
        $content .= ppdb_pdf_text('PENERIMAAN PESERTA DIDIK BARU (PPDB)', 50, 128, 10);
        $content .= ppdb_pdf_text('Isi formulir secara offline. Kolom bertanda * wajib dilengkapi.', 50, 145, 9);
        $content .= ppdb_pdf_section('DATA CALON SISWA', 163);

        $fields = [];
        ppdb_pdf_add_field($objects, $fields, $content, 'nama', 'Nama lengkap calon siswa *', $pageId, 50, 205, 495);
        ppdb_pdf_add_field($objects, $fields, $content, 'nisn', 'NISN *', $pageId, 50, 260, 238);
        ppdb_pdf_add_field($objects, $fields, $content, 'nik', 'NIK *', $pageId, 307, 260, 238);
        ppdb_pdf_add_field($objects, $fields, $content, 'tempat_lahir', 'Tempat lahir *', $pageId, 50, 315, 238);
        ppdb_pdf_add_field($objects, $fields, $content, 'tanggal_lahir', 'Tanggal lahir * (DD/MM/YYYY)', $pageId, 307, 315, 238);
        ppdb_pdf_add_field($objects, $fields, $content, 'jk', 'Jenis kelamin * (Laki-laki / Perempuan)', $pageId, 50, 370, 495);
        ppdb_pdf_add_field($objects, $fields, $content, 'asal_sekolah', 'Asal sekolah (SMP/MTs) *', $pageId, 50, 425, 495);
        $content .= ppdb_pdf_section('DATA KONTAK', 480);
        ppdb_pdf_add_field($objects, $fields, $content, 'wa_ortu', 'Nomor WhatsApp orang tua/wali *', $pageId, 50, 522, 238);
        ppdb_pdf_add_field($objects, $fields, $content, 'email', 'Email aktif *', $pageId, 307, 522, 238);
        $content .= ppdb_pdf_text('Pastikan data sesuai dokumen resmi calon siswa.', 50, 573, 9);
        $content .= "0.55 0.61 0.68 RG 50 44 495 0.7 w S\n";
        $content .= ppdb_pdf_text('SMK Infokom Bogor  |  Formulir PPDB offline', 50, 810, 8);
        $content .= ppdb_pdf_text('1 / 2', 514, 810, 8);
    } else {
        $content .= ppdb_pdf_header(28, 'SMK INFOKOM BOGOR', 'INFORMATIKA DAN TELEKOMUNIKASI');
        $content .= ppdb_pdf_text('PILIHAN PROGRAM DAN ALAMAT', 50, 103, 16);
        $content .= ppdb_pdf_text('HALAMAN 2 - LENGKAPI PILIHAN DAN PERNYATAAN', 50, 128, 9);
        $content .= ppdb_pdf_section('PILIHAN PENDAFTARAN', 153);

        $fields = [];
        ppdb_pdf_add_field($objects, $fields, $content, 'pilihan1', 'Pilihan program keahlian 1 *', $pageId, 50, 195, 495);
        ppdb_pdf_add_field($objects, $fields, $content, 'pilihan2', 'Pilihan program keahlian 2 (opsional)', $pageId, 50, 250, 495);
        $content .= ppdb_pdf_text('RPL - Rekayasa Perangkat Lunak; TKJ - Teknik Komputer & Jaringan;', 50, 288, 8);
        $content .= ppdb_pdf_text('DKV - Desain Komunikasi Visual; PSPT - Produksi dan Siaran Program Televisi.', 50, 301, 8);
        ppdb_pdf_add_field($objects, $fields, $content, 'jalur', 'Jalur pendaftaran * (Prestasi / Reguler / Afirmasi)', $pageId, 50, 340, 495);
        $content .= ppdb_pdf_section('ALAMAT DOMISILI', 395);
        ppdb_pdf_add_field($objects, $fields, $content, 'alamat', 'Alamat lengkap sesuai KTP/KK *', $pageId, 50, 437, 495, 78, true);
        $content .= ppdb_pdf_section('PERNYATAAN DAN TANDA TANGAN', 538);
        $content .= ppdb_pdf_text('Saya menyatakan data yang diisi benar dan dapat dipertanggungjawabkan.', 50, 575, 9);
        $content .= ppdb_pdf_text('Berkas: ijazah/SKL, rapor, kartu keluarga, dan pas foto.', 50, 593, 9);
        $content .= ppdb_pdf_text('Serahkan formulir dan berkas persyaratan kepada panitia PPDB.', 50, 611, 9);
        $content .= ppdb_pdf_text('Tempat, tanggal:', 50, 654, 9);
        $content .= "0.55 0.61 0.68 RG 124 160 m 304 160 l 0.7 w S\n";
        $content .= ppdb_pdf_text('Tanda tangan calon siswa / orang tua', 345, 654, 9);
        $content .= "0.55 0.61 0.68 RG 345 150 m 545 150 l 0.7 w S\n";
        $content .= ppdb_pdf_text('Nama lengkap', 345, 735, 8);
        $content .= "0.55 0.61 0.68 RG 50 44 495 0.7 w S\n";
        $content .= ppdb_pdf_text('SMK Infokom Bogor  |  Formulir PPDB offline', 50, 810, 8);
        $content .= ppdb_pdf_text('2 / 2', 514, 810, 8);
    }

    $allFields = array_merge($allFields, $fields);
    $pageAnnotations[] = $fields;
    $streamId = count($objects);
    $objects[] = '<< /Length ' . strlen($content) . " >>\nstream\n" . $content . "endstream";
    $pageContents[] = $streamId;
}

foreach ($pageIds as $index => $pageId) {
    $annotationRefs = array_map(static fn(int $id): string => $id . ' 0 R', $pageAnnotations[$index]);
    $objects[$pageId] = '<< /Type /Page /Parent ' . $pagesId . ' 0 R /MediaBox [0 0 595 842]'
        . ' /Resources << /Font << /Helv ' . $fontId . ' 0 R >> /XObject << /Logo ' . $logoId . ' 0 R >> >>'
        . ' /Contents ' . $pageContents[$index] . ' 0 R /Annots [' . implode(' ', $annotationRefs) . '] >>';
}

$objects[$pagesId] = '<< /Type /Pages /Kids [' . implode(' ', array_map(
    static fn(int $id): string => $id . ' 0 R',
    $pageIds
)) . '] /Count ' . count($pageIds) . ' >>';
$objects[$acroFormId] = '<< /Fields [' . implode(' ', array_map(
    static fn(int $id): string => $id . ' 0 R',
    $allFields
)) . '] /NeedAppearances true /DA (/Helv 10 Tf 0 g) /DR << /Font << /Helv ' . $fontId . ' 0 R >> >> >>';
$objects[$catalogId] = '<< /Type /Catalog /Pages ' . $pagesId . ' 0 R /AcroForm ' . $acroFormId . ' 0 R >>';

$pdf = "%PDF-1.7\n%\xE2\xE3\xCF\xD3\n";
$offsets = [0];
for ($id = 1; $id < count($objects); $id++) {
    $offsets[$id] = strlen($pdf);
    $pdf .= $id . " 0 obj\n" . $objects[$id] . "\nendobj\n";
}
$xrefOffset = strlen($pdf);
$pdf .= "xref\n0 " . count($objects) . "\n0000000000 65535 f \n";
for ($id = 1; $id < count($objects); $id++) {
    $pdf .= sprintf("%010d 00000 n \n", $offsets[$id]);
}
$pdf .= 'trailer << /Size ' . count($objects) . ' /Root ' . $catalogId . " 0 R >>\n";
$pdf .= "startxref\n{$xrefOffset}\n%%EOF\n";

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="formulir-ppdb-smk-infokom.pdf"');
header('Content-Length: ' . strlen($pdf));
echo $pdf;
