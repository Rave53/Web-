-- =========================================================
--  SMK Infokom Bogor — Skema Database
--  Cara pakai: buka phpMyAdmin -> Import -> pilih file ini
--  (ini akan membuat database `smk_infokom` secara otomatis)
-- =========================================================

CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

-- ---------------------------------------------------------
-- Tabel akun login (admin, admin BKK, siswa, alumni, orang tua)
-- ---------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin','admin_bkk','siswa','alumni','ortu') NOT NULL,
    nama VARCHAR(150) NOT NULL,
    ref_id INT NULL COMMENT 'id siswa terkait, untuk role siswa/ortu',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_username_role (username, role),
    KEY idx_users_ref_id (ref_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Data kelas
-- ---------------------------------------------------------
CREATE TABLE kelas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kelas VARCHAR(50) NOT NULL,
    wali_kelas VARCHAR(150) NULL,
    jumlah_siswa INT DEFAULT 0
);

-- ---------------------------------------------------------
-- Data guru
-- ---------------------------------------------------------
CREATE TABLE guru (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    jabatan VARCHAR(150) NULL,
    kategori VARCHAR(30) DEFAULT 'umum' COMMENT 'rpl/tkj/dkv/umum, bisa gabungan dipisah spasi',
    mapel VARCHAR(150) NULL,
    no_hp VARCHAR(30) NULL,
    deskripsi TEXT NULL,
    foto VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Berita / Kabar & Prestasi sekolah
-- ---------------------------------------------------------
CREATE TABLE berita (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    ringkasan VARCHAR(300) NULL,
    kategori ENUM('prestasi','kegiatan','pengumuman') DEFAULT 'kegiatan',
    tanggal DATE NOT NULL,
    foto VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Galeri foto sekolah
-- ---------------------------------------------------------
CREATE TABLE galeri (
    id INT AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(200) NOT NULL,
    kategori ENUM('kegiatan','prestasi','akademik','fasilitas') DEFAULT 'kegiatan',
    foto VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Pilihan foto Galeri untuk bagian Beranda dan Profil
-- ---------------------------------------------------------
CREATE TABLE page_image_slots (
    slot_key VARCHAR(60) PRIMARY KEY,
    gallery_id INT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_page_image_slots_gallery
        FOREIGN KEY (gallery_id) REFERENCES galeri(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Foto media untuk halaman Kunjungan Industri dan Mitra Kerja
-- ---------------------------------------------------------
CREATE TABLE page_media (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    page_key ENUM('kunjungan_industri','mitra_kerja') NOT NULL,
    title VARCHAR(200) NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
    sort_order INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_page_media_page_status (page_key, status, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Pengaturan foto program keahlian dan Teaching Factory
-- ---------------------------------------------------------
CREATE TABLE akademik_images (
    slot_key VARCHAR(40) PRIMARY KEY,
    image_path VARCHAR(255) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Video sekolah (unggahan lokal atau YouTube)
-- ---------------------------------------------------------
CREATE TABLE videos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    source_type ENUM('upload','youtube') NOT NULL,
    video_path VARCHAR(255) NULL,
    youtube_id VARCHAR(11) NULL,
    thumbnail_path VARCHAR(255) NULL,
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'nonaktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_videos_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Galeri khusus program Magang Jepang
-- ---------------------------------------------------------
CREATE TABLE japan_gallery (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NULL,
    item_type ENUM('image','upload','youtube','text') NOT NULL,
    image_path VARCHAR(255) NULL,
    video_path VARCHAR(255) NULL,
    youtube_id VARCHAR(11) NULL,
    status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'nonaktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_japan_gallery_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Ekstrakurikuler
-- ---------------------------------------------------------
CREATE TABLE ekstrakurikuler (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    kategori ENUM('teknologi','seni','olahraga','organisasi') DEFAULT 'teknologi',
    deskripsi TEXT NULL,
    pembina VARCHAR(150) NULL,
    jadwal VARCHAR(150) NULL,
    foto VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Data siswa
-- ---------------------------------------------------------
CREATE TABLE siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nisn VARCHAR(20) NOT NULL UNIQUE,
    nama VARCHAR(150) NOT NULL,
    kelas VARCHAR(50) NOT NULL,
    jk ENUM('Laki-laki','Perempuan') DEFAULT 'Laki-laki',
    rata_nilai DECIMAL(5,2) DEFAULT 0,
    kehadiran_persen DECIMAL(5,2) DEFAULT 0,
    peringkat VARCHAR(20) DEFAULT '-',
    status_spp VARCHAR(20) DEFAULT 'Belum Bayar',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE users
    ADD CONSTRAINT fk_users_siswa
    FOREIGN KEY (ref_id) REFERENCES siswa(id) ON DELETE CASCADE;

-- ---------------------------------------------------------
-- Data orang tua (relasi ke siswa/anak)
-- ---------------------------------------------------------
CREATE TABLE orang_tua (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    nama VARCHAR(150) NOT NULL,
    telepon VARCHAR(30) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Absensi harian siswa
-- ---------------------------------------------------------
CREATE TABLE absensi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    siswa_id INT NOT NULL,
    tanggal DATE NOT NULL,
    jam_masuk TIME NULL,
    status ENUM('Hadir','Izin','Sakit','Terlambat','Alpa') NOT NULL,
    keterangan VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (siswa_id) REFERENCES siswa(id) ON DELETE CASCADE,
    UNIQUE KEY uq_absensi_siswa_tanggal (siswa_id, tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------
-- Pendaftar PPDB (formulir pendaftaran siswa baru)
-- ---------------------------------------------------------
CREATE TABLE ppdb_pendaftar (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    nisn VARCHAR(20) NOT NULL,
    nik VARCHAR(20) NOT NULL,
    tempat_lahir VARCHAR(100) NULL,
    tanggal_lahir DATE NULL,
    jk ENUM('Laki-laki','Perempuan') NOT NULL,
    asal_sekolah VARCHAR(150) NULL,
    wa_ortu VARCHAR(30) NULL,
    email VARCHAR(150) NULL,
    pilihan1 VARCHAR(100) NULL,
    pilihan2 VARCHAR(100) NULL,
    jalur ENUM('Prestasi','Reguler','Afirmasi') NULL,
    alamat TEXT NULL,
    status ENUM('Menunggu Verifikasi','Diterima','Ditolak') DEFAULT 'Menunggu Verifikasi',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Pesan dari form kontak
-- ---------------------------------------------------------
CREATE TABLE pesan_kontak (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    pesan TEXT NOT NULL,
    status ENUM('Menunggu Verifikasi','Diterima','Ditolak') NOT NULL DEFAULT 'Menunggu Verifikasi',
    dibaca TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------
-- Pengganti gambar statis website, dikelola lewat admin-media.php
-- ---------------------------------------------------------
CREATE TABLE site_media (
    media_key CHAR(64) PRIMARY KEY,
    source_path TEXT NOT NULL,
    label VARCHAR(255) NOT NULL,
    uploaded_path VARCHAR(255) NULL,
    mime_type VARCHAR(80) NULL,
    file_size INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_site_media_label (label)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =========================================================
--  DATA CONTOH (SEED) — supaya dashboard langsung terisi
-- =========================================================

INSERT INTO kelas (nama_kelas, wali_kelas, jumlah_siswa) VALUES
('XI RPL 1', 'Rina Amelia', 34),
('X TKJ 1', 'Aditya Nugraha', 32),
('XI MM 2', 'Muhammad Ibnu Arif', 33),
('X RPL 2', 'Fajar Nugraha', 34),
('XI RPL 2', 'Rina Amelia', 34);

-- Guru & staf (lengkap dengan jabatan, kategori, foto)
INSERT INTO guru (nama, jabatan, kategori, foto) VALUES
('Ir. Hj. Liliek Rahmaningsih, M.M.Pd.', 'Kepala Sekolah', 'rpl tkj dkv pspt umum', 'uploads/guru/liliek-rahmaningsih.png'),
('Mila Yaelasari, M.Pd.', 'Wakil Kepala Sekolah Bidang Kurikulum', 'umum', 'uploads/guru/mila-yaelasari.png'),
('Dea Rijalul Fikri, S.Kom.,Gr.', 'Wakil Kepala Sekolah Bidang Kesiswaan', 'umum', 'uploads/guru/dea-rijalul-fikri.png'),
('R. Radiani Srirestuti Dewi, SS.,Gr.', 'Wakil Kepala Sekolah Bidang Hubungan Industri dan Masyarakat', 'umum', 'uploads/guru/radiani-srirestuti-dewi.png'),
('Heny Handayani, S.Pd.', 'Wakil Kepala Sekolah Bidang Pengembangan Sumber Daya Manusia', 'umum', 'uploads/guru/heny-handayani.png'),
('Agus Tiyono, M.Pd.', 'Wakil Kepala Sekolah Bidang Sarana dan Prasarana', 'umum', 'uploads/guru/agus-tiyono.png'),
('Aditya Nugraha, ST.', 'Ketua Manajemen Mutu & Kepala Program Keahlian TKJ', 'tkj umum', 'uploads/guru/aditya-nugraha.png'),
('Cahyadi Rozi, ST.', 'Kepala Tata Usaha', 'umum', 'uploads/guru/cahyadi-rozi.png'),
('Drs. Puji Marhaen Waluyo', 'Kepala Perpustakaan', 'umum', 'uploads/guru/puji-marhaen-waluyo.png'),
('Putri Riandini, S.Hut., M.Pd.,Gr.', 'Kepala Bendahara', 'umum', 'uploads/guru/putri-riandini.png'),
('Ridwan Hala, S.Kom.,Gr.', 'Kepala Program Keahlian RPL', 'rpl', 'uploads/guru/ridwan-hala.png'),
('Muhammad Ibnu Arif, S.IKom.', 'Kepala Program Keahlian DKV', 'dkv', 'uploads/guru/muhammad-ibnu-arif.png'),
('Erli Suherli, A.Md.Kom.', 'Kepala Program Keahlian PSPT', 'pspt', 'uploads/guru/erli-suherli.png'),
('Ahmad Hotib, S.Pd.I', 'Pembina OSIS', 'umum', 'uploads/guru/ahmad-hotib.png'),
('Abdul Azis, M.Pd.', 'Pembina OSIS', 'umum', 'uploads/guru/abdul-azis.png'),
('Vera Yuni Astuti, SP., M.IKom.,Gr.', 'Staf Kurikulum', 'umum', 'uploads/guru/vera-yuni-astuti.png'),
('M. Fauzan Arifin, S.IKom.,Gr.', 'Staf Kurikulum', 'tkj umum', 'uploads/guru/fauzan-arifin.png'),
('Dra. Popon Puspitasari', 'Guru Bimbingan & Konseling', 'umum', 'uploads/guru/popon-puspitasari.png'),
('Richo Santana, S.Kom.', 'Guru Bimbingan & Konseling', 'umum', 'uploads/guru/richo-santana.png'),
('Dian Hardianti, S.Kom.,Gr.', 'Guru Bimbingan & Konseling', 'umum', 'uploads/guru/dian-hardianti.png'),
('Yeni Yuliawati, S.Pd.,Gr.', 'Staf Teller (Bendahara)', 'umum', 'uploads/guru/yeni-yuliawati.png'),
('Rita Widyastuti', 'Staf Teller (Bendahara)', 'umum', 'uploads/guru/rita-widyastuti.png'),
('Eva Farida Rahayu, S.Pd.,Gr.', 'Staf Teller (Bendahara)', 'umum', 'uploads/guru/eva-farida-rahayu.png'),
('Jayadi, S.Pd.,Gr.', 'Staf Tata Usaha', 'umum', 'uploads/guru/jayadi.png'),
('Yadi Setiadi, S.Sos.,Gr.', 'Staf Tata Usaha', 'umum', 'uploads/guru/yadi-setiadi.png'),
('Siti Nuraeni', 'Staf Tata Usaha', 'umum', 'uploads/guru/siti-nuraeni.png'),
('Reza Prafitriansyah, S.Kom.,Gr.', 'Staf Perpustakaan', 'dkv umum', 'uploads/guru/reza-prafitriansyah.png'),
('Dra. Diana Octaria', 'Guru', 'umum', 'uploads/guru/diana-octaria.png'),
('Nabila Ahmadia Pratama, S.Pd.', 'Guru', 'umum', 'uploads/guru/nabila-ahmadia-pratama.png'),
('Erwin Hasiholan Gultom, S.Kom.', 'Guru RPL', 'rpl', 'uploads/guru/erwin-hasiholan-gultom.png'),
('Widyatama Nuranisa, SM.', 'Guru', 'umum', 'uploads/guru/widyatama-nuranisa.png'),
('Dara Purwanita, S.Pd.,Gr.', 'Guru', 'umum', 'uploads/guru/dara-purwanita.png');

-- Berita / Kabar & Prestasi
INSERT INTO berita (judul, ringkasan, kategori, tanggal, foto) VALUES
('Tim RPL Raih Juara 1 LKS Kota Bogor', 'Proyek aplikasi manajemen UMKM buatan siswa kelas XI menyisihkan 14 sekolah lain.', 'prestasi', '2026-08-12', 'https://images.pexels.com/photos/10638070/pexels-photo-10638070.jpeg?auto=compress&cs=tinysrgb&w=700'),
('Kunjungan Industri ke Perusahaan Teknologi Jakarta', '', 'kegiatan', '2026-07-28', 'https://images.pexels.com/photos/5092815/pexels-photo-5092815.jpeg?auto=compress&cs=tinysrgb&w=700'),
('Jadwal Masa Pengenalan Lingkungan Sekolah', '', 'pengumuman', '2026-07-05', 'https://images.pexels.com/photos/10638082/pexels-photo-10638082.jpeg?auto=compress&cs=tinysrgb&w=700'),
('Finalis Festival Film Pendek Pelajar Bogor', '', 'prestasi', '2026-07-01', 'https://images.pexels.com/photos/17115912/pexels-photo-17115912.jpeg?auto=compress&cs=tinysrgb&w=700');

-- Galeri foto
INSERT INTO galeri (judul, kategori, foto) VALUES
('Sesi kerja tim di lab komputer', 'kegiatan', 'https://images.pexels.com/photos/10638115/pexels-photo-10638115.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Wisuda & perayaan kelulusan', 'prestasi', 'https://images.pexels.com/photos/38395597/pexels-photo-38395597.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Praktik pemrograman kelas RPL', 'akademik', 'https://images.pexels.com/photos/10643469/pexels-photo-10643469.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Ruang server & jaringan', 'fasilitas', 'https://images.pexels.com/photos/4508751/pexels-photo-4508751.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Produksi konten DKV', 'kegiatan', 'https://images.pexels.com/photos/17115910/pexels-photo-17115910.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Prosesi wisuda siswa', 'prestasi', 'https://images.pexels.com/photos/32067327/pexels-photo-32067327.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Gedung utama sekolah', 'fasilitas', 'assets/img/gedung-infokom.jpg'),
('Aktivitas lab komputer', 'akademik', 'https://images.pexels.com/photos/10638065/pexels-photo-10638065.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Sesi videografi & fotografi', 'kegiatan', 'https://images.pexels.com/photos/7610533/pexels-photo-7610533.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Momen kelulusan siswa', 'prestasi', 'https://images.pexels.com/photos/2513993/pexels-photo-2513993.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Area kampus SMK Infokom Bogor', 'fasilitas', 'https://images.pexels.com/photos/5147366/pexels-photo-5147366.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Kelas praktik komputer', 'akademik', 'https://images.pexels.com/photos/10638068/pexels-photo-10638068.jpeg?auto=compress&cs=tinysrgb&w=600');

-- Ekstrakurikuler
INSERT INTO ekstrakurikuler (nama, kategori, deskripsi, pembina, jadwal, foto) VALUES
('Klub Robotika', 'teknologi', 'Merakit dan memprogram robot line-follower untuk kompetisi antar-SMK.', 'Aditya Nugraha, ST.', 'Selasa & Kamis, 15.30', 'https://images.pexels.com/photos/4508751/pexels-photo-4508751.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Klub Kompetisi Coding', 'teknologi', 'Latihan rutin menghadapi kompetisi pemrograman kompetitif dan LKS.', 'Ridwan Hala, S.Kom.,Gr.', 'Senin & Rabu, 15.30', 'https://images.pexels.com/photos/10638075/pexels-photo-10638075.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Karya Ilmiah Remaja', 'teknologi', 'Riset dan penulisan karya ilmiah di bidang teknologi terapan.', 'Erwin Hasiholan Gultom, S.Kom.', 'Jumat, 14.00', 'https://images.pexels.com/photos/10643469/pexels-photo-10643469.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Desain & Fotografi', 'seni', 'Latihan fotografi produk dan desain grafis untuk kebutuhan sekolah.', 'Muhammad Ibnu Arif, S.IKom.', 'Rabu, 15.30', 'https://images.pexels.com/photos/7610533/pexels-photo-7610533.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Band & Musik', 'seni', 'Latihan musik dan tampil di acara-acara sekolah.', 'Widyatama Nuranisa, SM.', 'Kamis, 15.30', 'https://images.pexels.com/photos/17115906/pexels-photo-17115906.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Futsal', 'olahraga', 'Latihan rutin dan mengikuti turnamen antar-SMK se-Bogor.', 'Ahmad Hotib, S.Pd.I', 'Selasa & Jumat, 16.00', 'https://images.pexels.com/photos/5147366/pexels-photo-5147366.jpeg?auto=compress&cs=tinysrgb&w=600'),
('Paskibra', 'organisasi', 'Latihan baris-berbaris dan persiapan upacara kenegaraan.', 'Abdul Azis, M.Pd.', 'Sabtu, 08.00', 'assets/img/gedung-infokom.jpg'),
('English Club', 'organisasi', 'Latihan percakapan bahasa Inggris dan persiapan lomba debat.', 'Nabila Ahmadia Pratama, S.Pd.', 'Senin, 15.30', 'https://images.pexels.com/photos/20853049/pexels-photo-20853049.jpeg?auto=compress&cs=tinysrgb&w=600');

INSERT INTO siswa (nisn, nama, kelas, jk, rata_nilai, kehadiran_persen, peringkat, status_spp) VALUES
('0051234321', 'Muhammad Fadli', 'XI RPL 2', 'Laki-laki', 88.00, 96.00, '5 dari 34', 'Lunas'),
('0051234322', 'Fajar Ramadhan', 'XI RPL 1', 'Laki-laki', 85.00, 94.80, '8 dari 34', 'Lunas'),
('0051234323', 'Siti Aulia', 'X TKJ 1', 'Perempuan', 90.00, 92.00, '2 dari 32', 'Lunas'),
('0051234324', 'Rizky Ramadhan', 'XI RPL 1', 'Laki-laki', 82.00, 90.00, '12 dari 34', 'Belum Bayar'),
('0051234325', 'Nadia Putri', 'XI MM 2', 'Perempuan', 87.00, 89.00, '6 dari 33', 'Lunas'),
('0051234326', 'Dimas Pratama', 'X RPL 2', 'Laki-laki', 91.00, 95.00, '3 dari 34', 'Lunas'),
('0051234327', 'Fajar Hidayat', 'X TKJ 1', 'Laki-laki', 78.00, 81.00, '20 dari 32', 'Belum Bayar'),
('0051234328', 'Putri Handayani', 'XI MM 2', 'Perempuan', 89.00, 93.00, '4 dari 33', 'Lunas'),
('0051234329', 'Muhammad Fadli Akbar', 'X RPL 2', 'Laki-laki', 80.00, 88.00, '15 dari 34', 'Lunas');

INSERT INTO orang_tua (siswa_id, nama, telepon) VALUES
(1, 'Budi Santoso', '0813-2000-0001');

-- Absensi hari ini untuk beberapa siswa (contoh data admin-absensi)
INSERT INTO absensi (siswa_id, tanggal, jam_masuk, status, keterangan) VALUES
(2, CURDATE(), '06:52:00', 'Hadir', NULL),
(3, CURDATE(), '06:58:00', 'Izin', 'Terlambat 5 menit'),
(4, CURDATE(), '07:05:00', 'Hadir', NULL),
(5, CURDATE(), '07:45:00', 'Terlambat', 'Alasan transportasi'),
(6, CURDATE(), '06:47:00', 'Hadir', NULL),
(7, CURDATE(), NULL, 'Alpa', 'Tanpa keterangan'),
(8, CURDATE(), '06:55:00', 'Hadir', NULL),
(9, CURDATE(), NULL, 'Izin', 'Acara keluarga'),
(1, CURDATE(), '06:50:00', 'Hadir', NULL);

-- ---------------------------------------------------------
-- Akun admin awal: username admin1, kata sandi admin2.
-- Hash dibuat dengan password_hash() PHP; ganti kata sandi setelah login pertama.
-- ---------------------------------------------------------
INSERT INTO users (username, password, role, nama)
VALUES ('admin1', '$2y$10$LdxaEWQXS7huBmnQ8Q.oTuanSeZ4xmAr.tNR60jzIv8Of.6Bs9LR2', 'admin', 'Admin Sekolah');

-- Tabel dan skema BKK (urutkan setelah tabel users dan data inti tersedia).

ALTER TABLE users
  MODIFY role ENUM('admin','admin_bkk','siswa','alumni','ortu') NOT NULL;

CREATE TABLE IF NOT EXISTS bkk_settings (
  id TINYINT UNSIGNED PRIMARY KEY DEFAULT 1,
  nama_bkk VARCHAR(150) NOT NULL DEFAULT 'Bursa Kerja Khusus SMK Infokom Bogor',
  deskripsi TEXT NULL,
  alamat VARCHAR(255) NULL,
  email VARCHAR(150) NULL,
  telepon VARCHAR(40) NULL,
  video_url VARCHAR(500) NULL,
  logo VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO bkk_settings (id) VALUES (1);

CREATE TABLE IF NOT EXISTS bkk_perusahaan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(180) NOT NULL,
  logo VARCHAR(255) NULL,
  bidang_industri VARCHAR(120) NOT NULL DEFAULT '',
  deskripsi TEXT NULL,
  alamat VARCHAR(255) NULL,
  kota VARCHAR(100) NULL,
  website VARCHAR(255) NULL,
  email VARCHAR(150) NULL,
  telepon VARCHAR(40) NULL,
  nama_pic VARCHAR(150) NULL,
  status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
  tanggal_mulai_kerja_sama DATE NULL,
  tanggal_akhir_kerja_sama DATE NULL,
  dokumen_mou VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_lowongan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  perusahaan_id INT UNSIGNED NOT NULL,
  posisi VARCHAR(180) NOT NULL,
  lokasi VARCHAR(150) NOT NULL,
  jenis_pekerjaan VARCHAR(80) NOT NULL,
  deskripsi MEDIUMTEXT NOT NULL,
  persyaratan MEDIUMTEXT NULL,
  pendidikan VARCHAR(100) NULL,
  jurusan VARCHAR(180) NULL,
  skill TEXT NULL,
  dokumen TEXT NULL,
  gaji VARCHAR(100) NULL,
  jumlah_posisi SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  tanggal_mulai DATE NULL,
  deadline DATE NOT NULL,
  link_pendaftaran VARCHAR(500) NULL,
  cara_melamar TEXT NULL,
  status ENUM('Aktif','Ditutup') NOT NULL DEFAULT 'Aktif',
  featured TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_bkk_lowongan_perusahaan FOREIGN KEY (perusahaan_id) REFERENCES bkk_perusahaan(id) ON DELETE RESTRICT,
  INDEX idx_bkk_lowongan_status_deadline (status, deadline),
  INDEX idx_bkk_lowongan_jurusan (jurusan),
  INDEX idx_bkk_lowongan_lokasi (lokasi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_pelamar (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  nisn VARCHAR(30) NULL,
  status_pelamar ENUM('Siswa','Alumni') NOT NULL DEFAULT 'Siswa',
  tahun_lulus YEAR NULL,
  jurusan VARCHAR(100) NOT NULL,
  no_hp VARCHAR(40) NOT NULL,
  email VARCHAR(150) NOT NULL,
  domisili VARCHAR(150) NOT NULL,
  cv VARCHAR(255) NULL,
  sertifikat VARCHAR(255) NULL,
  portofolio VARCHAR(500) NULL,
  skill TEXT NULL,
  pengalaman TEXT NULL,
  status ENUM('Aktif','Bekerja','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_pelamar_user (user_id),
  CONSTRAINT fk_bkk_pelamar_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_bkk_pelamar_jurusan (jurusan),
  INDEX idx_bkk_pelamar_status (status_pelamar)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_lamaran (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pelamar_id INT UNSIGNED NOT NULL,
  lowongan_id INT UNSIGNED NOT NULL,
  tanggal_melamar TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Lamaran Masuk','Seleksi Administrasi','Tes','Interview','Diterima','Ditolak') NOT NULL DEFAULT 'Lamaran Masuk',
  catatan_admin TEXT NULL,
  catatan_perusahaan TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_lamaran_pelamar_lowongan (pelamar_id, lowongan_id),
  CONSTRAINT fk_bkk_lamaran_pelamar FOREIGN KEY (pelamar_id) REFERENCES bkk_pelamar(id) ON DELETE CASCADE,
  CONSTRAINT fk_bkk_lamaran_lowongan FOREIGN KEY (lowongan_id) REFERENCES bkk_lowongan(id) ON DELETE CASCADE,
  INDEX idx_bkk_lamaran_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_riwayat_lamaran (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lamaran_id INT UNSIGNED NOT NULL,
  status ENUM('Lamaran Masuk','Seleksi Administrasi','Tes','Interview','Diterima','Ditolak') NOT NULL,
  catatan TEXT NULL,
  tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bkk_riwayat_lamaran FOREIGN KEY (lamaran_id) REFERENCES bkk_lamaran(id) ON DELETE CASCADE,
  INDEX idx_bkk_riwayat_tanggal (lamaran_id, tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_event (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama_event VARCHAR(180) NOT NULL,
  poster VARCHAR(255) NULL,
  deskripsi TEXT NULL,
  tanggal DATE NOT NULL,
  waktu VARCHAR(80) NULL,
  lokasi VARCHAR(180) NOT NULL,
  perusahaan_ikut TEXT NULL,
  kuota SMALLINT UNSIGNED NULL,
  link_pendaftaran VARCHAR(500) NULL,
  status ENUM('Akan Datang','Sedang Berlangsung','Selesai') NOT NULL DEFAULT 'Akan Datang',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_bkk_event_tanggal (tanggal, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_peserta_event (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id INT UNSIGNED NOT NULL,
  pelamar_id INT UNSIGNED NOT NULL,
  status ENUM('Terdaftar','Hadir','Batal') NOT NULL DEFAULT 'Terdaftar',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_peserta_event (event_id, pelamar_id),
  CONSTRAINT fk_bkk_peserta_event_event FOREIGN KEY (event_id) REFERENCES bkk_event(id) ON DELETE CASCADE,
  CONSTRAINT fk_bkk_peserta_event_pelamar FOREIGN KEY (pelamar_id) REFERENCES bkk_pelamar(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_berita (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(220) NOT NULL,
  slug VARCHAR(240) NOT NULL,
  thumbnail VARCHAR(255) NULL,
  isi MEDIUMTEXT NOT NULL,
  kategori ENUM('Lowongan','Job Fair','Rekrutmen','Alumni','Kerja Sama','Tips Karier') NOT NULL DEFAULT 'Lowongan',
  penulis VARCHAR(150) NOT NULL,
  status ENUM('Draft','Publish') NOT NULL DEFAULT 'Draft',
  published_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_berita_slug (slug),
  INDEX idx_bkk_berita_publish (status, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_notifikasi (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  judul VARCHAR(180) NOT NULL,
  pesan TEXT NOT NULL,
  tautan VARCHAR(500) NULL,
  dibaca TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bkk_notifikasi_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_bkk_notifikasi_user (user_id, dibaca, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
