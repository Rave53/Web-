-- Migrasi foto program keahlian dan Teaching Factory pada halaman Akademik.
CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

CREATE TABLE IF NOT EXISTS akademik_images (
  slot_key VARCHAR(40) PRIMARY KEY,
  image_path VARCHAR(255) NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
