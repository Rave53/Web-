-- Jalankan sekali pada database lama untuk mengaktifkan status pesan Kontak.
ALTER TABLE pesan_kontak
    ADD COLUMN status ENUM('Menunggu Verifikasi','Diterima','Ditolak')
    NOT NULL DEFAULT 'Menunggu Verifikasi' AFTER pesan;
