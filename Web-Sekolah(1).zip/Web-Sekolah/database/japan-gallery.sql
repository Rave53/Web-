-- Migrasi galeri Magang Jepang untuk database smk_infokom yang sudah ada.
CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

CREATE TABLE IF NOT EXISTS japan_gallery (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT NULL,
  item_type ENUM('image','upload','youtube','text') NOT NULL,
  image_path VARCHAR(255) NULL,
  video_path VARCHAR(255) NULL,
  youtube_id VARCHAR(11) NULL,
  status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'nonaktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_japan_gallery_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
