CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

CREATE TABLE IF NOT EXISTS site_media (
    media_key CHAR(64) PRIMARY KEY,
    source_path TEXT NOT NULL,
    label VARCHAR(255) NOT NULL,
    uploaded_path VARCHAR(255) NULL,
    mime_type VARCHAR(80) NULL,
    file_size INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_site_media_label (label)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
