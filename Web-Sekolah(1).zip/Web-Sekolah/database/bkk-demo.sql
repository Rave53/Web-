-- Data contoh BKK untuk pratinjau lokal. Semua entri diberi label DEMO.
-- Aman dijalankan ulang: tidak membuat duplikat berdasarkan nama/judul.

INSERT INTO bkk_perusahaan (nama, bidang_industri, deskripsi, alamat, kota, website, email, telepon, nama_pic, status, tanggal_mulai_kerja_sama)
SELECT 'DEMO - Digital Nusantara', 'Teknologi Informasi', 'Contoh mitra industri untuk pratinjau modul Bursa Kerja Khusus.', 'Jl. Pajajaran No. 10', 'Bogor', 'https://example.com', 'mitra@example.com', '0251-000000', 'PIC Demo', 'Aktif', CURDATE()
WHERE NOT EXISTS (SELECT 1 FROM bkk_perusahaan WHERE nama = 'DEMO - Digital Nusantara');

INSERT INTO bkk_perusahaan (nama, bidang_industri, deskripsi, alamat, kota, website, email, telepon, nama_pic, status, tanggal_mulai_kerja_sama)
SELECT 'DEMO - Kreasi Visual Studio', 'Kreatif dan Media', 'Contoh perusahaan kreatif untuk data tampilan BKK. Informasi ini bukan lowongan nyata.', 'Jl. Siliwangi No. 5', 'Bogor', 'https://example.org', 'halo@example.org', '0251-111111', 'Kontak Demo', 'Aktif', CURDATE()
WHERE NOT EXISTS (SELECT 1 FROM bkk_perusahaan WHERE nama = 'DEMO - Kreasi Visual Studio');

INSERT INTO bkk_lowongan (perusahaan_id, posisi, lokasi, jenis_pekerjaan, deskripsi, persyaratan, pendidikan, jurusan, skill, dokumen, gaji, jumlah_posisi, tanggal_mulai, deadline, cara_melamar, status, featured)
SELECT p.id, 'DEMO - Junior Web Developer', 'Bogor, Jawa Barat', 'Full-time', 'Contoh lowongan untuk pratinjau tampilan BKK. Data perusahaan dan pekerjaan ini bukan penawaran nyata.', 'Memahami dasar HTML, CSS, JavaScript, dan PHP. Bersedia belajar dan bekerja dalam tim.', 'SMK / Sederajat', 'RPL', 'HTML, CSS, JavaScript, PHP, Git', 'CV dan portofolio', 'Rp4.000.000 - Rp5.000.000 (contoh)', 2, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'Lengkapi profil BKK dan kirim lamaran melalui tombol Daftar Sekarang.', 'Aktif', 1
FROM bkk_perusahaan p WHERE p.nama = 'DEMO - Digital Nusantara'
AND NOT EXISTS (SELECT 1 FROM bkk_lowongan WHERE posisi = 'DEMO - Junior Web Developer');

INSERT INTO bkk_lowongan (perusahaan_id, posisi, lokasi, jenis_pekerjaan, deskripsi, persyaratan, pendidikan, jurusan, skill, dokumen, gaji, jumlah_posisi, tanggal_mulai, deadline, cara_melamar, status, featured)
SELECT p.id, 'DEMO - IT Support Trainee', 'Kota Bogor', 'Magang', 'Contoh posisi magang untuk memperlihatkan status lowongan yang segera berakhir.', 'Mengenal perangkat komputer dan jaringan dasar. Komunikatif dan teliti.', 'SMK / Sederajat', 'TKJ, RPL', 'Troubleshooting, jaringan dasar, komunikasi', 'CV dan surat pengantar sekolah', 'Uang saku (contoh)', 1, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'Ajukan melalui profil pencari kerja BKK.', 'Aktif', 0
FROM bkk_perusahaan p WHERE p.nama = 'DEMO - Digital Nusantara'
AND NOT EXISTS (SELECT 1 FROM bkk_lowongan WHERE posisi = 'DEMO - IT Support Trainee');

INSERT INTO bkk_lowongan (perusahaan_id, posisi, lokasi, jenis_pekerjaan, deskripsi, persyaratan, pendidikan, jurusan, skill, dokumen, gaji, jumlah_posisi, tanggal_mulai, deadline, cara_melamar, status, featured)
SELECT p.id, 'DEMO - Desainer Konten Digital', 'Bogor / Hybrid', 'Kontrak', 'Contoh lowongan berstatus ditutup untuk mengisi filter status.', 'Memiliki minat pada desain visual dan komunikasi digital.', 'SMK / Sederajat', 'DKV, PSPT', 'Desain grafis, fotografi, editing video', 'CV dan portofolio', NULL, 1, DATE_SUB(CURDATE(), INTERVAL 30 DAY), DATE_SUB(CURDATE(), INTERVAL 2 DAY), 'Pendaftaran contoh ini telah ditutup.', 'Ditutup', 0
FROM bkk_perusahaan p WHERE p.nama = 'DEMO - Kreasi Visual Studio'
AND NOT EXISTS (SELECT 1 FROM bkk_lowongan WHERE posisi = 'DEMO - Desainer Konten Digital');

INSERT INTO bkk_event (nama_event, poster, deskripsi, tanggal, waktu, lokasi, perusahaan_ikut, kuota, status)
SELECT 'DEMO - Sesi Persiapan Karier', 'assets/img/Jepang1.jpeg', 'Contoh sesi berbagi tentang penyusunan CV dan persiapan wawancara. Acara ini hanya data pratinjau.', DATE_ADD(CURDATE(), INTERVAL 12 DAY), '09.00 - 12.00 WIB', 'Aula SMK Infokom Bogor', 'DEMO - Digital Nusantara', 80, 'Akan Datang'
WHERE NOT EXISTS (SELECT 1 FROM bkk_event WHERE nama_event = 'DEMO - Sesi Persiapan Karier');

INSERT INTO bkk_event (nama_event, poster, deskripsi, tanggal, waktu, lokasi, perusahaan_ikut, kuota, status)
SELECT 'DEMO - Mini Job Fair Industri Kreatif', 'assets/img/Jepang1.jpeg', 'Contoh agenda temu perusahaan dan siswa/alumni. Bukan pengumuman acara nyata.', DATE_ADD(CURDATE(), INTERVAL 25 DAY), '10.00 - 15.00 WIB', 'Gedung Serbaguna SMK Infokom Bogor', 'DEMO - Kreasi Visual Studio', 120, 'Akan Datang'
WHERE NOT EXISTS (SELECT 1 FROM bkk_event WHERE nama_event = 'DEMO - Mini Job Fair Industri Kreatif');

INSERT INTO bkk_berita (judul, slug, thumbnail, isi, kategori, penulis, status, published_at)
SELECT 'DEMO - Tips Menyiapkan Portofolio Pertama', 'demo-tips-portofolio-pertama', 'assets/img/Jepang1.jpeg', 'Artikel contoh: pilih karya terbaik, jelaskan proses pengerjaan, dan sertakan peranmu pada setiap proyek. Konten ini hanya data pratinjau.', 'Tips Karier', 'Tim BKK (Demo)', 'Publish', NOW()
WHERE NOT EXISTS (SELECT 1 FROM bkk_berita WHERE slug = 'demo-tips-portofolio-pertama');

INSERT INTO bkk_berita (judul, slug, thumbnail, isi, kategori, penulis, status, published_at)
SELECT 'DEMO - Mengenal Proses Rekrutmen', 'demo-mengenal-proses-rekrutmen', 'assets/img/Jepang1.jpeg', 'Artikel contoh yang menjelaskan tahapan umum seleksi administrasi, tes, dan wawancara. Ini bukan pengumuman rekrutmen nyata.', 'Rekrutmen', 'Tim BKK (Demo)', 'Publish', NOW()
WHERE NOT EXISTS (SELECT 1 FROM bkk_berita WHERE slug = 'demo-mengenal-proses-rekrutmen');

INSERT INTO bkk_berita (judul, slug, thumbnail, isi, kategori, penulis, status, published_at)
SELECT 'DEMO - Cerita Alumni Memulai Karier', 'demo-cerita-alumni-karier', 'assets/img/Jepang1.jpeg', 'Artikel contoh untuk pratinjau bagian cerita alumni BKK. Kisah ini bukan testimoni orang nyata.', 'Alumni', 'Tim BKK (Demo)', 'Publish', NOW()
WHERE NOT EXISTS (SELECT 1 FROM bkk_berita WHERE slug = 'demo-cerita-alumni-karier');
