-- Migrasi fitur Video untuk database smk_infokom yang sudah ada.
CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

CREATE TABLE IF NOT EXISTS videos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  description TEXT NULL,
  source_type ENUM('upload','youtube') NOT NULL,
  video_path VARCHAR(255) NULL,
  youtube_id VARCHAR(11) NULL,
  thumbnail_path VARCHAR(255) NULL,
  status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'nonaktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_videos_status_created (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
