-- Migrasi media untuk halaman Kunjungan Industri dan Mitra Kerja.
CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

CREATE TABLE IF NOT EXISTS page_media (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  page_key ENUM('kunjungan_industri','mitra_kerja') NOT NULL,
  title VARCHAR(200) NOT NULL,
  image_path VARCHAR(255) NOT NULL,
  status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_page_media_page_status (page_key, status, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
