-- Migrasi BKK untuk database smk_infokom.
-- Migrasi tambahan BKK tanpa menggandakan tabel sekolah yang sudah ada.

CREATE DATABASE IF NOT EXISTS `smk_infokom` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `smk_infokom`;

ALTER TABLE users
  MODIFY role ENUM('admin','admin_bkk','siswa','alumni','ortu') NOT NULL;

CREATE TABLE IF NOT EXISTS bkk_settings (
  id TINYINT UNSIGNED PRIMARY KEY DEFAULT 1,
  nama_bkk VARCHAR(150) NOT NULL DEFAULT 'Bursa Kerja Khusus SMK Infokom Bogor',
  deskripsi TEXT NULL,
  alamat VARCHAR(255) NULL,
  email VARCHAR(150) NULL,
  telepon VARCHAR(40) NULL,
  video_url VARCHAR(500) NULL,
  logo VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO bkk_settings (id) VALUES (1);

CREATE TABLE IF NOT EXISTS bkk_perusahaan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(180) NOT NULL,
  logo VARCHAR(255) NULL,
  bidang_industri VARCHAR(120) NOT NULL DEFAULT '',
  deskripsi TEXT NULL,
  alamat VARCHAR(255) NULL,
  kota VARCHAR(100) NULL,
  website VARCHAR(255) NULL,
  email VARCHAR(150) NULL,
  telepon VARCHAR(40) NULL,
  nama_pic VARCHAR(150) NULL,
  status ENUM('Aktif','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
  tanggal_mulai_kerja_sama DATE NULL,
  tanggal_akhir_kerja_sama DATE NULL,
  dokumen_mou VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_lowongan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  perusahaan_id INT UNSIGNED NOT NULL,
  posisi VARCHAR(180) NOT NULL,
  lokasi VARCHAR(150) NOT NULL,
  jenis_pekerjaan VARCHAR(80) NOT NULL,
  deskripsi MEDIUMTEXT NOT NULL,
  persyaratan MEDIUMTEXT NULL,
  pendidikan VARCHAR(100) NULL,
  jurusan VARCHAR(180) NULL,
  skill TEXT NULL,
  dokumen TEXT NULL,
  gaji VARCHAR(100) NULL,
  jumlah_posisi SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  tanggal_mulai DATE NULL,
  deadline DATE NOT NULL,
  link_pendaftaran VARCHAR(500) NULL,
  cara_melamar TEXT NULL,
  status ENUM('Aktif','Ditutup') NOT NULL DEFAULT 'Aktif',
  featured TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_bkk_lowongan_perusahaan FOREIGN KEY (perusahaan_id) REFERENCES bkk_perusahaan(id) ON DELETE RESTRICT,
  INDEX idx_bkk_lowongan_status_deadline (status, deadline),
  INDEX idx_bkk_lowongan_jurusan (jurusan),
  INDEX idx_bkk_lowongan_lokasi (lokasi)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_pelamar (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  nisn VARCHAR(30) NULL,
  status_pelamar ENUM('Siswa','Alumni') NOT NULL DEFAULT 'Siswa',
  tahun_lulus YEAR NULL,
  jurusan VARCHAR(100) NOT NULL,
  no_hp VARCHAR(40) NOT NULL,
  email VARCHAR(150) NOT NULL,
  domisili VARCHAR(150) NOT NULL,
  cv VARCHAR(255) NULL,
  sertifikat VARCHAR(255) NULL,
  portofolio VARCHAR(500) NULL,
  skill TEXT NULL,
  pengalaman TEXT NULL,
  status ENUM('Aktif','Bekerja','Tidak Aktif') NOT NULL DEFAULT 'Aktif',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_pelamar_user (user_id),
  CONSTRAINT fk_bkk_pelamar_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_bkk_pelamar_jurusan (jurusan),
  INDEX idx_bkk_pelamar_status (status_pelamar)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_lamaran (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pelamar_id INT UNSIGNED NOT NULL,
  lowongan_id INT UNSIGNED NOT NULL,
  tanggal_melamar TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Lamaran Masuk','Seleksi Administrasi','Tes','Interview','Diterima','Ditolak') NOT NULL DEFAULT 'Lamaran Masuk',
  catatan_admin TEXT NULL,
  catatan_perusahaan TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_lamaran_pelamar_lowongan (pelamar_id, lowongan_id),
  CONSTRAINT fk_bkk_lamaran_pelamar FOREIGN KEY (pelamar_id) REFERENCES bkk_pelamar(id) ON DELETE CASCADE,
  CONSTRAINT fk_bkk_lamaran_lowongan FOREIGN KEY (lowongan_id) REFERENCES bkk_lowongan(id) ON DELETE CASCADE,
  INDEX idx_bkk_lamaran_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_riwayat_lamaran (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  lamaran_id INT UNSIGNED NOT NULL,
  status ENUM('Lamaran Masuk','Seleksi Administrasi','Tes','Interview','Diterima','Ditolak') NOT NULL,
  catatan TEXT NULL,
  tanggal TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bkk_riwayat_lamaran FOREIGN KEY (lamaran_id) REFERENCES bkk_lamaran(id) ON DELETE CASCADE,
  INDEX idx_bkk_riwayat_tanggal (lamaran_id, tanggal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_event (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama_event VARCHAR(180) NOT NULL,
  poster VARCHAR(255) NULL,
  deskripsi TEXT NULL,
  tanggal DATE NOT NULL,
  waktu VARCHAR(80) NULL,
  lokasi VARCHAR(180) NOT NULL,
  perusahaan_ikut TEXT NULL,
  kuota SMALLINT UNSIGNED NULL,
  link_pendaftaran VARCHAR(500) NULL,
  status ENUM('Akan Datang','Sedang Berlangsung','Selesai') NOT NULL DEFAULT 'Akan Datang',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_bkk_event_tanggal (tanggal, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_peserta_event (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  event_id INT UNSIGNED NOT NULL,
  pelamar_id INT UNSIGNED NOT NULL,
  status ENUM('Terdaftar','Hadir','Batal') NOT NULL DEFAULT 'Terdaftar',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_peserta_event (event_id, pelamar_id),
  CONSTRAINT fk_bkk_peserta_event_event FOREIGN KEY (event_id) REFERENCES bkk_event(id) ON DELETE CASCADE,
  CONSTRAINT fk_bkk_peserta_event_pelamar FOREIGN KEY (pelamar_id) REFERENCES bkk_pelamar(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_berita (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  judul VARCHAR(220) NOT NULL,
  slug VARCHAR(240) NOT NULL,
  thumbnail VARCHAR(255) NULL,
  isi MEDIUMTEXT NOT NULL,
  kategori ENUM('Lowongan','Job Fair','Rekrutmen','Alumni','Kerja Sama','Tips Karier') NOT NULL DEFAULT 'Lowongan',
  penulis VARCHAR(150) NOT NULL,
  status ENUM('Draft','Publish') NOT NULL DEFAULT 'Draft',
  published_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_bkk_berita_slug (slug),
  INDEX idx_bkk_berita_publish (status, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bkk_notifikasi (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  judul VARCHAR(180) NOT NULL,
  pesan TEXT NOT NULL,
  tautan VARCHAR(500) NULL,
  dibaca TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bkk_notifikasi_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_bkk_notifikasi_user (user_id, dibaca, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
