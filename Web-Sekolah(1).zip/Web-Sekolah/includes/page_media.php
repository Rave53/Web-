<?php

function page_media_items(?string $page = null): array
{
    global $pdo;

    if ($page !== null) {
        $stmt = $pdo->prepare("SELECT id, page_key, title, image_path FROM page_media WHERE page_key = ? AND status = 'aktif' ORDER BY sort_order ASC, id DESC");
        $stmt->execute([$page]);
        return $stmt->fetchAll();
    }

    return $pdo->query('SELECT id, page_key, title, image_path, status FROM page_media ORDER BY page_key ASC, sort_order ASC, id DESC')->fetchAll();
}
