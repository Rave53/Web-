<?php
require_once __DIR__ . '/../config.php';

/** Ambil data user yang sedang login, atau null. */
function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

/** Halaman login yang sesuai untuk sebuah role. */
function role_login_page(string $role): string
{
    return match ($role) {
        'admin', 'admin_bkk' => 'admin-login.php',
        'siswa', 'alumni' => 'portal-siswa-login.php',
        'ortu'  => 'portal-ortu-login.php',
        default => 'portal.php',
    };
}

/** Halaman dashboard yang sesuai untuk sebuah role. */
function role_dashboard_page(string $role): string
{
    return match ($role) {
        'admin' => 'admin-dashboard.php',
        'admin_bkk' => 'admin-bkk.php',
        'siswa' => 'siswa-dashboard.php',
        'alumni' => 'bkk.php',
        'ortu'  => 'ortu-dashboard.php',
        default => 'index.php',
    };
}

/** Wajibkan login dengan role tertentu, redirect ke halaman login jika belum. */
function require_role(string $role): array
{
    $user = current_user();
    if (!$user || $user['role'] !== $role) {
        header('Location: ' . role_login_page($role));
        exit;
    }
    return $user;
}

/** Coba login. Mengembalikan true/false. */
function attempt_login(PDO $pdo, string $username, string $password, string $role): bool
{
    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? AND role = ? LIMIT 1');
    $stmt->execute([$username, $role]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id'       => $user['id'],
            'username' => $user['username'],
            'nama'     => $user['nama'],
            'role'     => $user['role'],
            'ref_id'   => $user['ref_id'],
        ];
        return true;
    }
    return false;
}

function h(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
