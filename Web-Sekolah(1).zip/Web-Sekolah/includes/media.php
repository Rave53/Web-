<?php
require_once __DIR__ . '/../config.php';

function media_normalize_source(string $source): string
{
    $source = html_entity_decode(trim($source), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (preg_match('~^https?://~i', $source)) {
        return $source;
    }

    $source = str_replace('\\', '/', $source);
    while (str_starts_with($source, '../')) {
        $source = substr($source, 3);
    }
    return rawurldecode($source);
}

function media_source_key(string $source): string
{
    return hash('sha256', media_normalize_source($source));
}

function site_media_url(string $source): string
{
    static $cache = [];
    $normalized = media_normalize_source($source);
    $key = hash('sha256', $normalized);
    if (!array_key_exists($key, $cache)) {
        global $pdo;
        $stmt = $pdo->prepare('SELECT uploaded_path FROM site_media WHERE media_key = ? LIMIT 1');
        $stmt->execute([$key]);
        $cache[$key] = $stmt->fetchColumn() ?: null;
    }

    return $cache[$key] ?? $normalized;
}

function site_media_html(string $source): string
{
    return htmlspecialchars(site_media_url($source), ENT_QUOTES, 'UTF-8');
}

function media_upload_image(array $file, string $mediaKey): array
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Unggahan gagal diterima. Silakan coba lagi.');
    }
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('File gambar tidak diterima sebagai unggahan yang valid.');
    }
    if (($file['size'] ?? 0) < 1 || $file['size'] > 5 * 1024 * 1024) {
        throw new RuntimeException('Ukuran gambar harus lebih dari 0 dan tidak melebihi 5 MB.');
    }

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $extensions = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
        'image/gif' => 'gif',
    ];
    if (!isset($extensions[$mime]) || @getimagesize($file['tmp_name']) === false) {
        throw new RuntimeException('Format gambar harus JPG, PNG, WebP, atau GIF yang valid.');
    }

    $directory = __DIR__ . '/../uploads/media';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('Folder media tidak dapat dibuat.');
    }

    $filename = $mediaKey . '.' . $extensions[$mime];
    $targetPath = $directory . '/' . $filename;
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new RuntimeException('File gambar tidak dapat disimpan.');
    }

    return ['path' => 'uploads/media/' . $filename, 'mime' => $mime, 'size' => (int) $file['size']];
}
