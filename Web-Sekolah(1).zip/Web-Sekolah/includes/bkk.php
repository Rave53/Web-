<?php
require_once __DIR__ . '/auth.php';

function bkk_csrf_token(): string
{
    if (empty($_SESSION['bkk_csrf'])) {
        $_SESSION['bkk_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['bkk_csrf'];
}

function bkk_verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(bkk_csrf_token(), $token)) {
        http_response_code(419);
        exit('Sesi formulir kedaluwarsa. Muat ulang halaman lalu coba lagi.');
    }
}

function bkk_require_roles(array $roles): array
{
    $user = current_user();
    if (!$user || !in_array($user['role'], $roles, true)) {
        $target = in_array('admin_bkk', $roles, true) ? 'admin-login.php' : 'portal-siswa-login.php';
        header('Location: ' . $target);
        exit;
    }
    return $user;
}

function bkk_upload(array $file, string $kind): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'] ?? '')) {
        throw new RuntimeException('Berkas gagal diunggah.');
    }

    $limits = [
        'cv' => ['application/pdf' => 'pdf', 'application/msword' => 'doc', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx'],
        'image' => ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'],
    ];
    if (!isset($limits[$kind]) || $file['size'] > ($kind === 'cv' ? 5 : 3) * 1024 * 1024) {
        throw new RuntimeException('Ukuran berkas melewati batas yang diizinkan.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!isset($limits[$kind][$mime])) {
        throw new RuntimeException('Format berkas tidak diizinkan.');
    }

    $subdirectory = $kind === 'image' ? 'media' : 'private';
    $directory = __DIR__ . '/../uploads/bkk/' . $subdirectory;
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('Folder unggahan tidak dapat dibuat.');
    }
    $filename = bin2hex(random_bytes(20)) . '.' . $limits[$kind][$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
        throw new RuntimeException('Berkas tidak dapat disimpan.');
    }
    return 'uploads/bkk/' . $subdirectory . '/' . $filename;
}

function bkk_safe_return(string $value, string $fallback = 'bkk.php'): string
{
    return preg_match('/^(bkk\.php|admin-bkk\.php)(\?.*)?$/', $value) ? $value : $fallback;
}

function bkk_video_embed_src(string $url): ?string
{
    $raw = trim((string) $url);
    if ($raw === '') {
        return null;
    }

    if (preg_match('#(?:youtube\.com/(?:watch\?v=|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})#i', $raw, $matches)) {
        return 'https://www.youtube.com/embed/' . $matches[1] . '?autoplay=1&mute=1&rel=0';
    }

    if (preg_match('#instagram\.com/(?:p|reel|tv)/([^/?#]+)#i', $raw, $matches)) {
        $medium = preg_match('#instagram\.com/(?:reel|tv)/#i', $raw) ? 'reel' : 'p';
        return 'https://www.instagram.com/' . $medium . '/' . $matches[1] . '/embed/?autoplay=1&mute=1';
    }

    if (preg_match('#^https?://(?:www\.)?(?:youtube\.com|youtu\.be|instagram\.com)/#i', $raw)) {
        return $raw;
    }

    return null;
}

function bkk_render_video_embed(?string $url): string
{
    $src = bkk_video_embed_src((string) $url);
    if ($src === null || $src === '') {
        return '';
    }

    return '<div class="bkk-video-embed"><iframe src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '" title="Video BKK / PKL" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>';
}

function bkk_notify_users(PDO $pdo, string $title, string $message, string $link): void
{
    $notify = $pdo->prepare("INSERT INTO bkk_notifikasi (user_id, judul, pesan, tautan)
        SELECT id, ?, ?, ? FROM users WHERE role IN ('siswa', 'alumni')");
    $notify->execute([$title, $message, $link]);
}
