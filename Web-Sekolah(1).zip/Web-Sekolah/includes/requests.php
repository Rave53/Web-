<?php

function request_csrf_token(): string
{
    if (empty($_SESSION['requests_csrf_token'])) {
        $_SESSION['requests_csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['requests_csrf_token'];
}

function request_verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(request_csrf_token(), $token)) {
        throw new RuntimeException('Sesi formulir tidak valid. Muat ulang halaman dan coba lagi.');
    }
}
