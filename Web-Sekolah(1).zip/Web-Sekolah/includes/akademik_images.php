<?php

function akademik_image_slots(): array
{
    return [
        'program_rpl' => [
            'label' => 'Foto Program Rekayasa Perangkat Lunak',
            'default' => 'https://images.pexels.com/photos/10638075/pexels-photo-10638075.jpeg?auto=compress&cs=tinysrgb&w=700',
        ],
        'program_tkj' => [
            'label' => 'Foto Program Teknik Komputer & Jaringan',
            'default' => 'https://images.pexels.com/photos/4508751/pexels-photo-4508751.jpeg?auto=compress&cs=tinysrgb&w=700',
        ],
        'program_pspt' => [
            'label' => 'Foto Program PSPT',
            'default' => 'https://images.pexels.com/photos/713149/pexels-photo-713149.jpeg?auto=compress&cs=tinysrgb&w=700',
        ],
        'program_dkv' => [
            'label' => 'Foto Program DKV',
            'default' => 'https://images.pexels.com/photos/7610533/pexels-photo-7610533.jpeg?auto=compress&cs=tinysrgb&w=700',
        ],
        'factory_rpl' => [
            'label' => 'Logo Teaching Factory RPL',
            'default' => 'assets/img/TEACING FACTORY(2).png',
        ],
        'factory_tkj' => [
            'label' => 'Logo Teaching Factory TKJ',
            'default' => 'assets/img/TEACING FACTORY(1).png',
        ],
        'factory_pspt' => [
            'label' => 'Logo Teaching Factory PSPT',
            'default' => 'assets/img/TEACING FACTORY(3).png',
        ],
        'factory_dkv' => [
            'label' => 'Logo Teaching Factory DKV',
            'default' => 'assets/img/TEACING FACTORY.png',
        ],
    ];
}

function akademik_image_paths(): array
{
    global $pdo;

    $paths = [];
    $stmt = $pdo->query('SELECT slot_key, image_path FROM akademik_images');
    foreach ($stmt->fetchAll() as $image) {
        $paths[$image['slot_key']] = $image['image_path'];
    }

    return $paths;
}
