<?php

function gallery_images(): array
{
    global $pdo;

    return $pdo->query("SELECT id, judul, kategori, foto FROM galeri WHERE foto IS NOT NULL AND foto <> '' ORDER BY id DESC")->fetchAll();
}

function gallery_image_slots(): array
{
    return [
        'home_hero' => ['label' => 'Beranda — Foto utama', 'category' => 'fasilitas', 'keywords' => ['gedung utama', 'area smk']],
        'home_profile' => ['label' => 'Beranda — Profil Sekolah', 'category' => 'fasilitas', 'keywords' => ['gedung', 'area smk']],
        'home_academic' => ['label' => 'Beranda — Akademik', 'category' => 'akademik', 'keywords' => ['praktik pemrograman', 'kelas praktik', 'aktivitas lab']],
        'home_teachers' => ['label' => 'Beranda — Guru & Tenaga Pendidik', 'category' => 'kegiatan', 'keywords' => ['guru', 'tenaga pendidik', 'pengajar']],
        'home_ppdb' => ['label' => 'Beranda — PPDB', 'category' => null, 'keywords' => ['ppdb', 'pendaftaran', 'siswa baru']],
        'home_info' => ['label' => 'Beranda — Info & Berita', 'category' => 'kegiatan', 'keywords' => ['workshop', 'sesi kerja tim', 'produksi konten']],
        'profile_main' => ['label' => 'Profil — Gedung sekolah', 'category' => 'fasilitas', 'keywords' => ['gedung utama', 'area smk']],
        'profile_activities' => ['label' => 'Profil — Kegiatan sekolah', 'category' => 'kegiatan', 'keywords' => ['workshop', 'sesi kerja tim']],
        'profile_academic' => ['label' => 'Profil — Kegiatan akademik', 'category' => 'akademik', 'keywords' => ['praktik pemrograman', 'kelas praktik', 'aktivitas lab']],
        'profile_library' => ['label' => 'Profil — Perpustakaan', 'category' => 'fasilitas', 'keywords' => ['perpustakaan', 'kantin']],
        'profile_lab' => ['label' => 'Profil — Lab Komputer & Jaringan', 'category' => 'akademik', 'keywords' => ['aktivitas lab', 'kelas praktik']],
        'profile_multimedia' => ['label' => 'Profil — Studio DKV', 'category' => 'kegiatan', 'keywords' => ['produksi konten dkv', 'studio dkv', 'videografi', 'fotografi']],
        'profile_server' => ['label' => 'Profil — Ruang Server', 'category' => 'fasilitas', 'keywords' => ['server', 'jaringan']],
        'profile_library_facility' => ['label' => 'Profil — Fasilitas perpustakaan digital', 'category' => 'fasilitas', 'keywords' => ['perpustakaan']],
    ];
}

function gallery_page_image_selections(): array
{
    global $pdo;

    $rows = $pdo->query('SELECT slot_key, gallery_id FROM page_image_slots')->fetchAll();
    $selections = [];
    foreach ($rows as $row) {
        if ($row['gallery_id'] !== null) {
            $selections[$row['slot_key']] = (int) $row['gallery_id'];
        }
    }

    return $selections;
}

function gallery_image_for_display(array $images, array $selections, string $slotKey, ?string $category, array $titleKeywords, string $fallback): string
{
    $selectedId = $selections[$slotKey] ?? null;
    if ($selectedId !== null) {
        foreach ($images as $image) {
            if ((int) $image['id'] === $selectedId) {
                return (string) $image['foto'];
            }
        }
    }

    $matchingImages = array_values(array_filter(
        $images,
        static function (array $image) use ($category, $titleKeywords): bool {
            if ($category !== null && $image['kategori'] !== $category) {
                return false;
            }

            $title = strtolower((string) $image['judul']);
            foreach ($titleKeywords as $keyword) {
                if (str_contains($title, strtolower($keyword))) {
                    return true;
                }
            }

            return false;
        }
    ));

    if (!$matchingImages) {
        return $fallback;
    }

    usort(
        $matchingImages,
        static function (array $left, array $right) use ($titleKeywords): int {
            $score = static function (array $image) use ($titleKeywords): int {
                $title = strtolower((string) $image['judul']);
                $matches = array_filter(
                    $titleKeywords,
                    static fn(string $keyword): bool => str_contains($title, strtolower($keyword))
                );

                return $matches ? max(array_map('strlen', $matches)) : 0;
            };

            return $score($right) <=> $score($left);
        }
    );

    return (string) $matchingImages[0]['foto'];
}
