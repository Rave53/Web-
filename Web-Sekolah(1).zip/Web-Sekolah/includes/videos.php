<?php

function video_csrf_token(): string
{
    if (empty($_SESSION['video_csrf_token'])) {
        $_SESSION['video_csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['video_csrf_token'];
}

function video_verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals(video_csrf_token(), $token)) {
        throw new RuntimeException('Sesi formulir tidak valid. Muat ulang halaman dan coba lagi.');
    }
}

function video_youtube_id(string $url): ?string
{
    $parts = parse_url(trim($url));
    if (!is_array($parts) || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)) {
        return null;
    }

    $host = strtolower($parts['host'] ?? '');
    $path = trim($parts['path'] ?? '', '/');
    $id = null;
    if (in_array($host, ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtube-nocookie.com', 'www.youtube-nocookie.com'], true)) {
        if ($path === 'watch') {
            parse_str($parts['query'] ?? '', $query);
            $id = $query['v'] ?? null;
        } elseif (preg_match('~^(?:embed|shorts)/([A-Za-z0-9_-]{11})$~', $path, $matches)) {
            $id = $matches[1];
        }
    } elseif (in_array($host, ['youtu.be', 'www.youtu.be'], true) && preg_match('~^([A-Za-z0-9_-]{11})$~', $path, $matches)) {
        $id = $matches[1];
    }

    return is_string($id) && preg_match('/^[A-Za-z0-9_-]{11}$/', $id) ? $id : null;
}

function video_store_upload(array $file, string $kind): ?array
{
    $error = $file['error'] ?? UPLOAD_ERR_NO_FILE;
    if ($error === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($error !== UPLOAD_ERR_OK || !isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
        throw new RuntimeException('Unggahan gagal diterima. Periksa batas unggahan server lalu coba lagi.');
    }

    $size = (int) ($file['size'] ?? 0);
    $isVideo = $kind === 'video';
    $maxSize = $isVideo ? 100 * 1024 * 1024 : 5 * 1024 * 1024;
    if ($size < 1 || $size > $maxSize) {
        $limit = $isVideo ? '100 MB' : '5 MB';
        $label = $isVideo ? 'Video' : (in_array($kind, ['gallery_image', 'page_media', 'akademik_image'], true) ? 'Gambar' : 'Thumbnail');
        throw new RuntimeException("Ukuran {$label} harus lebih dari 0 dan tidak melebihi {$limit}.");
    }

    $allowed = $isVideo
        ? ['video/mp4' => 'mp4', 'video/webm' => 'webm', 'video/ogg' => 'ogv']
        : ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
    if (!is_string($mime) || !isset($allowed[$mime])) {
        throw new RuntimeException($isVideo
            ? 'Format video harus MP4, WebM, atau Ogg yang valid.'
            : 'Gambar harus berupa JPG, PNG, atau WebP yang valid.');
    }
    if (!$isVideo && @getimagesize($file['tmp_name']) === false) {
        throw new RuntimeException('File gambar bukan gambar yang valid.');
    }

    $directoryName = match ($kind) {
        'video' => 'videos',
        'thumbnail' => 'video-thumbnails',
        'gallery_image' => 'japan-gallery',
        'page_media' => 'page-media',
        'akademik_image' => 'akademik',
        default => throw new RuntimeException('Jenis unggahan tidak dikenal.'),
    };
    $directory = __DIR__ . '/../uploads/' . $directoryName;
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException("Folder unggahan {$kind} tidak dapat dibuat.");
    }

    $filename = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $directory . '/' . $filename)) {
        throw new RuntimeException("File {$kind} tidak dapat disimpan.");
    }

    return [
        'path' => 'uploads/' . $directoryName . '/' . $filename,
        'mime' => $mime,
        'size' => $size,
    ];
}

function video_delete_upload(?string $path): void
{
    if ($path === null || $path === '') {
        return;
    }
    if (!preg_match('~^uploads/videos/[a-f0-9]{32}\.(?:mp4|webm|ogv)$|^uploads/(?:video-thumbnails|japan-gallery|page-media|akademik)/[a-f0-9]{32}\.(?:jpg|png|webp)$~', $path)) {
        throw new RuntimeException('Path file video tidak valid; file tidak dihapus.');
    }

    $absolutePath = __DIR__ . '/../' . $path;
    if (is_file($absolutePath) && !unlink($absolutePath)) {
        throw new RuntimeException('Data berhasil diperbarui, tetapi file lama tidak dapat dihapus.');
    }
}
