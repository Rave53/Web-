<?php
/**
 * Konfigurasi generik untuk fitur "Kelola Konten" admin.
 * Setiap entri di sini otomatis mendapat halaman CRUD (Tambah/Edit/Hapus)
 * di admin-kelola.php?entity=<key>
 */

function crud_entities(): array
{
    return [
        'guru' => [
            'table' => 'guru',
            'label' => 'Guru & Staf',
            'label_singular' => 'Guru',
            'order_by' => 'nama ASC',
            'fields' => [
                'nama'      => ['label' => 'Nama Lengkap', 'type' => 'text', 'required' => true],
                'jabatan'   => ['label' => 'Jabatan', 'type' => 'text', 'placeholder' => 'Contoh: Guru Matematika'],
                'kategori'  => ['label' => 'Program (untuk filter)', 'type' => 'select',
                    'options' => ['umum' => 'Umum', 'rpl' => 'RPL', 'tkj' => 'TKJ', 'dkv' => 'DKV (Desain Komunikasi Visual)', 'pspt' => 'PSPT', 'rpl tkj dkv pspt umum' => 'Semua Program'],
                ],
                'mapel'     => ['label' => 'Mata Pelajaran', 'type' => 'text'],
                'no_hp'     => ['label' => 'No. HP', 'type' => 'text'],
                'deskripsi' => ['label' => 'Deskripsi Singkat', 'type' => 'textarea'],
                'foto'      => ['label' => 'Foto', 'type' => 'image'],
            ],
            'list_cols' => ['foto', 'nama', 'jabatan', 'kategori'],
        ],
        'berita' => [
            'table' => 'berita',
            'label' => 'Berita & Prestasi',
            'label_singular' => 'Berita',
            'order_by' => 'tanggal DESC',
            'fields' => [
                'judul'     => ['label' => 'Judul', 'type' => 'text', 'required' => true],
                'ringkasan' => ['label' => 'Ringkasan Singkat', 'type' => 'textarea'],
                'kategori'  => ['label' => 'Kategori', 'type' => 'select',
                    'options' => ['prestasi' => 'Prestasi', 'kegiatan' => 'Kegiatan', 'pengumuman' => 'Pengumuman'],
                ],
                'tanggal'   => ['label' => 'Tanggal', 'type' => 'date', 'required' => true],
                'foto'      => ['label' => 'Foto', 'type' => 'image'],
            ],
            'list_cols' => ['foto', 'judul', 'kategori', 'tanggal'],
        ],
        'galeri' => [
            'table' => 'galeri',
            'label' => 'Galeri Foto',
            'label_singular' => 'Foto',
            'order_by' => 'id DESC',
            'fields' => [
                'judul'    => ['label' => 'Judul / Keterangan', 'type' => 'text', 'required' => true],
                'kategori' => ['label' => 'Kategori', 'type' => 'select',
                    'options' => ['kegiatan' => 'Kegiatan', 'prestasi' => 'Prestasi', 'akademik' => 'Akademik', 'fasilitas' => 'Fasilitas'],
                ],
                'foto'     => ['label' => 'Foto', 'type' => 'image', 'required' => true],
            ],
            'list_cols' => ['foto', 'judul', 'kategori'],
        ],
        'ekstrakurikuler' => [
            'table' => 'ekstrakurikuler',
            'label' => 'Ekstrakurikuler',
            'label_singular' => 'Ekstrakurikuler',
            'order_by' => 'nama ASC',
            'fields' => [
                'nama'      => ['label' => 'Nama Ekskul', 'type' => 'text', 'required' => true],
                'kategori'  => ['label' => 'Kategori', 'type' => 'select',
                    'options' => ['teknologi' => 'Teknologi', 'seni' => 'Seni & Kreatif', 'olahraga' => 'Olahraga', 'organisasi' => 'Organisasi'],
                ],
                'deskripsi' => ['label' => 'Deskripsi', 'type' => 'textarea'],
                'pembina'   => ['label' => 'Pembina', 'type' => 'text'],
                'jadwal'    => ['label' => 'Jadwal', 'type' => 'text', 'placeholder' => 'Contoh: Selasa & Kamis, 15.30'],
                'foto'      => ['label' => 'Foto', 'type' => 'image'],
            ],
            'list_cols' => ['foto', 'nama', 'kategori', 'pembina'],
        ],
        'siswa' => [
            'table' => 'siswa',
            'label' => 'Data Siswa',
            'label_singular' => 'Siswa',
            'order_by' => 'nama ASC',
            'fields' => [
                'nisn'             => ['label' => 'NISN', 'type' => 'text', 'required' => true],
                'nama'             => ['label' => 'Nama', 'type' => 'text', 'required' => true],
                'kelas'            => ['label' => 'Kelas', 'type' => 'text', 'required' => true],
                'jk'               => ['label' => 'Jenis Kelamin', 'type' => 'select', 'options' => ['Laki-laki' => 'Laki-laki', 'Perempuan' => 'Perempuan']],
                'rata_nilai'       => ['label' => 'Rata-rata Nilai', 'type' => 'number', 'step' => '0.01'],
                'kehadiran_persen' => ['label' => 'Kehadiran (%)', 'type' => 'number', 'step' => '0.01'],
                'peringkat'        => ['label' => 'Peringkat', 'type' => 'text', 'placeholder' => 'Contoh: 5 dari 34'],
                'status_spp'       => ['label' => 'Status SPP', 'type' => 'select', 'options' => ['Lunas' => 'Lunas', 'Belum Bayar' => 'Belum Bayar']],
            ],
            'list_cols' => ['nisn', 'nama', 'kelas', 'status_spp'],
        ],
        'kelas' => [
            'table' => 'kelas',
            'label' => 'Data Kelas',
            'label_singular' => 'Kelas',
            'order_by' => 'nama_kelas ASC',
            'fields' => [
                'nama_kelas'   => ['label' => 'Nama Kelas', 'type' => 'text', 'required' => true],
                'wali_kelas'   => ['label' => 'Wali Kelas', 'type' => 'text'],
                'jumlah_siswa' => ['label' => 'Jumlah Siswa', 'type' => 'number'],
            ],
            'list_cols' => ['nama_kelas', 'wali_kelas', 'jumlah_siswa'],
        ],
        'orang_tua' => [
            'table' => 'orang_tua',
            'label' => 'Data Orang Tua',
            'label_singular' => 'Orang Tua',
            'order_by' => 'nama ASC',
            'fields' => [
                'nama'     => ['label' => 'Nama Orang Tua', 'type' => 'text', 'required' => true],
                'telepon'  => ['label' => 'No. Telepon', 'type' => 'text'],
                'siswa_id' => ['label' => 'Anak (Siswa)', 'type' => 'select_query',
                    'query' => 'SELECT id, nama FROM siswa ORDER BY nama', 'required' => true],
            ],
            'list_cols' => ['nama', 'telepon', 'siswa_id'],
        ],
    ];
}

function crud_upload_image(array $file): ?string
{
    if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] === 0) {
        return null;
    }
    $allowed = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif'];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) {
        return null;
    }
    $dir = __DIR__ . '/../uploads';
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $filename = uniqid('img_', true) . '.' . $ext;
    if (move_uploaded_file($file['tmp_name'], $dir . '/' . $filename)) {
        return 'uploads/' . $filename;
    }
    return null;
}
