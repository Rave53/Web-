<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/gallery.php';
$galleryImages = gallery_images();
$galleryImageSelections = gallery_page_image_selections();
?>
<!DOCTYPE html> 
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMK Infokom Bogor | Sekolah Menengah Kejuruan Informatika dan Komunikasi</title>
<meta name="description" content="SMK Infokom Bogor merupakan sekolah menengah kejuruan di bidang informatika dan komunikasi yang berlokasi di Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Tentang Kami</a>
    <a href="ppdb.php">Pendaftaran PPDB</a>
    <a href="portal.php">Portal Siswa dan Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika dan Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil dan Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi dan Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer dan Jaringan</a>
            <a href="akademik.php">Desain Komunikasi Visual</a>
            <a href="akademik.php">Produksi dan Siaran Program Televisi</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas dan Laboratorium</a>
            
            
            
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info dan Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil dan Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi dan Misi</a>
  <a href="guru.php">Guru dan Tenaga Pendidik</a>
  <a href="siswa.php">Siswa dan Prestasi</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info dan Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="hero" id="top">
  <div class="hero-scene"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'home_hero', 'fasilitas', ['gedung utama', 'area smk'], 'uploads/GEDUNG DEPAN.png')) ?>" alt="" style="width:100%;height:100%;object-fit:cover;"></div>
  <div class="hero-overlay"></div>
  <div class="wrap hero-content">
    <div class="home-hero-copy">
      <svg class="squiggle" viewBox="0 0 150 26"><path d="M2 20C20 4 32 4 50 14C68 24 80 24 98 14C112 6 124 6 148 16"/></svg>
      <h1 class="split">Selamat Datang</h1>
      <p class="hero-sub load-in">Temukan peluang pengembangan diri di bidang teknologi melalui pembelajaran Rekayasa Perangkat Lunak, Teknik Komputer dan Jaringan, Desain Komunikasi Visual, atau Produksi dan Siaran Program Televisi berbasis praktik sejak kelas 10 di SMK Infokom Bogor.</p>
      <div class="hero-actions load-in">
        <a href="ppdb.php#ppdb-form" class="btn btn-gold">Daftar PPDB <svg width="16" height="16" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        <a href="akademik.php" class="btn btn-line">Lihat Program Keahlian <svg width="16" height="16" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
      </div>
    </div>
  </div>
</header>

<div class="ribbon" id="ribbon">
  <div class="wrap">
    <div class="ribbon-badge">PPDB<br>DIBUKA</div>
    <div class="ribbon-body">
      <h3>Pendaftaran Gelombang 1 Tahun Ajaran 2027/2028 Resmi Dibuka</h3>
      <p>Daftarkan diri lebih awal untuk memperoleh kesempatan lebih besar dalam memilih program keahlian yang diutamakan.</p>
    </div>
    <div class="ribbon-actions">
      <a href="ppdb.php" class="btn btn-navy" style="padding:11px 20px;">Daftar Siswa Baru</a>
    </div>
    <button class="ribbon-close" id="ribbonClose" aria-label="Tutup pengumuman">&times;</button>
  </div>
</div>

<section style="padding:70px 0 20px;">
  <div class="wrap">
    <div class="section-head reveal" style="text-align:center;margin:0 auto 44px;max-width:520px;">
      <h2 class="split" style="font-size:clamp(22px,2.6vw,28px);">Informasi Terbaru</h2>
    </div>
    <div class="reveal" data-stagger style="display:grid;grid-template-columns:repeat(4,1fr);gap:22px;">
      <a href="info.php" style="text-align:center;text-decoration:none;">
        <div style="width:58px;height:58px;border-radius:50%;background:var(--navy);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M4 10v4a1 1 0 001 1h2l5 4V5L7 9H5a1 1 0 00-1 1z" stroke="#C9A227" stroke-width="1.6" stroke-linejoin="round"/><path d="M16 9a4 4 0 010 6" stroke="#C9A227" stroke-width="1.6" stroke-linecap="round"/></svg>
        </div>
        <h4 style="font-size:15px;color:var(--navy);">Pengumuman</h4>
        <p style="margin-top:6px;font-size:13px;color:var(--muted);">Jadwal Ujian Tengah Semester Ganjil Tahun Ajaran 2026/2027</p>
        <span style="display:block;margin-top:6px;font-size:12px;color:var(--muted);">05 September 2026</span>
      </a>
      <a href="ppdb.php" style="text-align:center;text-decoration:none;">
        <div style="width:58px;height:58px;border-radius:50%;background:var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="16" rx="2" stroke="#0C2340" stroke-width="1.6"/><path d="M3 10h18M8 3v4M16 3v4" stroke="#0C2340" stroke-width="1.6" stroke-linecap="round"/></svg>
        </div>
        <h4 style="font-size:15px;color:var(--navy);">Agenda</h4>
        <p style="margin-top:6px;font-size:13px;color:var(--muted);">Upacara Peringatan Hari Kemerdekaan RI</p>
        <span style="display:block;margin-top:6px;font-size:12px;color:var(--muted);">17 Agustus 2026</span>
      </a>
      <a href="siswa.php" style="text-align:center;text-decoration:none;">
        <div style="width:58px;height:58px;border-radius:50%;background:var(--navy);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M8 21h8M12 17v4M6 4h12l-1 8a5 5 0 01-10 0L6 4z" stroke="#C9A227" stroke-width="1.6" stroke-linejoin="round"/></svg>
        </div>
        <h4 style="font-size:15px;color:var(--navy);">Prestasi</h4>
        <p style="margin-top:6px;font-size:13px;color:var(--muted);">Juara 1 LKS Tingkat Kota Bogor — Teknologi Web</p>
        <span style="display:block;margin-top:6px;font-size:12px;color:var(--muted);">12 Agustus 2026</span>
      </a>
      <a href="galeri.php" style="text-align:center;text-decoration:none;">
        <div style="width:58px;height:58px;border-radius:50%;background:var(--gold);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="#0C2340" stroke-width="1.6"/><circle cx="9" cy="11" r="2" stroke="#0C2340" stroke-width="1.6"/><path d="M21 17l-5.5-5.5L7 20" stroke="#0C2340" stroke-width="1.6" stroke-linejoin="round"/></svg>
        </div>
        <h4 style="font-size:15px;color:var(--navy);">Galeri</h4>
        <p style="margin-top:6px;font-size:13px;color:var(--muted);">Kegiatan Pertemuan Antarkelas Semester Genap 2026</p>
        <span style="display:block;margin-top:6px;font-size:12px;color:var(--muted);">01 Juli 2026</span>
      </a>
    </div>
  </div>
</section>

<section class="teaser-section">
  <div class="wrap">
    <div class="section-head reveal" style="max-width:640px;margin-bottom:50px;">
      <div class="eyebrow">Jelajahi Sekolah Kami</div>
      <h2 class="split" style="font-size:clamp(26px,3vw,36px);">Informasi singkat mengenai sekolah dalam satu langkah</h2>
    </div>
    <div class="teaser-grid">
      <a href="profil.php" class="teaser-card reveal">
        <div class="teaser-thumb"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'home_profile', 'fasilitas', ['gedung', 'area smk'], 'assets/img/gedung-infokom.jpg')) ?>" alt="" loading="lazy"></div>
        <div class="teaser-body"><h4>Profil Sekolah</h4><p>Sejarah, visi misi, dan sambutan kepala sekolah.</p><span class="go">Selengkapnya <svg width="13" height="13" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>
      </a>
      <a href="akademik.php" class="teaser-card reveal">
        <div class="teaser-thumb"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'home_academic', 'akademik', ['praktik pemrograman', 'kelas praktik', 'aktivitas lab'], 'https://images.pexels.com/photos/10643469/pexels-photo-10643469.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy"></div>
        <div class="teaser-body"><h4>Akademik</h4><p>Empat program keahlian: RPL, TKJ, DKV , Dan Produksi dan Siaran Program Televisi.</p><span class="go">Selengkapnya <svg width="13" height="13" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>
      </a>
      <a href="guru.php" class="teaser-card reveal">
        <div class="teaser-thumb"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'home_teachers', 'kegiatan', ['guru', 'tenaga pendidik', 'pengajar'], 'https://images.pexels.com/photos/18395403/pexels-photo-18395403.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy"></div>
        <div class="teaser-body"><h4>Guru dan Tenaga Pendidik</h4><p>Pendidik yang memiliki pengalaman di bidang industri masing-masing.</p><span class="go">Selengkapnya <svg width="13" height="13" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>
      </a>
      <a href="ppdb.php" class="teaser-card reveal">
        <div class="teaser-thumb"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'home_ppdb', null, ['ppdb', 'pendaftaran', 'siswa baru'], 'https://images.pexels.com/photos/38395597/pexels-photo-38395597.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy"></div>
        <div class="teaser-body"><h4>PPDB</h4><p>Langkah-langkah dan jalur pendaftaran siswa baru.</p><span class="go">Selengkapnya <svg width="13" height="13" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>
      </a>
      <a href="info.php" class="teaser-card reveal">
        <div class="teaser-thumb"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'home_info', 'kegiatan', ['workshop', 'sesi kerja tim', 'produksi konten'], 'https://images.pexels.com/photos/17115906/pexels-photo-17115906.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy"></div>
        <div class="teaser-body"><h4>Info dan Berita</h4><p>Informasi terbaru dan berbagai kegiatan di lingkungan sekolah.</p><span class="go">Selengkapnya <svg width="13" height="13" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></span></div>
      </a>
    </div>
  </div>
</section>

<section class="campaign">
  <div class="wrap campaign-inner reveal">
    <div class="campaign-mark">
      <svg width="26" height="26" viewBox="0 0 26 26"><path d="M13 2l3 7 7 1-5 5 1 7-6-3-6 3 1-7-5-5 7-1z" stroke="#C9A227" stroke-width="1.6" fill="none" stroke-linejoin="round"/></svg>
    </div>
    <h2>Program Infokom Bogor Mengabdi</h2>
    <p>Setiap tahun, siswa turut mengajarkan literasi digital dasar di sekolah dasar sekitar Bogor. Kegiatan ini membangun keterampilan sekaligus menumbuhkan kepedulian terhadap masyarakat sejak dini.</p>
    <a href="kontak.php" class="btn btn-gold">Ikut Bergabung <svg width="16" height="16" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
  </div>
</section>

<section class="stats">
  <div class="wrap">
    <div class="stats-head reveal">
      <h2>Dalam Angka</h2>
      <p>Hampir dua dekade menyiapkan lulusan yang siap kerja dan siap kuliah di bidang teknologi.</p>
    </div>
    <div class="stats-row reveal">
      <div class="stat-item"><b data-count="20">0</b><span>Tahun beroperasi<br>di Bogor</span></div>
      <div class="stat-item"><b data-count="4">0</b><span>Program keahlian<br>aktif</span></div>
    </div>
  </div>
</section>

<section style="padding:90px 0 100px;background:var(--cream);">
  <div class="wrap">
    <div class="section-head reveal" style="text-align:center;margin:0 auto 40px;max-width:520px;">
      <h2 class="split" style="font-size:clamp(24px,2.8vw,32px);">Galeri Kegiatan</h2>
    </div>
    <div class="reveal gallery-grid" data-stagger style="display:grid;grid-template-columns:repeat(6,1fr);gap:14px;">
      <?php
      $homeGalleryFallbacks = [
          ['Kegiatan belajar bersama', 'https://images.pexels.com/photos/10638115/pexels-photo-10638115.jpeg?auto=compress&cs=tinysrgb&w=300'],
          ['Praktik teknologi', 'https://images.pexels.com/photos/10643469/pexels-photo-10643469.jpeg?auto=compress&cs=tinysrgb&w=300'],
          ['Kegiatan siswa', 'https://images.pexels.com/photos/38395597/pexels-photo-38395597.jpeg?auto=compress&cs=tinysrgb&w=300'],
          ['Kolaborasi kelas', 'https://images.pexels.com/photos/17115910/pexels-photo-17115910.jpeg?auto=compress&cs=tinysrgb&w=300'],
          ['Komunitas sekolah', 'https://images.pexels.com/photos/4508751/pexels-photo-4508751.jpeg?auto=compress&cs=tinysrgb&w=300'],
          ['Aktivitas praktik', 'https://images.pexels.com/photos/32067327/pexels-photo-32067327.jpeg?auto=compress&cs=tinysrgb&w=300'],
      ];
      $homeGallery = $galleryImages ? array_slice($galleryImages, 0, 6) : array_map(
          static fn(array $fallback): array => ['judul' => $fallback[0], 'foto' => $fallback[1]],
          $homeGalleryFallbacks
      );
      foreach ($homeGallery as $image):
          $imageTitle = (string) $image['judul'];
      ?>
      <div class="gallery-item" style="border-radius:8px;overflow:hidden;aspect-ratio:1/1;"><img data-lightbox="<?= htmlspecialchars($imageTitle, ENT_QUOTES, 'UTF-8') ?>" src="<?= site_media_html((string) $image['foto']) ?>" alt="<?= htmlspecialchars($imageTitle, ENT_QUOTES, 'UTF-8') ?>" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:32px;">
      <a href="galeri.php" class="btn btn-navy">Lihat Semua Galeri</a>
    </div>
  </div>
</section>

<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
            <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika dan Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita dan Kabar</a></li><li><a href="info-darurat.php">Informasi Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
