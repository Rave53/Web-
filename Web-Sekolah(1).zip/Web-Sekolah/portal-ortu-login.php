<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';

$role = current_user()['role'] ?? null;
if ($role !== null) {
    header('Location: ' . role_dashboard_page($role));
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        $error = 'Sesi formulir tidak valid. Muat ulang halaman dan coba lagi.';
    } else {
        $usernameInput = $_POST['username'] ?? '';
        $passwordInput = $_POST['password'] ?? '';
        if (!is_string($usernameInput) || !is_string($passwordInput)) {
            $error = 'Data login tidak valid.';
        } elseif (trim($usernameInput) === '' || $passwordInput === '') {
            $error = 'Username dan kata sandi wajib diisi.';
        } elseif (attempt_login($pdo, trim($usernameInput), $passwordInput, 'ortu')) {
            unset($_SESSION['csrf_token']);
            header('Location: ortu-dashboard.php');
            exit;
        } else {
            $error = 'Username atau kata sandi salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Portal Orang Tua | SMK Infokom Bogor</title>
<meta name="description" content="Masuk ke portal orang tua SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="portal-login-header">
  <div class="wrap">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <a href="portal.php" class="portal-back-link">Pilih portal</a>
  </div>
</header>
<main class="portal-login-main">
  <section class="ppdb-form-card portal-login-card">
    <span class="eyebrow">Portal Keluarga</span>
    <h1>Masuk Portal Orang Tua</h1>
    <p>Masuk untuk melihat ringkasan akademik dan kehadiran anak yang terhubung dengan akun Anda.</p>
    <?php if ($error !== ''): ?>
      <p class="portal-alert" role="alert"><?= h($error) ?></p>
    <?php endif; ?>
    <form method="post" action="portal-ortu-login.php">
      <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">
      <div class="form-field full">
        <label for="username">Username</label>
        <input id="username" name="username" type="text" autocomplete="username" required value="<?= h(is_string($_POST['username'] ?? null) ? $_POST['username'] : '') ?>">
      </div>
      <div class="form-field full">
        <label for="password">Kata Sandi</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-gold portal-submit">Masuk</button>
    </form>
    <p class="portal-login-footnote">Siswa? <a href="portal-siswa-login.php">Masuk ke portal siswa</a>.</p>
  </section>
</main>
</body>
</html>
