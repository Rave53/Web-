<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/requests.php';

$sukses = false;
$namaSukses = '';
$formError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        request_verify_csrf();
    } catch (RuntimeException $e) {
        $formError = $e->getMessage();
    }

    $nama = trim((string) ($_POST['nama'] ?? ''));
    $email = trim((string) ($_POST['email'] ?? ''));
    if ($formError === '' && ($nama === '' || !filter_var($email, FILTER_VALIDATE_EMAIL))) {
        $formError = 'Nama lengkap dan email yang valid wajib diisi.';
    }
    if ($formError === '') {
        $stmt = $pdo->prepare(
            'INSERT INTO ppdb_pendaftar
             (nama, nisn, nik, tempat_lahir, tanggal_lahir, jk, asal_sekolah, wa_ortu, email, pilihan1, pilihan2, jalur, alamat, status)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            $nama,
            trim((string) ($_POST['nisn'] ?? '')),
            trim((string) ($_POST['nik'] ?? '')),
            trim((string) ($_POST['tempat_lahir'] ?? '')),
            ($_POST['tanggal_lahir'] ?? '') ?: null,
            $_POST['jk'] ?? 'Laki-laki',
            trim((string) ($_POST['asal_sekolah'] ?? '')),
            trim((string) ($_POST['wa_ortu'] ?? '')),
            $email,
            $_POST['pilihan1'] ?? '',
            ($_POST['pilihan2'] ?? '') ?: null,
            $_POST['jalur'] ?? null,
            trim((string) ($_POST['alamat'] ?? '')),
            'Menunggu Verifikasi',
        ]);
        $sukses = true;
        $namaSukses = $nama;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>PPDB | SMK Infokom Bogor</title>
<meta name="description" content="Cara mendaftar, jalur, dan kuota PPDB SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Kunjungi Kami</a>
    <a href="ppdb.php">Daftar PPDB</a>
    <a href="portal.php">Portal Siswa &amp; Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil &amp; Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi &amp; Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer &amp; Jaringan</a>
            <a href="akademik.php">DKV (Desain Komunikasi Visual)</a>
            <a href="akademik.php">PSPT</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas &amp; Laboratorium</a>
            
            
            
  <a href="portal-siswa-login.php">Portal Siswa</a>
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil &amp; Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi &amp; Misi</a>
  <a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info &amp; Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / PPDB</div>
    <h1 class="split">Penerimaan Peserta Didik Baru</h1>
    <p>Langkah-langkah, jalur, dan kuota pendaftaran siswa baru SMK Infokom Bogor.</p>
  </div>
</header>

<section class="campaign" id="ppdb" style="text-align:left;padding:100px 0;">
  <div class="wrap reveal" style="position:relative;display:grid;grid-template-columns:1.1fr .9fr;gap:70px;max-width:1240px;margin:0;">
    <div>
      <div class="eyebrow" style="color:var(--gold);">Penerimaan Peserta Didik Baru</div>
      <h2 style="color:#fff;font-size:clamp(24px,2.8vw,32px);" class="split">Langkah mendaftar ke SMK Infokom Bogor</h2>
      <div style="position:relative;padding-left:36px;margin-top:36px;">
        <div style="position:absolute;left:9px;top:6px;bottom:6px;width:1.5px;background:rgba(255,255,255,0.18);"></div>
        <div style="position:relative;padding-bottom:30px;"><div style="position:absolute;left:-36px;top:2px;width:19px;height:19px;border-radius:50%;background:var(--navy);border:2px solid var(--gold);"></div><h4 style="color:#fff;font-size:16px;">1. Buat akun pendaftaran</h4><p style="color:#9FB0C3;font-size:14px;margin-top:4px;">Isi data diri calon siswa melalui formulir pendaftaran online.</p></div>
        <div style="position:relative;padding-bottom:30px;"><div style="position:absolute;left:-36px;top:2px;width:19px;height:19px;border-radius:50%;background:var(--navy);border:2px solid var(--gold);"></div><h4 style="color:#fff;font-size:16px;">2. Pilih program keahlian</h4><p style="color:#9FB0C3;font-size:14px;margin-top:4px;">Urutkan pilihan sesuai minat: RPL, TKJ, DKV, atau PSPT.</p></div>
        <div style="position:relative;padding-bottom:30px;"><div style="position:absolute;left:-36px;top:2px;width:19px;height:19px;border-radius:50%;background:var(--navy);border:2px solid var(--gold);"></div><h4 style="color:#fff;font-size:16px;">3. Unggah berkas persyaratan</h4><p style="color:#9FB0C3;font-size:14px;margin-top:4px;">Ijazah/SKL, rapor, kartu keluarga, dan pas foto dalam format digital.</p></div>
        <div style="position:relative;"><div style="position:absolute;left:-36px;top:2px;width:19px;height:19px;border-radius:50%;background:var(--navy);border:2px solid var(--gold);"></div><h4 style="color:#fff;font-size:16px;">4. Verifikasi &amp; daftar ulang</h4><p style="color:#9FB0C3;font-size:14px;margin-top:4px;">Panitia memverifikasi berkas, hasil diumumkan lewat portal dan SMS.</p></div>
      </div>
    </div>
    <div style="background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.15);border-radius:var(--r);padding:34px;align-self:start;">
      <h4 style="color:#fff;font-size:15px;margin-bottom:18px;">Jalur &amp; Kuota Gelombang 1</h4>
      <div style="display:flex;justify-content:space-between;padding:14px 0;border-top:1px solid rgba(255,255,255,0.15);font-size:14px;"><span style="color:#D7DEE7;">Jalur Prestasi</span><span style="font-family:'Inter',sans-serif;font-weight:700;color:var(--gold);">60 kursi</span></div>
      <div style="display:flex;justify-content:space-between;padding:14px 0;border-top:1px solid rgba(255,255,255,0.15);font-size:14px;"><span style="color:#D7DEE7;">Jalur Reguler</span><span style="font-family:'Inter',sans-serif;font-weight:700;color:var(--gold);">180 kursi</span></div>
      <div style="display:flex;justify-content:space-between;padding:14px 0;border-top:1px solid rgba(255,255,255,0.15);font-size:14px;"><span style="color:#D7DEE7;">Jalur Afirmasi</span><span style="font-family:'Inter',sans-serif;font-weight:700;color:var(--gold);">30 kursi</span></div>
      <div style="display:flex;justify-content:space-between;padding:14px 0;border-top:1px solid rgba(255,255,255,0.15);font-size:14px;"><span style="color:#D7DEE7;">Periode Pendaftaran</span><span style="font-family:'Inter',sans-serif;font-weight:700;color:var(--gold);">Jan — Mar</span></div>
      <a href="#ppdb-form" class="btn btn-gold" style="width:100%;justify-content:center;margin-top:24px;">Daftar Online Sekarang</a>
      <a href="formulir-ppdb.php" class="btn btn-line" download style="width:100%;justify-content:center;margin-top:12px;">Unduh Formulir PDF Offline</a>
      <p style="color:#9FB0C3;font-size:12px;line-height:1.6;margin-top:10px;">Isi PDF tanpa internet, lalu cetak dan serahkan kepada panitia PPDB.</p>
    </div>
  </div>
</section>

<!-- ================= PPDB FORM ================= -->
<section class="ppdb-form-wrap" id="ppdb-form">
  <div class="wrap">
    <div class="ppdb-form-card reveal" <?= $sukses ? 'style="display:none;"' : '' ?>>
      <h3>Formulir Pendaftaran Siswa Baru</h3>
      <p>Isi data di bawah ini dengan lengkap dan benar. Pendaftaran akan masuk ke panel admin untuk diverifikasi.</p>
      <?php if ($formError !== ''): ?><p role="alert" style="margin:16px 0;padding:12px 14px;border-radius:8px;background:#FDEBEC;color:var(--crimson);font-size:13.5px;font-weight:600;"><?= h($formError) ?></p><?php endif; ?>
      <form id="ppdbFormServer" method="post" action="ppdb.php#ppdb-form">
        <input type="hidden" name="csrf_token" value="<?= h(request_csrf_token()) ?>">
        <div class="form-grid">
          <div class="form-field full">
            <label>Nama Lengkap Calon Siswa *</label>
            <input type="text" name="nama" required placeholder="Sesuai akta kelahiran">
            <span class="field-error">Nama lengkap wajib diisi.</span>
          </div>
          <div class="form-field">
            <label>NISN *</label>
            <input type="text" name="nisn" required placeholder="10 digit NISN">
            <span class="field-error">NISN wajib diisi.</span>
          </div>
          <div class="form-field">
            <label>NIK *</label>
            <input type="text" name="nik" required placeholder="16 digit NIK">
            <span class="field-error">NIK wajib diisi.</span>
          </div>
          <div class="form-field">
            <label>Tempat Lahir *</label>
            <input type="text" name="tempat_lahir" required placeholder="Contoh: Bogor">
            <span class="field-error">Tempat lahir wajib diisi.</span>
          </div>
          <div class="form-field">
            <label>Tanggal Lahir *</label>
            <input type="date" name="tanggal_lahir" required>
            <span class="field-error">Tanggal lahir wajib diisi.</span>
          </div>
          <div class="form-field full">
            <label>Jenis Kelamin *</label>
            <div class="radio-row">
              <label class="radio-opt"><input type="radio" name="jk" value="Laki-laki" required> Laki-laki</label>
              <label class="radio-opt"><input type="radio" name="jk" value="Perempuan"> Perempuan</label>
            </div>
            <span class="field-error">Pilih jenis kelamin.</span>
          </div>
          <div class="form-field full">
            <label>Asal Sekolah (SMP/MTs) *</label>
            <input type="text" name="asal_sekolah" required placeholder="Nama sekolah asal">
            <span class="field-error">Asal sekolah wajib diisi.</span>
          </div>
          <div class="form-field">
            <label>Nomor WhatsApp Orang Tua/Wali *</label>
            <input type="tel" name="wa_ortu" required placeholder="08xxxxxxxxxx">
            <span class="field-error">Nomor WhatsApp wajib diisi.</span>
          </div>
          <div class="form-field">
            <label>Email Aktif *</label>
            <input type="email" name="email" required placeholder="nama@email.com">
            <span class="field-error">Email wajib diisi dengan format benar.</span>
          </div>
          <div class="form-field">
            <label>Pilihan Program Keahlian 1 *</label>
            <select name="pilihan1" required>
              <option value="">Pilih program</option>
              <option>Rekayasa Perangkat Lunak (RPL)</option>
              <option>Teknik Komputer &amp; Jaringan (TKJ)</option>
              <option>DKV (Desain Komunikasi Visual)</option>
              <option>Produksi dan Siaran Program Televisi (PSPT)</option>
            </select>
            <span class="field-error">Pilih program keahlian pertama.</span>
          </div>
          <div class="form-field">
            <label>Pilihan Program Keahlian 2 (opsional)</label>
            <select name="pilihan2">
              <option value="">Pilih program</option>
              <option>Rekayasa Perangkat Lunak (RPL)</option>
              <option>Teknik Komputer &amp; Jaringan (TKJ)</option>
              <option>DKV (Desain Komunikasi Visual)</option>
              <option>Produksi dan Siaran Program Televisi (PSPT)</option>
            </select>
          </div>
          <div class="form-field full">
            <label>Jalur Pendaftaran *</label>
            <div class="radio-row">
              <label class="radio-opt"><input type="radio" name="jalur" value="Prestasi" required> Jalur Prestasi</label>
              <label class="radio-opt"><input type="radio" name="jalur" value="Reguler"> Jalur Reguler</label>
              <label class="radio-opt"><input type="radio" name="jalur" value="Afirmasi"> Jalur Afirmasi</label>
            </div>
            <span class="field-error">Pilih jalur pendaftaran.</span>
          </div>
          <div class="form-field full">
            <label>Alamat Lengkap *</label>
            <textarea name="alamat" required placeholder="Alamat sesuai KTP/KK"></textarea>
            <span class="field-error">Alamat wajib diisi.</span>
          </div>
          <div class="form-field full">
            <label>Unggah Berkas (Ijazah/SKL, Rapor, KK — opsional di formulir contoh ini)</label>
            <div class="file-drop">Klik atau seret berkas ke sini (PDF/JPG, maks 5MB per file)</div>
          </div>
        </div>
        <button type="submit" class="btn btn-gold ppdb-submit">Kirim Pendaftaran</button>
      </form>
    </div>
    <div class="ppdb-success" id="ppdbSuccess" <?= $sukses ? 'style="display:block;"' : '' ?>>
      <div class="check"><svg width="28" height="28" viewBox="0 0 28 28"><path d="M5 14l6 6 12-12" stroke="var(--crimson)" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
      <h3>Pendaftaran <span id="ppdbSuccessName"><?= h($namaSukses) ?></span> Terkirim</h3>
      <p>Terima kasih. Data pendaftaran telah dikirim dan menunggu verifikasi panitia PPDB. Panitia akan menghubungi nomor WhatsApp yang Anda cantumkan untuk informasi selanjutnya.</p>
    </div>
  </div>
</section>


<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
