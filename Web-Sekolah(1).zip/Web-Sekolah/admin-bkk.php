<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/bkk.php';
$user = bkk_require_roles(['admin', 'admin_bkk']);
$tabs = ['dashboard', 'lowongan', 'mitra', 'pelamar', 'lamaran', 'event', 'berita', 'dokumen', 'pengaturan'];
$tab = $_GET['tab'] ?? 'dashboard';
if (!in_array($tab, $tabs, true)) {
    $tab = 'dashboard';
}
$resources = [
    'lowongan' => [
        'table' => 'bkk_lowongan', 'title' => 'Lowongan Kerja', 'singular' => 'Lowongan', 'order' => 'created_at DESC',
        'fields' => [
            'perusahaan_id' => ['Perusahaan', 'company', true], 'posisi' => ['Nama posisi', 'text', true], 'lokasi' => ['Lokasi', 'text', true],
            'jenis_pekerjaan' => ['Jenis pekerjaan', 'select', true, ['Full-time','Part-time','Kontrak','Magang','Freelance']],
            'deskripsi' => ['Deskripsi pekerjaan', 'textarea', true], 'persyaratan' => ['Persyaratan', 'textarea', false],
            'pendidikan' => ['Pendidikan minimal', 'text', false], 'jurusan' => ['Jurusan (RPL, TKJ, DKV, PSPT)', 'text', false],
            'skill' => ['Keahlian', 'textarea', false], 'dokumen' => ['Dokumen yang diperlukan', 'text', false], 'gaji' => ['Gaji', 'text', false],
            'jumlah_posisi' => ['Jumlah posisi', 'number', true], 'tanggal_mulai' => ['Tanggal dibuka', 'date', false], 'deadline' => ['Batas pendaftaran', 'date', true],
            'link_pendaftaran' => ['Link pendaftaran eksternal', 'url', false], 'cara_melamar' => ['Cara melamar', 'textarea', false],
            'status' => ['Status', 'select', true, ['Aktif','Ditutup']], 'featured' => ['Tandai sebagai pilihan BKK', 'checkbox', false],
        ],
    ],
    'mitra' => [
        'table' => 'bkk_perusahaan', 'title' => 'Perusahaan Mitra', 'singular' => 'Perusahaan', 'order' => 'nama ASC',
        'fields' => [
            'nama' => ['Nama perusahaan', 'text', true], 'logo' => ['Logo (JPG, PNG, WebP; maks. 3 MB)', 'image', false],
            'bidang_industri' => ['Bidang industri', 'text', true], 'deskripsi' => ['Deskripsi', 'textarea', false],
            'alamat' => ['Alamat', 'text', false], 'kota' => ['Kota', 'text', false], 'website' => ['Website', 'url', false],
            'email' => ['Email', 'email', false], 'telepon' => ['Nomor telepon', 'text', false], 'nama_pic' => ['PIC perusahaan', 'text', false],
            'status' => ['Status kemitraan', 'select', true, ['Aktif','Tidak Aktif']],
            'tanggal_mulai_kerja_sama' => ['Mulai kerja sama', 'date', false], 'tanggal_akhir_kerja_sama' => ['Akhir kerja sama', 'date', false],
            'dokumen_mou' => ['Dokumen MoU (PDF/DOC/DOCX; maks. 5 MB)', 'document', false],
        ],
    ],
    'event' => [
        'table' => 'bkk_event', 'title' => 'Job Fair / Event', 'singular' => 'Event', 'order' => 'tanggal DESC',
        'fields' => [
            'nama_event' => ['Nama event', 'text', true], 'poster' => ['Poster (JPG, PNG, WebP; maks. 3 MB)', 'image', false],
            'deskripsi' => ['Deskripsi', 'textarea', false], 'tanggal' => ['Tanggal', 'date', true], 'waktu' => ['Waktu', 'text', false],
            'lokasi' => ['Lokasi', 'text', true], 'perusahaan_ikut' => ['Perusahaan yang ikut', 'textarea', false],
            'kuota' => ['Kuota peserta (kosongkan jika tanpa batas)', 'number', false], 'link_pendaftaran' => ['Link pendaftaran', 'url', false],
            'status' => ['Status', 'select', true, ['Akan Datang','Sedang Berlangsung','Selesai']],
        ],
    ],
    'berita' => [
        'table' => 'bkk_berita', 'title' => 'Berita BKK', 'singular' => 'Berita', 'order' => 'created_at DESC',
        'fields' => [
            'judul' => ['Judul', 'text', true], 'thumbnail' => ['Thumbnail (JPG, PNG, WebP; maks. 3 MB)', 'image', false],
            'isi' => ['Isi berita', 'textarea', true],
            'kategori' => ['Kategori', 'select', true, ['Lowongan','Job Fair','Rekrutmen','Alumni','Kerja Sama','Tips Karier']],
            'penulis' => ['Penulis', 'text', true], 'status' => ['Status publikasi', 'select', true, ['Draft','Publish']],
        ],
    ],
];
$flash = $_SESSION['bkk_admin_flash'] ?? null;
unset($_SESSION['bkk_admin_flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    bkk_verify_csrf();
    $action = $_POST['action'] ?? '';
    $returnTab = in_array($_POST['tab'] ?? '', $tabs, true) ? $_POST['tab'] : 'dashboard';
    try {
        if ($action === 'save_resource') {
            $resourceKey = $_POST['resource'] ?? '';
            if (!isset($resources[$resourceKey])) {
                throw new RuntimeException('Jenis data tidak dikenal.');
            }
            $resource = $resources[$resourceKey];
            $id = (int) ($_POST['id'] ?? 0);
            $columns = [];
            $values = [];
            foreach ($resource['fields'] as $key => $field) {
                $type = $field[1];
                if ($type === 'image' || $type === 'document') {
                    $uploaded = bkk_upload($_FILES[$key] ?? [], $type === 'image' ? 'image' : 'cv');
                    if ($uploaded !== null) {
                        $columns[] = $key;
                        $values[] = $uploaded;
                    }
                    continue;
                }
                if ($type === 'checkbox') {
                    $columns[] = $key;
                    $values[] = isset($_POST[$key]) ? 1 : 0;
                    continue;
                }
                $value = trim((string) ($_POST[$key] ?? ''));
                if ($field[2] && $value === '') {
                    throw new RuntimeException($field[0] . ' wajib diisi.');
                }
                if ($type === 'company') {
                    if (!ctype_digit($value) || (int) $value < 1) {
                        throw new RuntimeException('Pilih perusahaan yang valid.');
                    }
                    $companyCheck = $pdo->prepare('SELECT id FROM bkk_perusahaan WHERE id = ?');
                    $companyCheck->execute([(int) $value]);
                    if (!$companyCheck->fetchColumn()) {
                        throw new RuntimeException('Perusahaan tidak ditemukan.');
                    }
                    $value = (int) $value;
                } elseif ($type === 'email' && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    throw new RuntimeException('Format email tidak valid.');
                } elseif ($type === 'url' && $value !== '' && !filter_var($value, FILTER_VALIDATE_URL)) {
                    throw new RuntimeException('URL tidak valid.');
                }
                if ($type === 'number' && $value === '') {
                    $value = null;
                }
                if ($type === 'number' && $value !== null && (int) $value < 0) {
                    throw new RuntimeException($field[0] . ' tidak boleh negatif.');
                }
                $columns[] = $key;
                $values[] = $value === '' ? null : $value;
            }
            if ($resourceKey === 'berita') {
                $baseSlug = strtolower(trim(preg_replace('/-+/', '-', preg_replace('/[^a-z0-9]+/', '-', iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $_POST['judul'] ?? 'berita'))), '-')) ?: 'berita';
                $slug = $baseSlug;
                $slugQuery = $pdo->prepare('SELECT id FROM bkk_berita WHERE slug = ? AND id <> ?');
                $suffix = 2;
                do {
                    $slugQuery->execute([$slug, $id]);
                    if (!$slugQuery->fetchColumn()) break;
                    $slug = $baseSlug . '-' . $suffix++;
                } while ($suffix < 1000);
                $columns[] = 'slug';
                $values[] = $slug;
                $columns[] = 'published_at';
                $values[] = ($_POST['status'] ?? '') === 'Publish' ? date('Y-m-d H:i:s') : null;
            }
            if ($id > 0) {
                $sets = implode(', ', array_map(static fn($column) => "`$column` = ?", $columns));
                $values[] = $id;
                $save = $pdo->prepare("UPDATE `{$resource['table']}` SET $sets WHERE id = ?");
                $save->execute($values);
            } else {
                $names = implode(', ', array_map(static fn($column) => "`$column`", $columns));
                $marks = implode(', ', array_fill(0, count($columns), '?'));
                $save = $pdo->prepare("INSERT INTO `{$resource['table']}` ($names) VALUES ($marks)");
                $save->execute($values);
                if ($resourceKey === 'lowongan' && ($_POST['status'] ?? '') === 'Aktif') {
                    bkk_notify_users($pdo, 'Lowongan baru', 'Lowongan baru tersedia: ' . trim($_POST['posisi'] ?? ''), 'bkk.php#lowongan');
                } elseif ($resourceKey === 'event' && ($_POST['status'] ?? '') === 'Akan Datang') {
                    bkk_notify_users($pdo, 'Agenda BKK baru', 'Agenda baru tersedia: ' . trim($_POST['nama_event'] ?? ''), 'bkk.php');
                }
            }
            $_SESSION['bkk_admin_flash'] = ['type' => 'success', 'text' => $resource['singular'] . ' berhasil disimpan.'];
        } elseif ($action === 'delete_resource') {
            $resourceKey = $_POST['resource'] ?? '';
            if (!in_array($resourceKey, ['lowongan','mitra','event','berita'], true)) {
                throw new RuntimeException('Data ini tidak dapat dihapus dari menu tersebut.');
            }
            $delete = $pdo->prepare("DELETE FROM `{$resources[$resourceKey]['table']}` WHERE id = ?");
            $delete->execute([(int) ($_POST['id'] ?? 0)]);
            $_SESSION['bkk_admin_flash'] = ['type' => 'success', 'text' => 'Data berhasil dihapus.'];
        } elseif ($action === 'update_application') {
            $applicationId = (int) ($_POST['application_id'] ?? 0);
            $status = $_POST['status'] ?? '';
            $allowedStatuses = ['Lamaran Masuk','Seleksi Administrasi','Tes','Interview','Diterima','Ditolak'];
            if (!in_array($status, $allowedStatuses, true)) {
                throw new RuntimeException('Status lamaran tidak valid.');
            }
            $pdo->beginTransaction();
            $currentQuery = $pdo->prepare('SELECT a.status, a.pelamar_id, p.user_id FROM bkk_lamaran a JOIN bkk_pelamar p ON p.id=a.pelamar_id WHERE a.id=? FOR UPDATE');
            $currentQuery->execute([$applicationId]);
            $current = $currentQuery->fetch();
            if (!$current) throw new RuntimeException('Lamaran tidak ditemukan.');
            $note = trim($_POST['catatan_admin'] ?? '');
            $update = $pdo->prepare('UPDATE bkk_lamaran SET status=?, catatan_admin=? WHERE id=?');
            $update->execute([$status, $note ?: null, $applicationId]);
            if ($current['status'] !== $status || $note !== '') {
                $history = $pdo->prepare('INSERT INTO bkk_riwayat_lamaran (lamaran_id, status, catatan) VALUES (?, ?, ?)');
                $history->execute([$applicationId, $status, $note ?: 'Status lamaran diperbarui oleh BKK.']);
                $notification = $pdo->prepare('INSERT INTO bkk_notifikasi (user_id, judul, pesan, tautan) VALUES (?, ?, ?, ?)');
                $notification->execute([(int) $current['user_id'], 'Status lamaran diperbarui', 'Status lamaran Anda sekarang: ' . $status, 'bkk.php#status-lamaran']);
            }
            if ($status === 'Diterima') {
                $markEmployed = $pdo->prepare("UPDATE bkk_pelamar SET status='Bekerja' WHERE id=?");
                $markEmployed->execute([(int) $current['pelamar_id']]);
            }
            $pdo->commit();
            $_SESSION['bkk_admin_flash'] = ['type' => 'success', 'text' => 'Status dan riwayat lamaran diperbarui.'];
            $returnTab = 'lamaran';
        } elseif ($action === 'update_applicant') {
            $status = $_POST['status'] ?? '';
            if (!in_array($status, ['Aktif','Bekerja','Tidak Aktif'], true)) throw new RuntimeException('Status pencari kerja tidak valid.');
            $update = $pdo->prepare('UPDATE bkk_pelamar SET status=? WHERE id=?');
            $update->execute([$status, (int) ($_POST['applicant_id'] ?? 0)]);
            $_SESSION['bkk_admin_flash'] = ['type' => 'success', 'text' => 'Status pencari kerja diperbarui.'];
            $returnTab = 'pelamar';
        } elseif ($action === 'save_settings') {
            $videoUrl = trim((string) ($_POST['video_url'] ?? ''));
            if ($videoUrl !== '' && !filter_var($videoUrl, FILTER_VALIDATE_URL)) {
                throw new RuntimeException('Tautan video tidak valid. Gunakan URL YouTube atau Instagram yang benar.');
            }
            $save = $pdo->prepare('UPDATE bkk_settings SET nama_bkk=?, deskripsi=?, alamat=?, email=?, telepon=?, video_url=? WHERE id=1');
            $save->execute([trim($_POST['nama_bkk'] ?? ''), trim($_POST['deskripsi'] ?? ''), trim($_POST['alamat'] ?? ''), trim($_POST['email'] ?? ''), trim($_POST['telepon'] ?? ''), $videoUrl === '' ? null : $videoUrl]);
            $_SESSION['bkk_admin_flash'] = ['type' => 'success', 'text' => 'Pengaturan BKK berhasil disimpan.'];
            $returnTab = 'pengaturan';
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $_SESSION['bkk_admin_flash'] = ['type' => 'error', 'text' => $exception instanceof PDOException ? 'Data tidak dapat disimpan. Periksa relasi atau data yang sudah ada.' : $exception->getMessage()];
    }
    header('Location: admin-bkk.php?tab=' . urlencode($returnTab));
    exit;
}

$flash = $_SESSION['bkk_admin_flash'] ?? $flash;
unset($_SESSION['bkk_admin_flash']);
$q = trim($_GET['q'] ?? '');
$editId = (int) ($_GET['edit'] ?? 0);
$editing = null;
if ($editId && isset($resources[$tab])) {
    $editQuery = $pdo->prepare("SELECT * FROM `{$resources[$tab]['table']}` WHERE id = ?");
    $editQuery->execute([$editId]);
    $editing = $editQuery->fetch() ?: null;
}
$companies = $pdo->query("SELECT id,nama FROM bkk_perusahaan WHERE status='Aktif' ORDER BY nama")->fetchAll();
$settings = $pdo->query('SELECT * FROM bkk_settings WHERE id=1')->fetch();
$stats = [
    'jobs' => (int) $pdo->query('SELECT COUNT(*) FROM bkk_lowongan')->fetchColumn(),
    'active' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_lowongan WHERE status='Aktif' AND deadline >= CURDATE()")->fetchColumn(),
    'partners' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_perusahaan WHERE status='Aktif'")->fetchColumn(),
    'applicants' => (int) $pdo->query('SELECT COUNT(*) FROM bkk_pelamar')->fetchColumn(),
    'applications' => (int) $pdo->query('SELECT COUNT(*) FROM bkk_lamaran')->fetchColumn(),
    'placed' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_pelamar WHERE status='Bekerja'")->fetchColumn(),
    'events' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_event WHERE tanggal >= CURDATE() AND status <> 'Selesai'")->fetchColumn(),
];

$rows = [];
if (isset($resources[$tab])) {
    $resource = $resources[$tab];
    if ($tab === 'lowongan') {
        $list = $pdo->prepare("SELECT j.*,p.nama AS perusahaan,(SELECT COUNT(*) FROM bkk_lamaran a WHERE a.lowongan_id=j.id) AS jumlah_pelamar FROM bkk_lowongan j JOIN bkk_perusahaan p ON p.id=j.perusahaan_id WHERE j.posisi LIKE ? OR p.nama LIKE ? OR j.jurusan LIKE ? ORDER BY j.created_at DESC LIMIT 100");
        $term = '%' . $q . '%'; $list->execute([$term,$term,$term]);
    } elseif ($tab === 'mitra') {
        $list = $pdo->prepare('SELECT * FROM bkk_perusahaan WHERE nama LIKE ? OR bidang_industri LIKE ? OR kota LIKE ? ORDER BY nama LIMIT 100');
        $term = '%' . $q . '%'; $list->execute([$term,$term,$term]);
    } elseif ($tab === 'event') {
        $list = $pdo->prepare('SELECT * FROM bkk_event WHERE nama_event LIKE ? OR lokasi LIKE ? ORDER BY tanggal DESC LIMIT 100');
        $term = '%' . $q . '%'; $list->execute([$term,$term]);
    } else {
        $list = $pdo->prepare('SELECT * FROM bkk_berita WHERE judul LIKE ? OR kategori LIKE ? ORDER BY created_at DESC LIMIT 100');
        $term = '%' . $q . '%'; $list->execute([$term,$term]);
    }
    $rows = $list->fetchAll();
} elseif ($tab === 'pelamar') {
    $list = $pdo->prepare('SELECT p.*,u.nama FROM bkk_pelamar p JOIN users u ON u.id=p.user_id WHERE u.nama LIKE ? OR p.jurusan LIKE ? OR p.email LIKE ? OR p.domisili LIKE ? ORDER BY p.updated_at DESC LIMIT 100');
    $term = '%' . $q . '%'; $list->execute([$term,$term,$term,$term]); $rows = $list->fetchAll();
} elseif ($tab === 'lamaran') {
    $list = $pdo->prepare('SELECT a.*,p.nama AS perusahaan,j.posisi,u.nama AS pelamar, pr.email, pr.no_hp FROM bkk_lamaran a JOIN bkk_lowongan j ON j.id=a.lowongan_id JOIN bkk_perusahaan p ON p.id=j.perusahaan_id JOIN bkk_pelamar pr ON pr.id=a.pelamar_id JOIN users u ON u.id=pr.user_id WHERE u.nama LIKE ? OR j.posisi LIKE ? OR p.nama LIKE ? ORDER BY a.tanggal_melamar DESC LIMIT 100');
    $term = '%' . $q . '%'; $list->execute([$term,$term,$term]); $rows = $list->fetchAll();
} elseif ($tab === 'dokumen') {
    $list = $pdo->prepare('SELECT p.*,u.nama FROM bkk_pelamar p JOIN users u ON u.id=p.user_id WHERE p.cv IS NOT NULL OR p.sertifikat IS NOT NULL ORDER BY p.updated_at DESC LIMIT 100');
    $list->execute(); $rows = $list->fetchAll();
}
$monthlyApplications = $pdo->query("SELECT DATE_FORMAT(tanggal_melamar,'%b') label, COUNT(*) jumlah FROM bkk_lamaran WHERE tanggal_melamar >= DATE_SUB(CURDATE(), INTERVAL 5 MONTH) GROUP BY YEAR(tanggal_melamar),MONTH(tanggal_melamar),label ORDER BY YEAR(MIN(tanggal_melamar)),MONTH(MIN(tanggal_melamar))")->fetchAll();
$maxMonthly = max(1, (int) max(array_column($monthlyApplications, 'jumlah') ?: [1]));
$majorStats = $pdo->query('SELECT jurusan,COUNT(*) jumlah FROM bkk_lowongan GROUP BY jurusan ORDER BY jumlah DESC LIMIT 6')->fetchAll();
$majorMax = max(1, (int) max(array_column($majorStats, 'jumlah') ?: [1]));
$latestJobs = $pdo->query("SELECT j.*,p.nama AS perusahaan,(SELECT COUNT(*) FROM bkk_lamaran a WHERE a.lowongan_id=j.id) AS jumlah_pelamar FROM bkk_lowongan j JOIN bkk_perusahaan p ON p.id=j.perusahaan_id ORDER BY j.created_at DESC LIMIT 8")->fetchAll();
$activeTabLabels = ['dashboard'=>'Dashboard BKK','lowongan'=>'Lowongan Kerja','mitra'=>'Perusahaan Mitra','pelamar'=>'Pelamar','lamaran'=>'Lamaran','event'=>'Job Fair / Event','berita'=>'Berita BKK','dokumen'=>'Dokumen','pengaturan'=>'Pengaturan BKK'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($activeTabLabels[$tab]) ?> | Admin BKK</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="assets/bkk.css">
</head>
<body class="bkk-admin-page">
<aside class="admin-sidebar" aria-label="Navigasi admin"><a href="admin-dashboard.php" class="admin-sidebar-brand"><img src="<?= h(site_media_url('assets/img/logo-infokom.png')) ?>" alt="Logo SMK Infokom Bogor"><span>SMK Infokom<br>Admin</span></a><div class="admin-sidebar-label">Workspace</div><a href="admin-dashboard.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="4" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="4" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/><rect x="14" y="14" width="6" height="6" rx="1" stroke="currentColor" stroke-width="1.7"/></svg><span>Dashboard Sekolah</span></a><a href="admin-kelola.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 6h16M4 12h16M4 18h10" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Kelola Konten</span></a><a href="admin-absensi.php"><svg viewBox="0 0 24 24" fill="none"><rect x="4" y="5" width="16" height="15" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M8 3v4m8-4v4M7 11h10" stroke="currentColor" stroke-width="1.7"/></svg><span>Absensi</span></a><a class="active" href="admin-bkk.php"><svg viewBox="0 0 24 24" fill="none"><path d="M3 8h18v12H3zM7 8V5h10v3M8 13h8M8 16h5" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round"/></svg><span>BKK</span></a><div class="admin-sidebar-label">Aplikasi</div><a href="bkk.php"><svg viewBox="0 0 24 24" fill="none"><path d="M4 19V5m0 14h16M8 15l3-4 3 2 5-7" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Halaman Publik BKK</span></a><div class="admin-sidebar-footer"><a href="logout.php"><svg viewBox="0 0 24 24" fill="none"><path d="M10 5H5v14h5m5-4 4-3-4-3m4 3H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg><span>Keluar</span></a></div></aside>
<main class="bkk-admin-main"><header class="bkk-admin-header"><div><span class="bkk-eyebrow">SMK Infokom Bogor / Workspace</span><h1><?= h($activeTabLabels[$tab]) ?></h1><p>Pengelolaan Bursa Kerja Khusus &middot; <?= h($user['nama']) ?></p></div><a class="btn btn-gold" href="bkk.php" target="_blank">Lihat BKK Publik &nearr;</a></header>
<nav class="bkk-admin-tabs" aria-label="Menu BKK"><?php foreach ($activeTabLabels as $key=>$label): ?><a class="<?= $tab===$key?'active':'' ?>" href="admin-bkk.php?tab=<?= h($key) ?>"><?= h($label) ?></a><?php endforeach; ?></nav>
<?php if ($flash): ?><div class="bkk-admin-alert <?= h($flash['type']) ?>" role="status"><?= h($flash['text']) ?></div><?php endif; ?>
<?php if ($tab==='dashboard'): ?>
  <section class="bkk-admin-stat-grid"><?php foreach ([['Total lowongan',$stats['jobs']],['Lowongan aktif',$stats['active']],['Perusahaan mitra',$stats['partners']],['Total pelamar',$stats['applicants']],['Total lamaran',$stats['applications']],['Alumni tersalurkan',$stats['placed']],['Event mendatang',$stats['events']]] as [$label,$value]): ?><div class="bkk-admin-stat"><span><?= h($label) ?></span><strong><?= number_format($value) ?></strong></div><?php endforeach; ?></section>
  <div class="bkk-admin-columns"><section class="bkk-admin-panel"><h2>Lamaran per bulan</h2><?php if ($monthlyApplications): ?><div class="bkk-chart-bars"><?php foreach ($monthlyApplications as $month): ?><div><i style="height:<?= max(4, (int) round($month['jumlah']/$maxMonthly*112)) ?>px"></i><span><?= h($month['label']) ?></span></div><?php endforeach; ?></div><?php else: ?><div class="bkk-empty"><span>Data lamaran belum tersedia.</span></div><?php endif; ?></section><section class="bkk-admin-panel"><h2>Lowongan berdasarkan jurusan</h2><?php if ($majorStats): ?><div class="bkk-chart-bars"><?php foreach ($majorStats as $major): ?><div><i style="height:<?= max(4, (int) round($major['jumlah']/$majorMax*112)) ?>px;background:#c9a227"></i><span><?= h($major['jurusan'] ?: 'Umum') ?></span></div><?php endforeach; ?></div><?php else: ?><div class="bkk-empty"><span>Data lowongan belum tersedia.</span></div><?php endif; ?></section></div>
  <section class="bkk-admin-panel"><h2>Lowongan Terbaru</h2><div class="bkk-table-scroll"><table class="bkk-table"><thead><tr><th>Posisi</th><th>Perusahaan</th><th>Jurusan</th><th>Pelamar</th><th>Deadline</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php if (!$latestJobs): ?><tr><td colspan="7">Belum ada lowongan.</td></tr><?php endif; ?><?php foreach ($latestJobs as $job): ?><tr><td><?= h($job['posisi']) ?></td><td><?= h($job['perusahaan']) ?></td><td><?= h($job['jurusan'] ?: '-') ?></td><td><?= (int)$job['jumlah_pelamar'] ?></td><td><?= date('d M Y',strtotime($job['deadline'])) ?></td><td><?= h($job['status']) ?></td><td><a class="bkk-text-link" href="admin-bkk.php?tab=lowongan&edit=<?= (int)$job['id'] ?>">Edit</a></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php elseif (isset($resources[$tab])): $resource=$resources[$tab]; ?>
  <?php if ($tab==='lowongan' && !$companies): ?><div class="bkk-admin-alert error">Tambahkan perusahaan mitra aktif sebelum membuat lowongan.</div><?php endif; ?>
  <?php if (!empty($_GET['new']) || $editing): ?><form class="bkk-admin-form" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="save_resource"><input type="hidden" name="tab" value="<?= h($tab) ?>"><input type="hidden" name="resource" value="<?= h($tab) ?>"><input type="hidden" name="id" value="<?= (int)($editing['id']??0) ?>"><h2><?= $editing ? 'Edit' : 'Tambah' ?> <?= h($resource['singular']) ?></h2><div class="bkk-admin-form-grid"><?php foreach ($resource['fields'] as $key=>$field): [$label,$type,$required]=$field; $value=$editing[$key]??''; $class=in_array($type,['textarea'])?'span-all':''; ?><label class="<?= $class ?>"><?= h($label) ?><?= $required?' *':'' ?><?php if ($type==='textarea'): ?><textarea name="<?= h($key) ?>" rows="4" <?= $required?'required':'' ?>><?= h((string)$value) ?></textarea><?php elseif ($type==='select'): ?><select name="<?= h($key) ?>" <?= $required?'required':'' ?>><?php foreach ($field[3] as $option): ?><option value="<?= h($option) ?>" <?= (string)$value===$option?'selected':'' ?>><?= h($option) ?></option><?php endforeach; ?></select><?php elseif ($type==='company'): ?><select name="<?= h($key) ?>" required><option value="">Pilih perusahaan</option><?php foreach ($companies as $company): ?><option value="<?= (int)$company['id'] ?>" <?= (int)$value===(int)$company['id']?'selected':'' ?>><?= h($company['nama']) ?></option><?php endforeach; ?></select><?php elseif ($type==='checkbox'): ?><input type="checkbox" name="<?= h($key) ?>" value="1" <?= $value?'checked':'' ?> style="width:auto;margin:10px 0 0"> <?php elseif ($type==='image' || $type==='document'): ?><input type="file" name="<?= h($key) ?>" accept="<?= $type==='image'?'.jpg,.jpeg,.png,.webp':'.pdf,.doc,.docx' ?>"><?php if ($value): ?><small>File tersimpan: <?= h(basename($value)) ?></small><?php endif; ?><?php else: ?><input type="<?= h($type) ?>" name="<?= h($key) ?>" value="<?= h((string)$value) ?>" <?= $required?'required':'' ?> <?= $type==='number'?'min="0"':'' ?>><?php endif; ?></label><?php endforeach; ?></div><div class="bkk-admin-form-actions"><button class="btn btn-navy" type="submit">Simpan <?= h($resource['singular']) ?></button><a class="btn btn-line" style="color:#0c2340;border-color:#cdd6d1" href="admin-bkk.php?tab=<?= h($tab) ?>">Batal</a></div></form><?php endif; ?>
  <section class="bkk-admin-panel"><div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px"><h2 style="margin:0"><?= h($resource['title']) ?></h2><a class="btn btn-navy" style="padding:9px 13px" href="admin-bkk.php?tab=<?= h($tab) ?>&new=1">+ Tambah</a></div><form class="bkk-admin-search" method="get"><input type="hidden" name="tab" value="<?= h($tab) ?>"><input name="q" value="<?= h($q) ?>" placeholder="Cari <?= h(strtolower($resource['title'])) ?>"><button class="btn btn-gold" type="submit">Cari</button></form><div class="bkk-table-scroll"><table class="bkk-table"><thead><tr><?php if ($tab==='lowongan'): ?><th>Posisi</th><th>Perusahaan</th><th>Jurusan</th><th>Pelamar</th><th>Deadline</th><th>Status</th><?php elseif ($tab==='mitra'): ?><th>Perusahaan</th><th>Bidang</th><th>Kota</th><th>Status</th><?php elseif ($tab==='event'): ?><th>Event</th><th>Tanggal</th><th>Lokasi</th><th>Status</th><?php else: ?><th>Judul</th><th>Kategori</th><th>Penulis</th><th>Status</th><?php endif; ?><th>Aksi</th></tr></thead><tbody><?php if (!$rows): ?><tr><td colspan="7" style="text-align:center">Belum ada data. Tambahkan data pertama untuk ditampilkan.</td></tr><?php endif; ?><?php foreach ($rows as $row): ?><tr><?php if ($tab==='lowongan'): ?><td><?= h($row['posisi']) ?></td><td><?= h($row['perusahaan']) ?></td><td><?= h($row['jurusan']?:'-') ?></td><td><?= (int)$row['jumlah_pelamar'] ?></td><td><?= date('d M Y',strtotime($row['deadline'])) ?></td><td><?= h($row['status']) ?></td><?php elseif ($tab==='mitra'): ?><td><?= h($row['nama']) ?></td><td><?= h($row['bidang_industri']) ?></td><td><?= h($row['kota']?:'-') ?></td><td><?= h($row['status']) ?></td><?php elseif ($tab==='event'): ?><td><?= h($row['nama_event']) ?></td><td><?= date('d M Y',strtotime($row['tanggal'])) ?></td><td><?= h($row['lokasi']) ?></td><td><?= h($row['status']) ?></td><?php else: ?><td><?= h($row['judul']) ?></td><td><?= h($row['kategori']) ?></td><td><?= h($row['penulis']) ?></td><td><?= h($row['status']) ?></td><?php endif; ?><td style="white-space:nowrap"><a class="bkk-text-link" href="admin-bkk.php?tab=<?= h($tab) ?>&edit=<?= (int)$row['id'] ?>">Edit</a> <form method="post" style="display:inline" onsubmit="return confirm('Hapus data ini?')"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="delete_resource"><input type="hidden" name="tab" value="<?= h($tab) ?>"><input type="hidden" name="resource" value="<?= h($tab) ?>"><input type="hidden" name="id" value="<?= (int)$row['id'] ?>"><button class="bkk-danger" type="submit">Hapus</button></form></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php elseif ($tab==='pelamar'): ?><section class="bkk-admin-panel"><h2>Daftar Pencari Kerja</h2><form class="bkk-admin-search"><input type="hidden" name="tab" value="pelamar"><input name="q" value="<?= h($q) ?>" placeholder="Nama, jurusan, email, atau domisili"><button class="btn btn-gold">Cari</button></form><div class="bkk-table-scroll"><table class="bkk-table"><thead><tr><th>Nama</th><th>Status</th><th>Tahun lulus</th><th>Jurusan</th><th>Kontak</th><th>Domisili</th><th>CV</th><th>Status kerja</th></tr></thead><tbody><?php if (!$rows): ?><tr><td colspan="8" style="text-align:center">Belum ada pencari kerja.</td></tr><?php endif; ?><?php foreach ($rows as $row): ?><tr><td><?= h($row['nama']) ?></td><td><?= h($row['status_pelamar']) ?></td><td><?= h((string)($row['tahun_lulus']??'-')) ?></td><td><?= h($row['jurusan']) ?></td><td><?= h($row['no_hp']) ?><br><?= h($row['email']) ?></td><td><?= h($row['domisili']) ?></td><td><?php if ($row['cv']): ?><a class="bkk-download" href="bkk-download.php?applicant=<?= (int)$row['id'] ?>&kind=cv">Lihat CV</a><?php else: ?>-<?php endif; ?></td><td><form class="bkk-inline-form" method="post"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="update_applicant"><input type="hidden" name="applicant_id" value="<?= (int)$row['id'] ?>"><input type="hidden" name="tab" value="pelamar"><select name="status"><?php foreach (['Aktif','Bekerja','Tidak Aktif'] as $status): ?><option <?= $row['status']===$status?'selected':'' ?>><?= h($status) ?></option><?php endforeach; ?></select><button class="bkk-text-link">Simpan</button></form></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php elseif ($tab==='lamaran'): ?><section class="bkk-admin-panel"><h2>Proses dan Riwayat Lamaran</h2><form class="bkk-admin-search"><input type="hidden" name="tab" value="lamaran"><input name="q" value="<?= h($q) ?>" placeholder="Cari pelamar, posisi, perusahaan"><button class="btn btn-gold">Cari</button></form><div class="bkk-table-scroll"><table class="bkk-table"><thead><tr><th>Pelamar</th><th>Lowongan</th><th>Perusahaan</th><th>Dikirim</th><th>Status / Catatan BKK</th><th>Riwayat</th><th>Simpan</th></tr></thead><tbody><?php if (!$rows): ?><tr><td colspan="7" style="text-align:center">Belum ada lamaran masuk.</td></tr><?php endif; ?><?php foreach ($rows as $row): ?><tr><td><?= h($row['pelamar']) ?><br><small><?= h($row['email']) ?> &middot; <?= h($row['no_hp']) ?></small></td><td><?= h($row['posisi']) ?></td><td><?= h($row['perusahaan']) ?></td><td><?= date('d M Y',strtotime($row['tanggal_melamar'])) ?></td><td><form class="bkk-inline-form" method="post" style="display:block"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="update_application"><input type="hidden" name="application_id" value="<?= (int)$row['id'] ?>"><input type="hidden" name="tab" value="lamaran"><select name="status" style="width:100%"> <?php foreach (['Lamaran Masuk','Seleksi Administrasi','Tes','Interview','Diterima','Ditolak'] as $status): ?><option <?= $row['status']===$status?'selected':'' ?>><?= h($status) ?></option><?php endforeach; ?></select><input name="catatan_admin" placeholder="Catatan untuk pelamar" value="<?= h($row['catatan_admin']??'') ?>" style="width:100%;margin-top:5px"></td><td><details><summary>Timeline</summary><?php $timeline=$pdo->prepare('SELECT status,catatan,tanggal FROM bkk_riwayat_lamaran WHERE lamaran_id=? ORDER BY tanggal DESC');$timeline->execute([(int)$row['id']]);foreach($timeline->fetchAll() as $item): ?><p class="bkk-history-item"><strong><?= h($item['status']) ?></strong><br><?= h($item['catatan']??'') ?><br><small><?= date('d M Y H:i',strtotime($item['tanggal'])) ?></small></p><?php endforeach; ?></details></td><td><button class="bkk-text-link" type="submit">Simpan status</button></form></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php elseif ($tab==='dokumen'): ?><section class="bkk-admin-panel"><h2>Dokumen Pencari Kerja</h2><div class="bkk-table-scroll"><table class="bkk-table"><thead><tr><th>Nama</th><th>Jurusan</th><th>CV</th><th>Sertifikat</th><th>Portofolio</th><th>Terakhir diperbarui</th></tr></thead><tbody><?php if (!$rows): ?><tr><td colspan="6" style="text-align:center">Belum ada dokumen terunggah.</td></tr><?php endif; ?><?php foreach($rows as $row): ?><tr><td><?= h($row['nama']) ?></td><td><?= h($row['jurusan']) ?></td><td><?php if($row['cv']): ?><a class="bkk-download" href="bkk-download.php?applicant=<?= (int)$row['id'] ?>&kind=cv">Unduh CV</a><?php else: ?>-<?php endif; ?></td><td><?php if($row['sertifikat']): ?><a class="bkk-download" href="bkk-download.php?applicant=<?= (int)$row['id'] ?>&kind=sertifikat">Unduh sertifikat</a><?php else: ?>-<?php endif; ?></td><td><?php if($row['portofolio']): ?><a class="bkk-download" href="<?= h($row['portofolio']) ?>" target="_blank" rel="noopener noreferrer">Buka</a><?php else: ?>-<?php endif; ?></td><td><?= date('d M Y',strtotime($row['updated_at'])) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php elseif ($tab==='pengaturan'): ?><form class="bkk-admin-form" method="post"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="save_settings"><input type="hidden" name="tab" value="pengaturan"><h2>Identitas BKK</h2><div class="bkk-admin-form-grid"><label>Nama BKK<input name="nama_bkk" required value="<?= h($settings['nama_bkk']??'') ?>"></label><label>Email<input type="email" name="email" value="<?= h($settings['email']??'') ?>"></label><label>Telepon<input name="telepon" value="<?= h($settings['telepon']??'') ?>"></label><label class="span-all">Tautan video YouTube atau Instagram (opsional)<input name="video_url" value="<?= h($settings['video_url'] ?? '') ?>" placeholder="https://www.youtube.com/watch?v=... or https://www.instagram.com/reel/..."></label><label class="span-all">Alamat<input name="alamat" value="<?= h($settings['alamat']??'') ?>"></label><label class="span-all">Deskripsi<textarea name="deskripsi" rows="5"><?= h($settings['deskripsi']??'') ?></textarea></label></div><div class="bkk-admin-form-actions"><button class="btn btn-navy">Simpan Pengaturan</button></div></form><?php endif; ?>
</main>
<script src="assets/main.js"></script>
</body>
</html>
