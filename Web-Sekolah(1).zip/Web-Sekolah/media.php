<?php
require_once __DIR__ . '/includes/media.php';

$sourceInput = $_GET['source'] ?? '';
if (!is_string($sourceInput)) {
    http_response_code(400);
    exit('Permintaan media tidak valid.');
}

$source = media_normalize_source($sourceInput);
$key = hash('sha256', $source);
$stmt = $pdo->prepare('SELECT source_path, uploaded_path, mime_type FROM site_media WHERE media_key = ? LIMIT 1');
$stmt->execute([$key]);
$media = $stmt->fetch();

$relativePath = $media && $media['uploaded_path'] !== null ? $media['uploaded_path'] : $source;
if (preg_match('~^https?://~i', $relativePath)) {
    $url = parse_url($relativePath);
    if (($url['scheme'] ?? '') !== 'https' || !in_array(strtolower($url['host'] ?? ''), ['images.pexels.com'], true)) {
        http_response_code(404);
        exit('Media tidak ditemukan.');
    }
    header('Location: ' . $relativePath, true, 302);
    exit;
}

$relativePath = str_replace('\\', '/', $relativePath);
if (str_contains($relativePath, '..') || !preg_match('~^(assets|uploads)/[A-Za-z0-9 _./()-]+\.(?:jpe?g|png|webp|gif|svg)$~i', $relativePath)) {
    http_response_code(404);
    exit('Media tidak ditemukan.');
}

$path = realpath(__DIR__ . '/' . $relativePath);
$root = realpath(__DIR__);
if ($path === false || $root === false || !str_starts_with(strtolower($path), strtolower($root . DIRECTORY_SEPARATOR)) || !is_file($path)) {
    http_response_code(404);
    exit('Media tidak ditemukan.');
}

$mime = $media && $media['uploaded_path'] !== null ? $media['mime_type'] : (new finfo(FILEINFO_MIME_TYPE))->file($path);
if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/svg+xml'], true)) {
    http_response_code(415);
    exit('Tipe media tidak didukung.');
}

header('Content-Type: ' . $mime);
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=3600');
readfile($path);
