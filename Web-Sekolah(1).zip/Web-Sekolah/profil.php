<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/gallery.php';
$galleryImages = gallery_images();
$galleryImageSelections = gallery_page_image_selections();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Profil Sekolah | SMK Infokom Bogor</title>
<meta name="description" content="Profil, sejarah, visi misi, dan sambutan kepala sekolah SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility">
  <div class="wrap">
    <a href="profil.php">Kunjungi Kami</a>
    <a href="ppdb.php">Daftar PPDB</a>
    <a href="portal.php">Portal Siswa &amp; Orang Tua</a>
  </div>
</div>

<nav class="nav" id="mainNav">
  <div class="wrap nav-row">
    <a href="index.php" class="brand">
      <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
      <span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span>
    </a>
    <div class="nav-links">
      <div class="nav-item">
        <a href="profil.php" class="nav-link">Profil</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Profil</h5>
            <a href="profil.php">Profil &amp; Sejarah Sekolah</a>
            <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
            <a href="profil.php#struktur">Struktur Organisasi</a>
            <a href="visi-misi.php">Visi &amp; Misi</a>
            
          </div>
          
        </div>
      </div>
      <a href="guru.php" class="nav-link">Guru</a>
      <div class="nav-item">
        <a href="akademik.php" class="nav-link">Akademik</a>
        <div class="mega">
          <div class="mega-col">
            <h5>Program Keahlian</h5>
            <a href="akademik.php">Rekayasa Perangkat Lunak</a>
            <a href="akademik.php">Teknik Komputer &amp; Jaringan</a>
            <a href="akademik.php">DKV (Desain Komunikasi Visual)</a>
            <a href="akademik.php">PSPT</a>
          </div>
          <div class="mega-col">
            <h5>Penunjang</h5>
            <a href="akademik.php">Fasilitas &amp; Laboratorium</a>
            
            
            
  <a href="portal-siswa-login.php">Portal Siswa</a>
            <a href="portal-siswa-login.php">Portal Siswa</a>
          </div>
        </div>
      </div>
      <a href="bkk.php" class="nav-link">BKK</a>
      <a href="info.php" class="nav-link">Info &amp; Berita</a>
      <a href="galeri.php" class="nav-link">Galeri</a>
      <a href="kontak.php" class="nav-link">Kontak</a>
    </div>
    <div class="nav-cta">
      <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
      <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
      
      <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
  <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
  <div class="m-group">Tentang Kami</div>
  <a href="profil.php">Profil &amp; Sejarah</a>
  <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
  <a href="profil.php#struktur">Struktur Organisasi</a>
  <a href="visi-misi.php">Visi &amp; Misi</a>
  <a href="guru.php">Guru &amp; Tenaga Pendidik</a>
  
  <div class="m-group">Akademik</div>
  <a href="akademik.php">Program Keahlian</a>
  <a href="bkk.php">Bursa Kerja Khusus (BKK)</a>
  
  
  
  <div class="m-group">Lainnya</div>
  <a href="ppdb.php">PPDB</a>
  <a href="admin-login.php">Login Admin</a>
  <a href="info.php">Info &amp; Berita</a>
  <a href="galeri.php">Galeri</a>
  <a href="kontak.php">Kontak</a>
</div>
<header class="page-hero page-hero-centered">
  <div class="wrap">
    <div class="crumb"><a href="index.php">Beranda</a> / Tentang Kami</div>
    <h1 class="split">Profil Sekolah</h1>
    <p>Berisi Sejarah Sekolah, Visi&Misi, Dan Sambutan kepala sekolah SMK Infokom Bogor.</p>
  </div>
</header>

<section class="explore" id="profil">
  <div class="wrap explore-grid">
    <div class="thumb-cluster reveal-right" style="order:-1;">
      <div class="thumb thumb-1">
        <img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_main', 'fasilitas', ['gedung utama', 'area smk'], 'assets/img/gedung-infokom.jpg')) ?>" alt="" loading="lazy">
      </div>
      <div class="thumb thumb-2">
        <img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_activities', 'kegiatan', ['workshop', 'sesi kerja tim'], 'https://images.pexels.com/photos/34787376/pexels-photo-34787376.jpeg?auto=compress&cs=tinysrgb&w=700')) ?>" alt="" loading="lazy">
      </div>
      <div class="thumb thumb-3">
        <img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_academic', 'akademik', ['praktik pemrograman', 'kelas praktik', 'aktivitas lab'], 'https://images.pexels.com/photos/10638065/pexels-photo-10638065.jpeg?auto=compress&cs=tinysrgb&w=700')) ?>" alt="" loading="lazy">
      </div>
      <div class="thumb thumb-4">
        <img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_library', 'fasilitas', ['perpustakaan', 'kantin'], 'https://images.pexels.com/photos/5147366/pexels-photo-5147366.jpeg?auto=compress&cs=tinysrgb&w=700')) ?>" alt="" loading="lazy">
      </div>
    </div>
    <div class="reveal-left"><div class="eyebrow">Profil Sekolah</div>
      <h2 class="split">Tumbuh bersama industri digital Bogor sejak 2007</h2>
      <p>SMK INFOKOM Kota Bogor berdiri pada tahun 2005 di bawah naungan Yayasan Telekomunikasi Nasional (YATELNAS). Sekolah ini berfokus pada pendidikan kejuruan di bidang teknologi informasi, komputer, dan telekomunikasi. Seiring perkembangan zaman, SMK INFOKOM terus meningkatkan kualitas pendidikan untuk menghasilkan lulusan yang kompeten, kreatif, dan siap menghadapi dunia kerja.</p>
      <div class="sambutan" style="margin-top:26px;border-left:3px solid var(--gold);padding-left:20px;">
        <p style="font-style:italic;font-size:15px;color:var(--ink);">"Kami tidak hanya mengajarkan siswa cara memakai teknologi, tapi cara berpikir seperti orang yang membangunnya — teliti, sabar mencari akar masalah, dan terbuka untuk terus belajar."</p>
        <cite style="display:block;margin-top:12px;font-style:normal;font-family:'Libre Franklin',sans-serif;font-weight:700;font-size:14px;color:var(--navy);">Ir. Hj. Liliek Rahmaningsih, M.M.Pd. <span style="display:block;font-family:'Inter',sans-serif;font-weight:400;font-size:13px;color:var(--muted);">Kepala Sekolah SMK Infokom Bogor</span></cite>
      </div>
      <div style="display:flex;flex-wrap:wrap;column-gap:26px;">
        <a href="#sambutan" class="browse-link">Baca Sambutan Lengkap Kepala Sekolah <svg width="14" height="14" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
        <a href="visi-misi.php" class="browse-link">Visi, Misi &amp; Nilai Sekolah <svg width="14" height="14" viewBox="0 0 14 14"><path d="M2 7h9M7 3l4 4-4 4" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
      </div>
    </div>
  </div>
</section>

<!-- ================= SAMBUTAN KEPALA SEKOLAH ================= -->
<section class="explore" id="sambutan" style="background:var(--sky);scroll-margin-top:100px;">
  <div class="wrap" style="display:grid;grid-template-columns:.85fr 1.15fr;gap:56px;align-items:center;">
    <div class="reveal-left" style="text-align:center;">
      <div style="width:220px;height:220px;border-radius:50%;margin:0 auto;overflow:hidden;border:4px solid var(--white);box-shadow:var(--shadow);">
        <img src="<?= site_media_html('uploads/guru/liliek-rahmaningsih.png') ?>" alt="Ir. Hj. Liliek Rahmaningsih, M.M.Pd. — Kepala Sekolah SMK Infokom Bogor" loading="lazy" style="width:100%;height:100%;object-fit:cover;object-position:top;display:block;">
      </div>
      <h4 style="margin-top:18px;font-size:16px;">Ir. Hj. Liliek Rahmaningsih, M.M.Pd.</h4>
      <span style="display:block;margin-top:4px;font-size:13px;color:var(--muted);">Kepala Sekolah SMK Infokom Bogor</span>
    </div>
    <div class="reveal-right">
      <div class="eyebrow">Sambutan Kepala Sekolah</div>
      <h2 class="split" style="font-size:clamp(24px,2.8vw,30px);margin-bottom:18px;">Selamat datang di SMK Infokom Bogor</h2>
      <p style="font-size:15px;color:var(--ink);line-height:1.85;">Assalamu'alaikum warahmatullahi wabarakatuh. Puji syukur kami panjatkan atas kesempatan mendampingi putra-putri terbaik bangsa menempuh pendidikan kejuruan di bidang informatika dan telekomunikasi.</p>
      <p style="margin-top:14px;font-size:15px;color:var(--ink);line-height:1.85;">Di SMK Infokom Bogor, kami percaya bahwa keterampilan teknis harus berjalan beriringan dengan karakter yang kuat. Karena itu, setiap siswa tidak hanya dibekali kemampuan coding, jaringan, desain, maupun produksi siaran — tapi juga kejujuran, kedisiplinan, dan kemauan untuk terus belajar sepanjang hayat.</p>
      <p style="margin-top:14px;font-size:15px;color:var(--ink);line-height:1.85;">Kami mengundang seluruh calon siswa dan orang tua untuk menjadi bagian dari keluarga besar SMK Infokom Bogor, tempat mimpi menjadi ahli teknologi masa depan dimulai.</p>
      <p style="margin-top:20px;font-family:'Libre Franklin',sans-serif;font-weight:700;font-size:14.5px;color:var(--navy);">Ir. Hj. Liliek Rahmaningsih, M.M.Pd.</p>
    </div>
  </div>
</section>

<!-- ================= STRUKTUR ORGANISASI ================= -->
<section class="explore" id="struktur" style="scroll-margin-top:100px;">
  <div class="wrap">
    <div class="section-head reveal" style="max-width:600px;margin:0 auto 50px;text-align:center;">
      <div class="eyebrow" style="justify-content:center;">Struktur Organisasi</div>
      <h2 class="split centered-section-title" style="font-size:clamp(24px,2.8vw,32px);">Susunan pengelola sekolah</h2>
    </div>
    <div class="reveal" style="max-width:1080px;margin:0 auto;">
      <div style="text-align:center;margin-bottom:0;">
        <div class="org-chief-card" style="display:inline-flex;flex-direction:column;align-items:center;gap:8px;background:var(--navy);color:var(--white);border-radius:var(--r);padding:12px 28px;text-align:center;">
          <img class="org-person-photo" src="<?= site_media_html('uploads/guru/liliek-rahmaningsih.png') ?>" alt="Foto Ir. Hj. Liliek Rahmaningsih" loading="lazy">
          <h4 style="color:var(--white);font-size:15px;">Kepala Sekolah</h4>
          <span style="font-size:12.5px;color:#B9C4D2;">Ir. Hj. Liliek Rahmaningsih, M.M.Pd.</span>
        </div>
      </div>
      <div style="width:1.5px;height:26px;background:var(--line);margin:0 auto;"></div>
      <div class="org-connector cols-5" style="display:grid;grid-template-columns:repeat(5,1fr);gap:14px;">
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/mila-yaelasari.png') ?>" alt="Foto Mila Yaelasari" loading="lazy"><h4 style="font-size:12.5px;">Waka Kurikulum</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Mila Yaelasari, M.Pd.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/dea-rijalul-fikri.png') ?>" alt="Foto Dea Rijalul Fikri" loading="lazy"><h4 style="font-size:12.5px;">Waka Kesiswaan</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Dea Rijalul Fikri, S.Kom.,Gr.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/radiani-srirestuti-dewi.png') ?>" alt="Foto R. Radiani Srirestuti Dewi" loading="lazy"><h4 style="font-size:12.5px;">Waka Humas &amp; Industri</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">R. Radiani Srirestuti Dewi, SS.,Gr.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/heny-handayani.png') ?>" alt="Foto Heny Handayani" loading="lazy"><h4 style="font-size:12.5px;">Waka SDM</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Heny Handayani, S.Pd.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/agus-tiyono.png') ?>" alt="Foto Agus Tiyono" loading="lazy"><h4 style="font-size:12.5px;">Waka Sarana &amp; Prasarana</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Agus Tiyono, M.Pd.</span></div>
      </div>
      <div style="width:1.5px;height:26px;background:var(--line);margin:0 auto;"></div>
      <div class="org-connector cols-4" style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;">
        <div class="org-person-card" style="background:var(--sky);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/aditya-nugraha.png') ?>" alt="Foto Aditya Nugraha" loading="lazy"><h4 style="font-size:12.5px;">Ketua Manajemen Mutu</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Aditya Nugraha, ST.</span></div>
        <div class="org-person-card" style="background:var(--sky);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/cahyadi-rozi.png') ?>" alt="Foto Cahyadi Rozi" loading="lazy"><h4 style="font-size:12.5px;">Kepala Tata Usaha</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Cahyadi Rozi, ST.</span></div>
        <div class="org-person-card" style="background:var(--sky);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/puji-marhaen-waluyo.png') ?>" alt="Foto Drs. Puji Marhaen Waluyo" loading="lazy"><h4 style="font-size:12.5px;">Kepala Perpustakaan</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Drs. Puji Marhaen Waluyo</span></div>
        <div class="org-person-card" style="background:var(--sky);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/putri-riandini.png') ?>" alt="Foto Putri Riandini" loading="lazy"><h4 style="font-size:12.5px;">Kepala Bendahara</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Putri Riandini, S.Hut., M.Pd.,Gr.</span></div>
      </div>
      <div style="width:1.5px;height:26px;background:var(--line);margin:0 auto;"></div>
      <div class="org-connector cols-4" style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;">
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/aditya-nugraha.png') ?>" alt="Foto Aditya Nugraha" loading="lazy"><h4 style="font-size:12.5px;">Kepala Program TKJ</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Aditya Nugraha, ST.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/ridwan-hala.png') ?>" alt="Foto Ridwan Hala" loading="lazy"><h4 style="font-size:12.5px;">Kepala Program RPL</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Ridwan Hala, S.Kom.,Gr.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/muhammad-ibnu-arif.png') ?>" alt="Foto Muhammad Ibnu Arif" loading="lazy"><h4 style="font-size:12.5px;">Kepala Program DKV</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Muhammad Ibnu Arif, S.IKom.</span></div>
        <div class="org-person-card" style="background:var(--white);border:1px solid var(--line);border-radius:var(--r);padding:16px 10px;text-align:center;"><img class="org-person-photo" src="<?= site_media_html('uploads/guru/erli-suherli.png') ?>" alt="Foto Erli Suherli" loading="lazy"><h4 style="font-size:12.5px;">Kepala Program PSPT</h4><span style="display:block;margin-top:4px;font-size:11.5px;color:var(--muted);">Erli Suherli, A.Md.Kom.</span></div>
      </div>
    </div>
  </div>
</section>

<!-- ================= STAF & GURU LAINNYA ================= -->
<section class="explore" style="background:var(--sky);">
  <div class="wrap">
    <div class="section-head reveal" style="max-width:600px;margin:0 auto 40px;text-align:center;">
      <div class="eyebrow" style="justify-content:center;">Staf &amp; Koordinator</div>
      <h2 class="split centered-section-title" style="font-size:clamp(22px,2.6vw,28px);">Tim pendukung kegiatan sekolah</h2>
      <p class="centered-section-copy" style="margin-top:12px;color:var(--muted);font-size:14.5px;">Daftar lengkap seluruh guru dan tenaga kependidikan dapat dilihat di halaman <a href="guru.php" class="browse-link" style="display:inline;">Guru &amp; Tenaga Pendidik</a>.</p>
    </div>
    <div class="staff-team-grid reveal" data-stagger>
      <div class="staff-team-card"><h4>Pembina OSIS</h4><div class="staff-person-list">
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/ahmad-hotib.png') ?>" alt="Foto Ahmad Hotib" loading="lazy"><span>Ahmad Hotib, S.Pd.I</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/abdul-azis.png') ?>" alt="Foto Abdul Azis" loading="lazy"><span>Abdul Azis, M.Pd.</span></div>
      </div></div>
      <div class="staff-team-card"><h4>Staf Kurikulum</h4><div class="staff-person-list">
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/vera-yuni-astuti.png') ?>" alt="Foto Vera Yuni Astuti" loading="lazy"><span>Vera Yuni Astuti, SP., M.IKom.,Gr.</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/fauzan-arifin.png') ?>" alt="Foto M. Fauzan Arifin" loading="lazy"><span>M. Fauzan Arifin, S.IKom.,Gr.</span></div>
      </div></div>
      <div class="staff-team-card"><h4>Guru Bimbingan &amp; Konseling</h4><div class="staff-person-list">
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/popon-puspitasari.png') ?>" alt="Foto Popon Puspitasari" loading="lazy"><span>Dra. Popon Puspitasari</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/richo-santana.png') ?>" alt="Foto Richo Santana" loading="lazy"><span>Richo Santana, S.Kom.</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/dian-hardianti.png') ?>" alt="Foto Dian Hardianti" loading="lazy"><span>Dian Hardianti, S.Kom.,Gr.</span></div>
      </div></div>
      <div class="staff-team-card"><h4>Staf Teller (Bendahara)</h4><div class="staff-person-list">
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/yeni-yuliawati.png') ?>" alt="Foto Yeni Yuliawati" loading="lazy"><span>Yeni Yuliawati, S.Pd.,Gr.</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/rita-widyastuti.png') ?>" alt="Foto Rita Widyastuti" loading="lazy"><span>Rita Widyastuti</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/eva-farida-rahayu.png') ?>" alt="Foto Eva Farida Rahayu" loading="lazy"><span>Eva Farida Rahayu, S.Pd.,Gr.</span></div>
      </div></div>
      <div class="staff-team-card"><h4>Staf Tata Usaha</h4><div class="staff-person-list">
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/jayadi.png') ?>" alt="Foto Jayadi" loading="lazy"><span>Jayadi, S.Pd.,Gr.</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/yadi-setiadi.png') ?>" alt="Foto Yadi Setiadi" loading="lazy"><span>Yadi Setiadi, S.Sos.,Gr.</span></div>
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/siti-nuraeni.png') ?>" alt="Foto Siti Nuraeni" loading="lazy"><span>Siti Nuraeni</span></div>
      </div></div>
      <div class="staff-team-card"><h4>Staf Perpustakaan</h4><div class="staff-person-list">
        <div class="staff-person"><img src="<?= site_media_html('uploads/guru/reza-prafitriansyah.png') ?>" alt="Foto Reza Prafitriansyah" loading="lazy"><span>Reza Prafitriansyah, S.Kom.,Gr.</span></div>
      </div></div>
    </div>
  </div>
</section>

<!-- ================= FASILITAS SEKOLAH ================= -->
<section class="explore" style="background:var(--sky);">
  <div class="wrap">
    <div class="section-head reveal" style="max-width:600px;margin:0 auto 44px;text-align:center;">
      <div class="eyebrow" style="justify-content:center;">Fasilitas Sekolah</div>
      <h2 class="split centered-section-title" style="font-size:clamp(24px,2.8vw,32px);">Ruang belajar yang menunjang praktik</h2>
    </div>
    <div class="reveal" data-stagger style="display:grid;grid-template-columns:repeat(4,1fr);gap:18px;">
      <div style="background:var(--white);border-radius:var(--r);overflow:hidden;">
        <div style="height:110px;overflow:hidden;"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_lab', 'akademik', ['aktivitas lab', 'kelas praktik'], 'https://images.pexels.com/photos/10638065/pexels-photo-10638065.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:16px;"><h4 style="font-size:14px;">Lab Komputer &amp; Jaringan</h4><p style="margin-top:6px;font-size:12.5px;color:var(--muted);">4 ruang lab, diperbarui tiap 3 tahun.</p></div>
      </div>
      <div style="background:var(--white);border-radius:var(--r);overflow:hidden;">
        <div style="height:110px;overflow:hidden;"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_multimedia', 'kegiatan', ['produksi konten dkv', 'studio dkv', 'videografi', 'fotografi'], 'https://images.pexels.com/photos/17115910/pexels-photo-17115910.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:16px;"><h4 style="font-size:14px;">Studio DKV</h4><p style="margin-top:6px;font-size:12.5px;color:var(--muted);">Ruang produksi &amp; editing desain visual.</p></div>
      </div>
      <div style="background:var(--white);border-radius:var(--r);overflow:hidden;">
        <div style="height:110px;overflow:hidden;"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_server', 'fasilitas', ['server', 'jaringan'], 'https://images.pexels.com/photos/4508751/pexels-photo-4508751.jpeg?auto=compress&cs=tinysrgb&w=500')) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:16px;"><h4 style="font-size:14px;">Ruang Server</h4><p style="margin-top:6px;font-size:12.5px;color:var(--muted);">Infrastruktur praktik TKJ.</p></div>
      </div>
      <div style="background:var(--white);border-radius:var(--r);overflow:hidden;">
        <div style="height:110px;overflow:hidden;"><img src="<?= site_media_html(gallery_image_for_display($galleryImages, $galleryImageSelections, 'profile_library_facility', 'fasilitas', ['perpustakaan'], 'assets/img/gedung-infokom.jpg')) ?>" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover;display:block;"></div>
        <div style="padding:16px;"><h4 style="font-size:14px;">Perpustakaan Digital</h4><p style="margin-top:6px;font-size:12.5px;color:var(--muted);">Akses modul &amp; e-book teknis.</p></div>
      </div>
    </div>
  </div>
</section>


<footer class="footer">
  <div class="wrap">
    <div class="foot-top">
      <div class="foot-logo">
        <div class="brand">
          <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
          <span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span>
        </div>
        <p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p>
        <p>(0251) 837-2210</p>
      </div>
      <a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a>
    </div>
    <div class="foot-cols">
      <div class="foot-col">
        <h5>Komunitas</h5>
        <ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Informasi</h5>
        <ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul>
      </div>
      <div class="foot-col">
        <h5>Akses Cepat</h5>
        <ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul>
      </div>
    </div>
    <div class="foot-sub">
      <div class="foot-social">
        <a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
        <a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a>
        <a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a>
      </div>
      <a href="index.php" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a>
    </div>
    <div class="foot-bottom">
      <span>© 2026 SMK Infokom Bogor.</span>
      <div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div>
    </div>
  </div>
</footer>
<script src="assets/main.js"></script>
</body>
</html>
