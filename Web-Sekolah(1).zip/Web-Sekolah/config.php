<?php
/**
 * Konfigurasi koneksi database.
 * Sesuaikan DB_HOST, DB_NAME, DB_USER, DB_PASS dengan setup lokal Anda
 * (default XAMPP: host=localhost, user=root, password=kosong).
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('DB_HOST', 'localhost');
define('DB_NAME', 'smk_infokom');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die(
        '<div style="font-family:sans-serif;max-width:640px;margin:60px auto;padding:24px;' .
        'border:1px solid #eee;border-radius:8px;background:#fff8f8;">' .
        '<h2 style="color:#A6192E;margin-top:0;">Koneksi database gagal</h2>' .
        '<p>Pastikan MySQL sudah berjalan dan database <code>' . DB_NAME . '</code> sudah dibuat ' .
        'dengan mengimpor file <code>database/schema.sql</code> lewat phpMyAdmin.</p>' .
        '<p style="color:#888;font-size:13px;">Detail teknis: ' . htmlspecialchars($e->getMessage()) . '</p>' .
        '</div>'
    );
}
