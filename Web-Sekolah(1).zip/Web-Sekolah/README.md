# Website SMK Infokom Bogor — Versi PHP + Database

Website ini sudah diubah dari HTML statis menjadi PHP dengan backend penuh:
login (admin/siswa/orang tua), database MySQL, dan form yang benar-benar
menyimpan data.

## Cara Menjalankan (XAMPP / Laragon)

1. **Install server PHP lokal** kalau belum punya:
   XAMPP (Windows/Mac/Linux) — download di apachefriends.org, atau
   Laragon (Windows).

2. **Salin folder ini** ke folder web server:
   - XAMPP: `C:/xampp/htdocs/Web-Sekolah/` (atau `/opt/lampp/htdocs/...` di Linux/Mac)
   - Laragon: `C:/laragon/www/Web-Sekolah/`

3. **Buat database**: buka phpMyAdmin (`http://localhost/phpmyadmin`),
   klik **Import**, pilih file `database/schema.sql` dari folder ini, lalu **Go**.
   File ini otomatis membuat database `smk_infokom`, tabel sekolah dan BKK,
   serta data sekolah contoh. File BKK sudah termasuk; jangan impor `bkk.sql`
   lagi untuk instalasi baru.
   Untuk database lama, impor `database/requests-status.sql` sekali agar pesan
   Kontak memiliki kolom status yang diperlukan panel Penerimaan.

4. **Jalankan Apache + MySQL** dari XAMPP/Laragon control panel.

5. **Buka di browser**: `http://localhost/Web-Sekolah/index.php`

Setelah mengimpor skema, gunakan akun admin awal berikut:

| Role  | Username | Password |
|-------|----------|----------|
| Admin | `admin1` | `admin2` |

Ganti kata sandi awal tersebut setelah login pertama dan jangan gunakan
kredensial ini pada situs produksi.

## Konfigurasi Database

Kalau username/password MySQL Anda berbeda dari default XAMPP (`root` tanpa
password), sesuaikan di file `config.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'smk_infokom');
define('DB_USER', 'root');
define('DB_PASS', '');
```

## Modul Bursa Kerja Khusus (BKK)

Pada instalasi baru, tabel BKK dan role `admin_bkk`/`alumni` sudah dibuat oleh
`database/schema.sql`. Untuk database sekolah lama yang belum memiliki tabel
BKK, pilih database `smk_infokom` lalu impor `database/bkk.sql` sebagai migrasi.

- Halaman publik: `bkk.php` (lowongan, filter, mitra, agenda, berita, profil, lamaran, dan status).
- Panel admin: `admin-bkk.php` (dashboard, CRUD lowongan/mitra/event/berita, pelamar, lamaran, dokumen, dan pengaturan).
- Berkas CV/sertifikat disimpan di `uploads/bkk/private` dan dilayani melalui `bkk-download.php` setelah pemeriksaan akses.
- Untuk pratinjau lokal, import `database/bkk-demo.sql` setelah migrasi utama. Isinya perusahaan, lowongan, agenda, dan berita fiktif berlabel DEMO; halaman publik menampilkan peringatan selama data contoh masih ada. Jangan gunakan seed demo sebagai informasi rekrutmen produksi.
- Buat akun melalui mekanisme akun sekolah yang sudah ada, lalu tetapkan role `admin_bkk` atau `alumni` pada akun terkait. Admin sekolah (`admin`) juga dapat mengelola seluruh bagian BKK.
- Pastikan `uploads/` dapat ditulis oleh Apache. Akun siswa yang melamar harus sudah tertaut ke record pada `users`; NISN diambil dari relasi `ref_id` bila tersedia.

Pengajuan lamaran dan statusnya hanya dapat dilihat oleh akun pemilik.

## Fitur CRUD "Kelola Konten" (Baru)

Login sebagai admin, lalu klik **Kelola Konten** di dashboard. Di sana admin bisa
**Tambah / Edit / Hapus** untuk semua data berikut — perubahan langsung tampil
di halaman publik:

| Data              | Tampil di halaman publik |
|-------------------|---------------------------|
| Guru & Staf (+ foto, jabatan) | `guru.php` |
| Berita & Prestasi (+ foto)    | `info.php` |
| Galeri Foto                   | `galeri.php`, `index.php`, `profil.php` |
| Foto Beranda & Profil         | `index.php`, `profil.php` |
| Foto Akademik                 | `akademik.php` |
| Media Kunjungan Industri & Mitra | `kunjungan-industri.php`, `mitra-kerja.php` |
| Video (unggahan / YouTube)    | `galeri.php`, `info.php` |
| Ekstrakurikuler (+ foto)      | `ekstrakurikuler.php` |
| Data Siswa                    | dashboard siswa/ortu, absensi |
| Data Kelas                    | form tambah siswa/absensi |
| Data Orang Tua                | relasi ke akun ortu |

Foto yang diunggah admin disimpan di folder `uploads/` — pastikan folder ini
bisa ditulis oleh server (`chmod 755 uploads` di Linux/Mac; di XAMPP Windows
biasanya otomatis bisa).
Foto pada cuplikan Galeri di Beranda dan area foto Profil memakai data Galeri
yang sama. Foto dipilih berdasarkan kecocokan judul dengan bagian yang
ditampilkan, seperti nama gedung, praktik komputer, DKV, atau
perpustakaan. Jika belum ada foto Galeri dengan judul yang sesuai, gambar
cadangan yang sudah tersedia tetap digunakan daripada menampilkan foto yang
tidak relevan.
Admin dapat memilih foto spesifik untuk tiap bagian melalui tab **Foto Beranda
& Profil**. Untuk database yang sudah ada, impor `database/page-images.sql`;
instalasi baru sudah memiliki tabel pilihan foto di `database/schema.sql`.
Foto untuk halaman Kunjungan Industri dan Mitra Kerja Sama dapat diunggah,
diubah, dinonaktifkan, atau dihapus melalui tab **Media** pada Kelola Konten.
Berkas disimpan di `uploads/page-media/`; untuk database yang sudah ada, impor
`database/page-media.sql`. Instalasi baru mendapat tabel `page_media` dari
`database/schema.sql`.
Foto program keahlian dan logo Teaching Factory dapat diganti satu per satu
melalui tab **Foto Akademik** di Kelola Konten. Untuk database yang sudah ada,
impor `database/akademik-images.sql`; instalasi baru sudah memiliki tabel
`akademik_images` di `database/schema.sql`. Berkas foto disimpan di
`uploads/akademik/`.

### Video Website

Tab **Video** pada Kelola Konten mendukung unggahan MP4, WebM, dan Ogg hingga
100 MB atau URL YouTube, thumbnail JPG/PNG/WebP hingga 5 MB, edit, hapus,
serta status aktif/nonaktif. Hanya video aktif ditampilkan pada halaman
`galeri.php` dan bagian **Info dalam Video** di `info.php`. Data video dan
lokasi file tersimpan di tabel `videos`; file video dan thumbnail berada
permanen di `uploads/videos/` dan `uploads/video-thumbnails/`, sehingga tetap
tersedia setelah browser ditutup atau sesi admin berakhir. Jangan hapus folder
`uploads/` atau database jika ingin mempertahankan berkasnya. Untuk database yang sudah ada, impor
`database/video.sql`; instalasi baru mendapat tabel `videos` dari
`database/schema.sql`. Pastikan `upload_max_filesize` diatur minimal `100M`
dan `post_max_size` sedikit lebih besar dari `100M` di konfigurasi PHP server.

### Galeri Magang Jepang

Tab **Galeri Magang Jepang** pada Kelola Konten mengelola gambar, video
unggahan, video YouTube, dan konten teks khusus halaman `magang-jepang.php`.
Unggahan gambar maksimal 5 MB; video lokal maksimal 100 MB. Untuk database
yang sudah ada, impor `database/japan-gallery.sql`. Instalasi baru memperoleh
tabel `japan_gallery` dari `database/schema.sql`.

## Apa yang Sudah Berfungsi Penuh

- **Login 3 role** (admin, siswa, orang tua) dengan password ter-hash & sesi aman
- **Dashboard Admin** — statistik real dari database, form "Tambah Data"
  (siswa/guru/orang tua/kelas) tersimpan ke database
- **Absensi Admin** — tabel dari database, filter per tanggal/kelas/status,
  form tambah absensi
- **Dashboard Siswa** — nilai, kehadiran, status SPP diambil dari data akun
  yang login
- **Dashboard Orang Tua** — data anak yang terhubung ke akun ortu
- **Formulir PPDB & Kontak** — pendaftaran dan pesan tersimpan dengan status
  menunggu verifikasi; admin dapat menerima atau menolak melalui
  `admin-penerimaan.php`
- **Formulir PPDB offline** — unduh PDF interaktif dari halaman `ppdb.php`,
  isi tanpa internet, lalu cetak dan serahkan kepada panitia PPDB. Pengisian
  PDF tidak mengirim data ke sistem pendaftaran online.
- Seluruh 27 halaman lain (profil, akademik, galeri, dll.) tetap tampil sama
  persis seperti versi HTML aslinya, hanya berformat `.php`.

## Struktur Folder

```
config.php              # koneksi database
includes/auth.php        # fungsi login & proteksi sesi
database/schema.sql      # skema sekolah + BKK dan seed (impor sekali untuk instalasi baru)
database/bkk.sql         # migrasi BKK untuk database sekolah lama
database/requests-status.sql # migrasi status pesan Kontak untuk database lama
database/video.sql       # migrasi video untuk database yang sudah ada
database/japan-gallery.sql # migrasi galeri Magang Jepang
includes/videos.php      # validasi sumber dan unggahan video
admin-login.php, admin-dashboard.php, admin-absensi.php, admin-penerimaan.php
portal-siswa-login.php, siswa-dashboard.php
portal-ortu-login.php, ortu-dashboard.php, siswa.php
ppdb.php, kontak.php
logout.php
... (halaman lainnya)
assets/                  # CSS & JS (tidak berubah)
```

## Catatan

- Field unggah berkas di form PPDB masih tampilan saja (belum menyimpan file
  fisik ke server) — bisa dikembangkan lebih lanjut kalau dibutuhkan.
- Ini dasar yang solid untuk dikembangkan; kalau butuh fitur tambahan
  (misalnya CRUD hapus/edit data siswa, upload foto, dsb), tinggal lanjutkan
  dari struktur yang sudah ada.
