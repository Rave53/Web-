<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/bkk.php';

$user = current_user();
$flash = $_SESSION['bkk_flash'] ?? null;
unset($_SESSION['bkk_flash']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    bkk_verify_csrf();
    $action = $_POST['action'] ?? '';
    if (!$user || !in_array($user['role'], ['siswa', 'alumni'], true)) {
        $_SESSION['bkk_flash'] = ['type' => 'error', 'text' => 'Silakan masuk melalui Portal Siswa untuk membuat profil atau melamar.'];
        header('Location: portal-siswa-login.php');
        exit;
    }

    try {
        if ($action === 'profile') {
            $jurusan = trim($_POST['jurusan'] ?? '');
            $phone = trim($_POST['no_hp'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $domisili = trim($_POST['domisili'] ?? '');
            $graduationYear = (int) ($_POST['tahun_lulus'] ?? 0);
            if (!in_array($jurusan, ['RPL', 'TKJ', 'DKV', 'PSPT'], true) || $phone === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $domisili === '') {
                throw new RuntimeException('Lengkapi jurusan, nomor HP, email valid, dan domisili.');
            }
            if ($graduationYear && ($graduationYear < 2000 || $graduationYear > (int) date('Y') + 2)) {
                throw new RuntimeException('Tahun lulus tidak valid.');
            }
            $cv = bkk_upload($_FILES['cv'] ?? [], 'cv');
            $certificate = bkk_upload($_FILES['sertifikat'] ?? [], 'cv');
            $portfolio = trim($_POST['portofolio'] ?? '');
            if ($portfolio !== '' && !filter_var($portfolio, FILTER_VALIDATE_URL)) {
                throw new RuntimeException('Tautan portofolio harus berupa URL yang valid.');
            }
            $student = null;
            if (!empty($user['ref_id'])) {
                $studentQuery = $pdo->prepare('SELECT nisn FROM siswa WHERE id = ?');
                $studentQuery->execute([(int) $user['ref_id']]);
                $student = $studentQuery->fetch();
            }
            $existingQuery = $pdo->prepare('SELECT cv, sertifikat FROM bkk_pelamar WHERE user_id = ?');
            $existingQuery->execute([(int) $user['id']]);
            $existing = $existingQuery->fetch() ?: [];
            $cv = $cv ?: ($existing['cv'] ?? null);
            $certificate = $certificate ?: ($existing['sertifikat'] ?? null);
            $applicantType = $user['role'] === 'alumni' ? 'Alumni' : 'Siswa';
            $graduationYearSql = $graduationYear ?: null;
            $saveProfile = $pdo->prepare("INSERT INTO bkk_pelamar (user_id, nisn, status_pelamar, tahun_lulus, jurusan, no_hp, email, domisili, cv, sertifikat, portofolio, skill, pengalaman)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE status_pelamar = VALUES(status_pelamar), tahun_lulus = VALUES(tahun_lulus), jurusan = VALUES(jurusan), no_hp = VALUES(no_hp), email = VALUES(email), domisili = VALUES(domisili), cv = VALUES(cv), sertifikat = VALUES(sertifikat), portofolio = VALUES(portofolio), skill = VALUES(skill), pengalaman = VALUES(pengalaman)");
            $saveProfile->execute([(int) $user['id'], $student['nisn'] ?? null, $applicantType, $graduationYearSql, $jurusan, $phone, $email, $domisili, $cv, $certificate, $portfolio ?: null, trim($_POST['skill'] ?? ''), trim($_POST['pengalaman'] ?? '')]);
            $_SESSION['bkk_flash'] = ['type' => 'success', 'text' => 'Profil pencari kerja berhasil disimpan.'];
        } elseif ($action === 'apply') {
            $jobId = (int) ($_POST['lowongan_id'] ?? 0);
            $profileQuery = $pdo->prepare('SELECT id FROM bkk_pelamar WHERE user_id = ? AND status = \'Aktif\'');
            $profileQuery->execute([(int) $user['id']]);
            $applicantId = $profileQuery->fetchColumn();
            if (!$applicantId) {
                throw new RuntimeException('Lengkapi profil pencari kerja sebelum mengirim lamaran.');
            }
            $jobQuery = $pdo->prepare("SELECT id FROM bkk_lowongan WHERE id = ? AND status = 'Aktif' AND deadline >= CURDATE()");
            $jobQuery->execute([$jobId]);
            if (!$jobQuery->fetchColumn()) {
                throw new RuntimeException('Lowongan ini sudah tidak menerima lamaran.');
            }
            $pdo->beginTransaction();
            $insertApplication = $pdo->prepare("INSERT INTO bkk_lamaran (pelamar_id, lowongan_id, status) VALUES (?, ?, 'Lamaran Masuk')");
            $insertApplication->execute([(int) $applicantId, $jobId]);
            $applicationId = (int) $pdo->lastInsertId();
            $history = $pdo->prepare("INSERT INTO bkk_riwayat_lamaran (lamaran_id, status, catatan) VALUES (?, 'Lamaran Masuk', 'Lamaran dikirim melalui halaman BKK.')");
            $history->execute([$applicationId]);
            $notification = $pdo->prepare('INSERT INTO bkk_notifikasi (user_id, judul, pesan, tautan) VALUES (?, ?, ?, ?)');
            $notification->execute([(int) $user['id'], 'Lamaran terkirim', 'Lamaran Anda berhasil dikirim dan sedang menunggu pemeriksaan.', 'bkk.php#status-lamaran']);
            $pdo->commit();
            $_SESSION['bkk_flash'] = ['type' => 'success', 'text' => 'Lamaran berhasil dikirim. Pantau perubahannya di bagian Status Lamaran.'];
        } elseif ($action === 'event') {
            $eventId = (int) ($_POST['event_id'] ?? 0);
            $profileQuery = $pdo->prepare('SELECT id FROM bkk_pelamar WHERE user_id = ? AND status = \'Aktif\'');
            $profileQuery->execute([(int) $user['id']]);
            $applicantId = $profileQuery->fetchColumn();
            if (!$applicantId) {
                throw new RuntimeException('Lengkapi profil pencari kerja sebelum mendaftar event.');
            }
            $pdo->beginTransaction();
            $eventQuery = $pdo->prepare("SELECT id, kuota, (SELECT COUNT(*) FROM bkk_peserta_event p WHERE p.event_id = e.id AND p.status <> 'Batal') peserta FROM bkk_event e WHERE id = ? AND status <> 'Selesai' AND tanggal >= CURDATE() FOR UPDATE");
            $eventQuery->execute([$eventId]);
            $event = $eventQuery->fetch();
            if (!$event || ($event['kuota'] && $event['peserta'] >= $event['kuota'])) {
                throw new RuntimeException('Event tidak tersedia atau kuotanya telah penuh.');
            }
            $register = $pdo->prepare('INSERT INTO bkk_peserta_event (event_id, pelamar_id) VALUES (?, ?)');
            $register->execute([$eventId, (int) $applicantId]);
            $pdo->commit();
            $_SESSION['bkk_flash'] = ['type' => 'success', 'text' => 'Pendaftaran event berhasil.'];
        } elseif ($action === 'read_notification') {
            $markRead = $pdo->prepare('UPDATE bkk_notifikasi SET dibaca = 1 WHERE id = ? AND user_id = ?');
            $markRead->execute([(int) ($_POST['notification_id'] ?? 0), (int) $user['id']]);
            $_SESSION['bkk_flash'] = ['type' => 'success', 'text' => 'Notifikasi ditandai sudah dibaca.'];
        }
    } catch (Throwable $exception) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $_SESSION['bkk_flash'] = ['type' => 'error', 'text' => $exception instanceof PDOException ? 'Data sudah tercatat atau proses tidak dapat diselesaikan.' : $exception->getMessage()];
    }

    $returnTo = bkk_safe_return($_POST['return_to'] ?? 'bkk.php');
    header('Location: ' . $returnTo);
    exit;
}

$settings = $pdo->query('SELECT * FROM bkk_settings WHERE id = 1')->fetch() ?: ['nama_bkk' => 'Bursa Kerja Khusus SMK Infokom Bogor', 'deskripsi' => '', 'video_url' => ''];
$demoCount = (int) $pdo->query("SELECT
    (SELECT COUNT(*) FROM bkk_perusahaan WHERE nama LIKE 'DEMO - %') +
    (SELECT COUNT(*) FROM bkk_lowongan WHERE posisi LIKE 'DEMO - %') +
    (SELECT COUNT(*) FROM bkk_event WHERE nama_event LIKE 'DEMO - %') +
    (SELECT COUNT(*) FROM bkk_berita WHERE slug LIKE 'demo-%')")->fetchColumn();
$filters = [
    'q' => trim($_GET['q'] ?? ''),
    'jurusan' => trim($_GET['jurusan'] ?? ''),
    'lokasi' => trim($_GET['lokasi'] ?? ''),
    'jenis' => trim($_GET['jenis'] ?? ''),
    'status' => trim($_GET['status'] ?? ''),
    'mulai' => trim($_GET['mulai'] ?? ''),
    'akhir' => trim($_GET['akhir'] ?? ''),
];
$where = ["p.status = 'Aktif'"];
$where[] = $filters['status'] === 'Ditutup'
    ? "(j.status = 'Ditutup' OR j.deadline < CURDATE())"
    : "j.status = 'Aktif' AND j.deadline >= CURDATE()";
$params = [];
if ($filters['q'] !== '') {
    $where[] = '(j.posisi LIKE ? OR p.nama LIKE ? OR j.lokasi LIKE ? OR j.jurusan LIKE ?)';
    $term = '%' . $filters['q'] . '%';
    array_push($params, $term, $term, $term, $term);
}
if (in_array($filters['jurusan'], ['RPL', 'TKJ', 'DKV', 'PSPT'], true)) {
    $where[] = 'j.jurusan LIKE ?';
    $params[] = '%' . $filters['jurusan'] . '%';
}
if ($filters['lokasi'] !== '') {
    $where[] = 'j.lokasi LIKE ?';
    $params[] = '%' . $filters['lokasi'] . '%';
}
if ($filters['jenis'] !== '') {
    $where[] = 'j.jenis_pekerjaan = ?';
    $params[] = $filters['jenis'];
}
if ($filters['mulai'] !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filters['mulai'])) {
    $where[] = 'j.deadline >= ?';
    $params[] = $filters['mulai'];
}
if ($filters['akhir'] !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filters['akhir'])) {
    $where[] = 'j.deadline <= ?';
    $params[] = $filters['akhir'];
}
if ($filters['status'] === 'Segera Berakhir') {
    $where[] = 'j.deadline <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)';
}
$whereSql = implode(' AND ', $where);
$countQuery = $pdo->prepare("SELECT COUNT(*) FROM bkk_lowongan j JOIN bkk_perusahaan p ON p.id = j.perusahaan_id WHERE $whereSql");
$countQuery->execute($params);
$totalJobs = (int) $countQuery->fetchColumn();
$perPage = 6;
$pageCount = max(1, (int) ceil($totalJobs / $perPage));
$page = min($pageCount, max(1, (int) ($_GET['page'] ?? 1)));
$offset = ($page - 1) * $perPage;
$jobsQuery = $pdo->prepare("SELECT j.*, p.nama AS perusahaan, p.logo, p.bidang_industri FROM bkk_lowongan j JOIN bkk_perusahaan p ON p.id = j.perusahaan_id WHERE $whereSql ORDER BY j.featured DESC, j.deadline ASC LIMIT $perPage OFFSET $offset");
$jobsQuery->execute($params);
$jobs = $jobsQuery->fetchAll();

$jobDetail = null;
if (!empty($_GET['job'])) {
    $detailQuery = $pdo->prepare("SELECT j.*, p.nama AS perusahaan, p.logo, p.bidang_industri, p.website FROM bkk_lowongan j JOIN bkk_perusahaan p ON p.id = j.perusahaan_id WHERE j.id = ?");
    $detailQuery->execute([(int) $_GET['job']]);
    $jobDetail = $detailQuery->fetch() ?: null;
}
$stats = [
    'jobs' => (int) $pdo->query('SELECT COUNT(*) FROM bkk_lowongan')->fetchColumn(),
    'partners' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_perusahaan WHERE status = 'Aktif'")->fetchColumn(),
    'placed' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_pelamar WHERE status = 'Bekerja'")->fetchColumn(),
    'active' => (int) $pdo->query("SELECT COUNT(*) FROM bkk_lowongan j JOIN bkk_perusahaan p ON p.id=j.perusahaan_id WHERE j.status='Aktif' AND j.deadline >= CURDATE() AND p.status='Aktif'")->fetchColumn(),
];
$partnerLimit = ($_GET['mitra'] ?? '') === 'semua' ? 100 : 6;
$partners = $pdo->query("SELECT * FROM bkk_perusahaan WHERE status = 'Aktif' ORDER BY nama LIMIT $partnerLimit")->fetchAll();
$events = $pdo->query("SELECT e.*, (SELECT COUNT(*) FROM bkk_peserta_event ep WHERE ep.event_id=e.id AND ep.status <> 'Batal') AS peserta FROM bkk_event e WHERE e.status <> 'Selesai' AND e.tanggal >= CURDATE() ORDER BY e.tanggal LIMIT 3")->fetchAll();
$news = $pdo->query("SELECT * FROM bkk_berita WHERE status='Publish' AND published_at <= NOW() ORDER BY published_at DESC LIMIT 3")->fetchAll();
$selectedArticle = null;
if (!empty($_GET['berita'])) {
    $articleQuery = $pdo->prepare("SELECT * FROM bkk_berita WHERE id = ? AND status = 'Publish' AND published_at <= NOW()");
    $articleQuery->execute([(int) $_GET['berita']]);
    $selectedArticle = $articleQuery->fetch() ?: null;
}
$applicant = null;
$myApplications = [];
$myEvents = [];
$myNotifications = [];
if ($user && in_array($user['role'], ['siswa', 'alumni'], true)) {
    $notificationQuery = $pdo->prepare('SELECT * FROM bkk_notifikasi WHERE user_id = ? ORDER BY created_at DESC LIMIT 8');
    $notificationQuery->execute([(int) $user['id']]);
    $myNotifications = $notificationQuery->fetchAll();
    $profileQuery = $pdo->prepare('SELECT * FROM bkk_pelamar WHERE user_id = ?');
    $profileQuery->execute([(int) $user['id']]);
    $applicant = $profileQuery->fetch() ?: null;
    if ($applicant) {
        $applicationsQuery = $pdo->prepare('SELECT a.*, j.posisi, j.lokasi, p.nama AS perusahaan FROM bkk_lamaran a JOIN bkk_lowongan j ON j.id=a.lowongan_id JOIN bkk_perusahaan p ON p.id=j.perusahaan_id WHERE a.pelamar_id=? ORDER BY a.tanggal_melamar DESC');
        $applicationsQuery->execute([(int) $applicant['id']]);
        $myApplications = $applicationsQuery->fetchAll();
        $eventsQuery = $pdo->prepare('SELECT e.nama_event, e.tanggal, e.lokasi, ep.status FROM bkk_peserta_event ep JOIN bkk_event e ON e.id=ep.event_id WHERE ep.pelamar_id=? ORDER BY e.tanggal DESC');
        $eventsQuery->execute([(int) $applicant['id']]);
        $myEvents = $eventsQuery->fetchAll();
    }
}
$flash = $_SESSION['bkk_flash'] ?? $flash;
unset($_SESSION['bkk_flash']);
function bkk_status_for_job(array $job): string
{
    if ($job['status'] !== 'Aktif' || $job['deadline'] < date('Y-m-d')) {
        return 'Ditutup';
    }
    return (new DateTimeImmutable($job['deadline'])) <= new DateTimeImmutable('+7 days') ? 'Segera Berakhir' : 'Aktif';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bursa Kerja Khusus | SMK Infokom Bogor</title>
<meta name="description" content="Temukan peluang kerja, agenda karier, dan mitra industri SMK Infokom Bogor.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/bkk.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility"><div class="wrap"><a href="profil.php">Tentang Kami</a><a href="ppdb.php">Pendaftaran PPDB</a><a href="portal.php">Portal Siswa dan Orang Tua</a></div></div>
<nav class="nav" id="mainNav">
    <div class="wrap nav-row">
        <a href="index.php" class="brand">
            <span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span>
            <span class="brand-text">SMK Infokom Bogor<span>Informatika dan Telekomunikasi</span></span>
        </a>
        <div class="nav-links">
            <div class="nav-item">
                <a href="profil.php" class="nav-link">Profil</a>
                <div class="mega">
                    <div class="mega-col">
                        <h5>Profil</h5>
                        <a href="profil.php">Profil dan Sejarah Sekolah</a>
                        <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
                        <a href="profil.php#struktur">Struktur Organisasi</a>
                        <a href="visi-misi.php">Visi dan Misi</a>
                        
                    </div>
                    
                </div>
            </div>
            <a href="guru.php" class="nav-link">Guru</a>
            <div class="nav-item">
                <a href="akademik.php" class="nav-link">Akademik</a>
                <div class="mega">
                    <div class="mega-col">
                        <h5>Program Keahlian</h5>
                        <a href="akademik.php">Rekayasa Perangkat Lunak</a>
                        <a href="akademik.php">Teknik Komputer dan Jaringan</a>
                        <a href="akademik.php">Desain Komunikasi Visual</a>
                        <a href="akademik.php">Produksi dan Siaran Program Televisi</a>
                    </div>
                    <div class="mega-col">
                        <h5>Penunjang</h5>
                        <a href="akademik.php">Fasilitas dan Laboratorium</a>
                        
                        
                        
                        <a href="portal-siswa-login.php">Portal Siswa</a>
                    </div>
                </div>
            </div>
            <a href="bkk.php" class="nav-link active" aria-current="page">BKK</a>
            <a href="info.php" class="nav-link">Info dan Berita</a>
            <a href="galeri.php" class="nav-link">Galeri</a>
            <a href="kontak.php" class="nav-link">Kontak</a>
        </div>
        <div class="nav-cta">
            <a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a>
            <a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a>
            
            <button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button>
        </div>
    </div>
</nav>
<div class="scrim" id="scrim"></div>
<div class="mobile-panel" id="mobilePanel">
    <button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button>
    <div class="m-group">Tentang Kami</div>
    <a href="profil.php">Profil dan Sejarah</a>
    <a href="profil.php#sambutan">Sambutan Kepala Sekolah</a>
    <a href="profil.php#struktur">Struktur Organisasi</a>
    <a href="visi-misi.php">Visi dan Misi</a>
    <a href="guru.php">Guru dan Tenaga Pendidik</a>
    <a href="siswa.php">Siswa dan Prestasi</a>
    
    <div class="m-group">Akademik</div>
    <a href="akademik.php">Program Keahlian</a>
    <a href="bkk.php" aria-current="page">Bursa Kerja Khusus (BKK)</a>
    
    
    
    <div class="m-group">Lainnya</div>
    <a href="ppdb.php">PPDB</a>
    <a href="admin-login.php">Login Admin</a>
    <a href="info.php">Info dan Berita</a>
    <a href="galeri.php">Galeri</a>
    <a href="kontak.php">Kontak</a>
</div>
<main class="bkk-page">
    <section class="bkk-hero"><div class="wrap bkk-hero-inner"><div class="bkk-hero-copy"><span class="bkk-eyebrow">Karier dimulai dari sini</span><h1>Bursa Kerja<br><span>Khusus (BKK)</span></h1><p>Temukan peluang kerja dan karier terbaik bersama BKK SMK Infokom Bogor.</p><div class="bkk-hero-actions"><a class="btn btn-gold" href="#lowongan">Lihat Lowongan <span aria-hidden="true">↗</span></a><a class="btn bkk-outline" href="#profil-pencari">Daftar Sebagai Pencari Kerja</a></div><div class="bkk-hero-note">Terhubung dengan industri. Siap melangkah ke dunia kerja.</div></div><div class="bkk-hero-art"><?php if (!empty($settings['video_url'])): ?><?= bkk_render_video_embed($settings['video_url']) ?><?php else: ?><img src="<?= site_media_html('https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1000') ?>" alt="Alumni bekerja dan berdiskusi bersama tim di perusahaan" fetchpriority="high"><?php endif; ?><div class="bkk-art-tag"><strong>Next step:</strong> kariermu</div></div></div></section>
  <section class="bkk-stats wrap" aria-label="Statistik BKK"><div><strong><?= number_format($stats['jobs']) ?></strong><span>Total lowongan</span></div><div><strong><?= number_format($stats['partners']) ?></strong><span>Perusahaan mitra</span></div><div><strong><?= number_format($stats['placed']) ?></strong><span>Alumni tersalurkan</span></div><div><strong><?= number_format($stats['active']) ?></strong><span>Lowongan aktif</span></div></section>
  <div class="wrap bkk-content">
        <?php if ($demoCount > 0): ?><div class="bkk-alert" role="note" style="border-color:#c9a227;background:#fff5d9;color:#624b0b;">Data berlabel <strong>DEMO</strong> hanya untuk pratinjau dan bukan lowongan, perusahaan, event, atau berita nyata.</div><?php endif; ?>
    <?php if ($flash): ?><div class="bkk-alert <?= h($flash['type']) ?>" role="status"><?= h($flash['text']) ?></div><?php endif; ?>
    <?php if ($jobDetail): ?>
      <section class="bkk-detail" id="detail-lowongan"><a class="bkk-back" href="bkk.php#lowongan">&larr; Semua lowongan</a><div class="bkk-detail-top"><div class="bkk-company-mark"><?php if ($jobDetail['logo']): ?><img src="<?= site_media_html($jobDetail['logo']) ?>" alt="Logo <?= h($jobDetail['perusahaan']) ?>"><?php else: ?><span><?= h(mb_substr($jobDetail['perusahaan'], 0, 1)) ?></span><?php endif; ?></div><div><span class="bkk-eyebrow"><?= h($jobDetail['bidang_industri']) ?></span><h2><?= h($jobDetail['posisi']) ?></h2><p><?= h($jobDetail['perusahaan']) ?> &middot; <?= h($jobDetail['lokasi']) ?></p></div><span class="bkk-badge <?= bkk_status_for_job($jobDetail) === 'Aktif' ? 'active' : 'soon' ?>"><?= h(bkk_status_for_job($jobDetail)) ?></span></div>
        <div class="bkk-detail-facts"><span><?= h($jobDetail['jenis_pekerjaan']) ?></span><span><?= h($jobDetail['pendidikan'] ?: 'Pendidikan sesuai posisi') ?></span><span>Deadline <?= date('d M Y', strtotime($jobDetail['deadline'])) ?></span><?php if ($jobDetail['gaji']): ?><span><?= h($jobDetail['gaji']) ?></span><?php endif; ?></div>
        <div class="bkk-detail-columns"><div><h3>Tentang pekerjaan</h3><div class="bkk-rich-text"><?= nl2br(h($jobDetail['deskripsi'])) ?></div><h3>Persyaratan</h3><div class="bkk-rich-text"><?= nl2br(h($jobDetail['persyaratan'] ?: 'Tidak ada persyaratan tambahan.')) ?></div></div><aside><h3>Ringkasan</h3><dl><dt>Jurusan</dt><dd><?= h($jobDetail['jurusan'] ?: 'Semua jurusan') ?></dd><dt>Keahlian</dt><dd><?= h($jobDetail['skill'] ?: 'Sesuai kebutuhan posisi') ?></dd><dt>Dokumen</dt><dd><?= h($jobDetail['dokumen'] ?: 'CV terbaru') ?></dd><dt>Jumlah posisi</dt><dd><?= (int) $jobDetail['jumlah_posisi'] ?> orang</dd></dl><?php if ($jobDetail['cara_melamar']): ?><p><?= nl2br(h($jobDetail['cara_melamar'])) ?></p><?php endif; ?><?php if ($jobDetail['link_pendaftaran']): ?><a class="btn btn-gold bkk-wide" href="<?= h($jobDetail['link_pendaftaran']) ?>" target="_blank" rel="noopener noreferrer">Daftar melalui perusahaan</a><?php else: ?><form method="post"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="apply"><input type="hidden" name="lowongan_id" value="<?= (int) $jobDetail['id'] ?>"><input type="hidden" name="return_to" value="bkk.php?job=<?= (int) $jobDetail['id'] ?>#detail-lowongan"><button class="btn btn-gold bkk-wide" type="submit">Daftar Sekarang</button></form><?php endif; ?></aside></div>
        <p class="bkk-security">Pastikan informasi lowongan berasal dari BKK sekolah dan jangan memberikan data pribadi di luar proses pendaftaran resmi.</p>
      </section>
    <?php endif; ?>
    <section class="bkk-section" id="lowongan"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Peluang terbaru</span><h2>Lowongan Kerja</h2></div><span class="bkk-result-count"><?= number_format($totalJobs) ?> lowongan ditemukan</span></div>
    <form class="bkk-filters" method="get" action="bkk.php#lowongan"><label class="bkk-search-field"><span class="sr-only">Cari lowongan</span><input type="search" name="q" value="<?= h($filters['q']) ?>" placeholder="Posisi, perusahaan, atau lokasi"></label><select name="jurusan" aria-label="Filter jurusan"><option value="">Semua jurusan</option><?php foreach (['RPL','TKJ','DKV','PSPT'] as $option): ?><option <?= $filters['jurusan'] === $option ? 'selected' : '' ?>><?= $option ?></option><?php endforeach; ?></select><input name="lokasi" value="<?= h($filters['lokasi']) ?>" placeholder="Lokasi" aria-label="Filter lokasi"><select name="jenis" aria-label="Filter jenis pekerjaan"><option value="">Semua jenis</option><?php foreach (['Full-time','Part-time','Kontrak','Magang','Freelance'] as $option): ?><option <?= $filters['jenis'] === $option ? 'selected' : '' ?>><?= h($option) ?></option><?php endforeach; ?></select><select name="status" aria-label="Filter status"><option value="">Semua status</option><option <?= $filters['status'] === 'Aktif' ? 'selected' : '' ?>>Aktif</option><option <?= $filters['status'] === 'Segera Berakhir' ? 'selected' : '' ?>>Segera Berakhir</option><option <?= $filters['status'] === 'Ditutup' ? 'selected' : '' ?>>Ditutup</option></select><label>Dari <input type="date" name="mulai" value="<?= h($filters['mulai']) ?>"></label><label>Sampai <input type="date" name="akhir" value="<?= h($filters['akhir']) ?>"></label><button class="btn btn-navy" type="submit">Terapkan</button><a class="bkk-reset" href="bkk.php#lowongan">Reset</a></form>
      <?php if ($jobs): ?><div class="bkk-job-grid"><?php foreach ($jobs as $job): $jobStatus = bkk_status_for_job($job); ?><article class="bkk-job-card"><div class="bkk-job-top"><div class="bkk-company-mark"><?php if ($job['logo']): ?><img src="<?= site_media_html($job['logo']) ?>" alt="Logo <?= h($job['perusahaan']) ?>"><?php else: ?><span><?= h(mb_substr($job['perusahaan'], 0, 1)) ?></span><?php endif; ?></div><span class="bkk-badge <?= $jobStatus === 'Aktif' ? 'active' : 'soon' ?>"><?= h($jobStatus) ?></span></div><?php if ($job['featured']): ?><span class="bkk-featured">Pilihan BKK</span><?php endif; ?><h3><?= h($job['posisi']) ?></h3><p class="bkk-company-name"><?= h($job['perusahaan']) ?></p><div class="bkk-job-meta"><span><?= h($job['lokasi']) ?></span><span><?= h($job['jenis_pekerjaan']) ?></span><span><?= h($job['jurusan'] ?: 'Semua jurusan') ?></span><span><?= h($job['pendidikan'] ?: 'Semua jenjang') ?></span></div><div class="bkk-job-foot"><small>Daftar sebelum <strong><?= date('d M Y', strtotime($job['deadline'])) ?></strong></small><a class="bkk-text-link" href="bkk.php?job=<?= (int) $job['id'] ?>#detail-lowongan">Lihat detail <span aria-hidden="true">&rarr;</span></a></div></article><?php endforeach; ?></div><?php else: ?><div class="bkk-empty"><strong>Belum ada lowongan yang sesuai.</strong><span>Coba ubah pencarian atau periksa kembali nanti.</span></div><?php endif; ?>
      <?php if ($pageCount > 1): ?><nav class="bkk-pagination" aria-label="Navigasi halaman lowongan"><?php for ($pageNumber = 1; $pageNumber <= $pageCount; $pageNumber++): $query = $_GET; $query['page'] = $pageNumber; ?><a class="<?= $pageNumber === $page ? 'current' : '' ?>" href="?<?= h(http_build_query($query)) ?>#lowongan" aria-current="<?= $pageNumber === $page ? 'page' : 'false' ?>"><?= $pageNumber ?></a><?php endfor; ?></nav><?php endif; ?>
    </section>
    <section class="bkk-section bkk-profile-section" id="profil-pencari"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Bersiap melamar</span><h2>Profil Pencari Kerja</h2></div><?php if ($user): ?><span class="bkk-signed-in">Masuk sebagai <?= h($user['nama']) ?></span><?php endif; ?></div>
    <?php if (!$user || !in_array($user['role'], ['siswa','alumni'], true)): ?><div class="bkk-login-prompt"><div><strong>Bangun profil kariermu.</strong><p>Masuk dengan akun Portal Siswa untuk menyimpan CV dan mengirim lamaran.</p></div><a class="btn btn-navy" href="portal-siswa-login.php?return=bkk">Masuk Portal Siswa</a></div><?php else: ?><form class="bkk-profile-form" method="post" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="profile"><div class="bkk-form-grid"><label>Nama lengkap<input value="<?= h($user['nama']) ?>" disabled></label><label>NISN<input value="<?= h($applicant['nisn'] ?? '') ?>" disabled placeholder="Terhubung dari data siswa"></label><label>Status<select disabled><option><?= $user['role'] === 'alumni' ? 'Alumni' : 'Siswa' ?></option></select></label><label>Tahun lulus<input type="number" name="tahun_lulus" min="2000" max="<?= (int) date('Y') + 2 ?>" value="<?= h((string)($applicant['tahun_lulus'] ?? '')) ?>" placeholder="Contoh: 2025"></label><label>Jurusan<select name="jurusan" required><option value="">Pilih jurusan</option><?php foreach (['RPL','TKJ','DKV','PSPT'] as $option): ?><option <?= ($applicant['jurusan'] ?? '') === $option ? 'selected' : '' ?>><?= $option ?></option><?php endforeach; ?></select></label><label>Nomor HP<input type="tel" name="no_hp" required value="<?= h($applicant['no_hp'] ?? '') ?>" autocomplete="tel"></label><label>Email<input type="email" name="email" required value="<?= h($applicant['email'] ?? '') ?>" autocomplete="email"></label><label>Domisili<input name="domisili" required value="<?= h($applicant['domisili'] ?? '') ?>" placeholder="Kota/Kabupaten"></label><label>CV (PDF/DOC/DOCX, maks. 5 MB)<input type="file" name="cv" accept=".pdf,.doc,.docx"></label><label>Sertifikat (PDF/DOC/DOCX, maks. 5 MB)<input type="file" name="sertifikat" accept=".pdf,.doc,.docx"></label><label>Portofolio (tautan)<input type="url" name="portofolio" value="<?= h($applicant['portofolio'] ?? '') ?>" placeholder="https://"></label><label>Keahlian<textarea name="skill" rows="3"><?= h($applicant['skill'] ?? '') ?></textarea></label><label class="bkk-span-two">Pengalaman kerja<textarea name="pengalaman" rows="3"><?= h($applicant['pengalaman'] ?? '') ?></textarea></label></div><button class="btn btn-gold" type="submit">Simpan Profil</button></form><?php endif; ?>
    </section>
    <?php if ($myNotifications): ?><section class="bkk-section"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Informasi akun</span><h2>Notifikasi</h2></div></div><div class="bkk-event-grid"><?php foreach ($myNotifications as $notification): ?><article class="bkk-event-card"><span><?= h($notification['dibaca'] ? 'Sudah dibaca' : 'Baru') ?> &middot; <?= date('d M Y H:i', strtotime($notification['created_at'])) ?></span><h3><?= h($notification['judul']) ?></h3><p><?= h($notification['pesan']) ?></p><?php if (!$notification['dibaca']): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="read_notification"><input type="hidden" name="notification_id" value="<?= (int)$notification['id'] ?>"><button class="bkk-text-link" type="submit">Tandai dibaca</button></form><?php endif; ?><?php if ($notification['tautan']): ?> <a class="bkk-text-link" href="<?= h($notification['tautan']) ?>">Buka &rarr;</a><?php endif; ?></article><?php endforeach; ?></div></section><?php endif; ?>
    <section class="bkk-section" id="status-lamaran"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Pantau proses</span><h2>Status Lamaran</h2></div></div><?php if (!$applicant): ?><div class="bkk-empty"><strong>Profil pencari kerja belum tersedia.</strong><span>Simpan profil terlebih dahulu untuk melihat lamaran dan riwayat proses.</span></div><?php elseif ($myApplications): ?><div class="bkk-table-scroll"><table class="bkk-table"><thead><tr><th>Posisi</th><th>Perusahaan</th><th>Tanggal</th><th>Status</th><th>Riwayat</th></tr></thead><tbody><?php foreach ($myApplications as $application): ?><tr><td><?= h($application['posisi']) ?></td><td><?= h($application['perusahaan']) ?></td><td><?= date('d M Y', strtotime($application['tanggal_melamar'])) ?></td><td><span class="bkk-status-pill"><?= h($application['status']) ?></span></td><td><details><summary>Lihat timeline</summary><?php $historyQuery=$pdo->prepare('SELECT status, catatan, tanggal FROM bkk_riwayat_lamaran WHERE lamaran_id=? ORDER BY tanggal DESC'); $historyQuery->execute([(int)$application['id']]); foreach ($historyQuery->fetchAll() as $history): ?><p class="bkk-history-item"><strong><?= h($history['status']) ?></strong><br><?= h($history['catatan'] ?: 'Pembaruan status') ?><br><small><?= date('d M Y H:i', strtotime($history['tanggal'])) ?></small></p><?php endforeach; ?></details></td></tr><?php endforeach; ?></tbody></table></div><?php else: ?><div class="bkk-empty"><strong>Belum ada lamaran.</strong><span>Lowongan yang kamu lamar akan muncul di sini.</span></div><?php endif; ?></section>
    <?php if ($myEvents): ?><section class="bkk-section"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Kegiatan karier</span><h2>Event Terdaftar</h2></div></div><div class="bkk-event-grid"><?php foreach ($myEvents as $event): ?><article class="bkk-event-card"><span><?= date('d M Y', strtotime($event['tanggal'])) ?></span><h3><?= h($event['nama_event']) ?></h3><p><?= h($event['lokasi']) ?> &middot; <?= h($event['status']) ?></p></article><?php endforeach; ?></div></section><?php endif; ?>
    <section class="bkk-section"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Jaringan industri</span><h2>Perusahaan Mitra BKK</h2></div><?php if ($partnerLimit === 6 && count($partners) === 6): ?><a class="bkk-text-link" href="bkk.php?mitra=semua#mitra">Lihat semua mitra <span aria-hidden="true">&rarr;</span></a><?php elseif ($partnerLimit > 6): ?><a class="bkk-text-link" href="bkk.php#mitra">Tampilkan mitra pilihan <span aria-hidden="true">&uarr;</span></a><?php endif; ?></div><?php if ($partners): ?><div class="bkk-partner-grid" id="mitra"><?php foreach ($partners as $partner): ?><article class="bkk-partner-card"><div class="bkk-company-mark"><?php if ($partner['logo']): ?><img src="<?= site_media_html($partner['logo']) ?>" alt="Logo <?= h($partner['nama']) ?>"><?php else: ?><span><?= h(mb_substr($partner['nama'],0,1)) ?></span><?php endif; ?></div><div><h3><?= h($partner['nama']) ?></h3><span><?= h($partner['bidang_industri']) ?> &middot; <?= h($partner['kota']) ?></span><p><?= h(mb_strimwidth($partner['deskripsi'] ?? '',0,110,'...')) ?></p></div></article><?php endforeach; ?></div><?php else: ?><div class="bkk-empty"><strong>Mitra BKK segera hadir.</strong><span>Informasi mitra akan ditampilkan setelah dikelola oleh admin BKK.</span></div><?php endif; ?></section>
    <section class="bkk-section"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Agenda karier</span><h2>Agenda &amp; Event</h2></div></div><?php if ($events): ?><div class="bkk-event-grid"><?php foreach ($events as $event): ?><article class="bkk-event-card"><?php if ($event['poster']): ?><img src="<?= site_media_html($event['poster']) ?>" alt="Poster <?= h($event['nama_event']) ?>" loading="lazy" style="display:block;width:100%;height:126px;object-fit:cover;margin:0 0 12px"><?php endif; ?><span><?= date('d M Y', strtotime($event['tanggal'])) ?><?= $event['waktu'] ? ' &middot; ' . h($event['waktu']) : '' ?></span><h3><?= h($event['nama_event']) ?></h3><p><?= h($event['lokasi']) ?> &middot; <?= h($event['status']) ?></p><?php if ($event['deskripsi']): ?><p><?= h($event['deskripsi']) ?></p><?php endif; ?><?php if ($user && $applicant): ?><form method="post"><input type="hidden" name="csrf_token" value="<?= h(bkk_csrf_token()) ?>"><input type="hidden" name="action" value="event"><input type="hidden" name="event_id" value="<?= (int)$event['id'] ?>"><button type="submit" class="bkk-text-link">Daftar event &rarr;</button></form><?php elseif ($event['link_pendaftaran']): ?><a class="bkk-text-link" href="<?= h($event['link_pendaftaran']) ?>" target="_blank" rel="noopener noreferrer">Detail / daftar &rarr;</a><?php endif; ?><small><?= (int)$event['peserta'] ?><?= $event['kuota'] ? ' / ' . (int)$event['kuota'] : '' ?> peserta</small></article><?php endforeach; ?></div><?php else: ?><div class="bkk-empty"><strong>Belum ada agenda mendatang.</strong><span>Pantau halaman ini untuk agenda karier terbaru.</span></div><?php endif; ?></section>
    <section class="bkk-section" id="berita"><div class="bkk-section-heading"><div><span class="bkk-eyebrow">Cerita dan wawasan</span><h2>Berita BKK</h2></div></div><?php if ($selectedArticle): ?><article class="bkk-detail bkk-article-detail"><?php if ($selectedArticle['thumbnail']): ?><img src="<?= site_media_html($selectedArticle['thumbnail']) ?>" alt="" loading="lazy"><?php endif; ?><span class="bkk-eyebrow"><?= h($selectedArticle['kategori']) ?> &middot; <?= date('d M Y', strtotime($selectedArticle['published_at'])) ?></span><h2><?= h($selectedArticle['judul']) ?></h2><p class="bkk-article-byline">Ditulis oleh <?= h($selectedArticle['penulis']) ?></p><div class="bkk-rich-text"><?= nl2br(h($selectedArticle['isi'])) ?></div></article><?php endif; ?><?php if ($news): ?><div class="bkk-news-grid"><?php foreach ($news as $article): ?><article class="bkk-news-card"><?php if ($article['thumbnail']): ?><img src="<?= site_media_html($article['thumbnail']) ?>" alt="" loading="lazy"><?php endif; ?><div><span><?= h($article['kategori']) ?> &middot; <?= date('d M Y', strtotime($article['published_at'])) ?></span><h3><?= h($article['judul']) ?></h3><p><?= h(mb_strimwidth(strip_tags($article['isi']),0,150,'...')) ?></p><a class="bkk-text-link" href="bkk.php?berita=<?= (int)$article['id'] ?>#berita">Baca selengkapnya &rarr;</a></div></article><?php endforeach; ?></div><?php else: ?><div class="bkk-empty"><strong>Belum ada berita BKK.</strong><span>Informasi terbaru akan muncul setelah dipublikasikan.</span></div><?php endif; ?></section>
  </div>
</main>
<footer class="bkk-footer"><div class="wrap"><a href="index.php">SMK Infokom Bogor</a><span><?= h($settings['nama_bkk']) ?> &middot; Bogor</span><a href="kontak.php">Hubungi sekolah</a></div></footer>
<script src="assets/main.js"></script>
</body>
</html>
