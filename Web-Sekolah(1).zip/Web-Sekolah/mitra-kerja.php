<?php
require_once __DIR__ . '/includes/media.php';
require_once __DIR__ . '/includes/page_media.php';
function h(?string $value): string
{
  return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}
$mitraMedia = page_media_items('mitra_kerja');
$mitra = [
    ['logo' => 'assets/kerja sama universitas/djuanda.png', 'nama' => 'Universitas Djuanda Bogor', 'kategori' => 'Universitas', 'deskripsi' => 'Kolaborasi pendidikan tinggi dapat membantu siswa mengenal pilihan studi, lingkungan kampus, dan peluang pengembangan diri setelah lulus.'],
    ['logo' => 'assets/kerja sama universitas/ibn.png', 'nama' => 'Universitas Ibn Khaldun Bogor', 'kategori' => 'Universitas', 'deskripsi' => 'Kemitraan dengan perguruan tinggi memperluas wawasan siswa tentang pendidikan lanjutan dan mendorong kesiapan mereka merencanakan masa depan.'],
    ['logo' => 'assets/kerja sama universitas/ipb.png', 'nama' => 'Institut Pertanian Bogor', 'kategori' => 'Perguruan Tinggi', 'deskripsi' => 'Interaksi dengan lingkungan akademik memberi siswa kesempatan mengenal kegiatan kampus, ilmu terapan, serta beragam jalur pendidikan tinggi.'],
    ['logo' => 'assets/kerja sama universitas/pakuan.png', 'nama' => 'Universitas Pakuan', 'kategori' => 'Universitas', 'deskripsi' => 'Sinergi sekolah dan universitas mendukung pengenalan program studi serta membantu siswa mempersiapkan pilihan pendidikan yang sesuai minat.'],
    ['logo' => 'assets/kerja sama universitas/pliteknik.png', 'nama' => 'Politeknik Negeri Jakarta', 'kategori' => 'Politeknik', 'deskripsi' => 'Pengenalan pendidikan vokasi membantu siswa memahami pembelajaran berbasis praktik dan peluang melanjutkan ke jenjang perguruan tinggi vokasi.'],
];
$bidang = [
    ['icon' => 'briefcase', 'judul' => 'Praktik Kerja Lapangan', 'deskripsi' => 'Menghubungkan pembelajaran kelas dengan pengalaman kerja yang terarah.'],
    ['icon' => 'users', 'judul' => 'Magang Siswa', 'deskripsi' => 'Memberi ruang bagi siswa untuk belajar langsung dari lingkungan profesional.'],
    ['icon' => 'building', 'judul' => 'Kunjungan Industri', 'deskripsi' => 'Mengenalkan proses kerja, budaya industri, dan peluang karier masa depan.'],
    ['icon' => 'presentation', 'judul' => 'Guru Tamu', 'deskripsi' => 'Menghadirkan praktisi untuk berbagi pengalaman dan wawasan terkini.'],
    ['icon' => 'tools', 'judul' => 'Pelatihan & Workshop', 'deskripsi' => 'Memperkuat keterampilan teknis dan soft skill sesuai kebutuhan industri.'],
    ['icon' => 'certificate', 'judul' => 'Sertifikasi Kompetensi', 'deskripsi' => 'Mendorong pengakuan kompetensi siswa melalui program yang relevan.'],
    ['icon' => 'target', 'judul' => 'Rekrutmen Lulusan', 'deskripsi' => 'Membuka akses informasi kerja dan pengembangan karier bagi lulusan.'],
    ['icon' => 'book', 'judul' => 'Pengembangan Kurikulum', 'deskripsi' => 'Menyelaraskan pembelajaran dengan perubahan teknologi dan dunia kerja.'],
];
function mitraIcon(string $type): string {
    $paths = [
        'briefcase' => '<rect x="4" y="7" width="16" height="12" rx="2"/><path d="M9 7V5h6v2M4 12h16M10 12v2h4v-2"/>',
        'users' => '<circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.5 2.7-6 6-6s6 2.5 6 6M16 11c2.8.2 5 2 5 5"/>',
        'building' => '<path d="M4 20V5l8-2 8 2v15M2 20h20M8 8h1m6 0h1M8 12h1m6 0h1M8 16h1m6 0h1"/>',
        'presentation' => '<rect x="3" y="4" width="18" height="12" rx="1"/><path d="M8 20h8M12 16v4M7 9l3 3 6-5"/>',
        'tools' => '<path d="m14 6 4 4M4 20l9-9 3 3-9 9H4v-3ZM15 4a4 4 0 0 0 5 5l-3 3-5-5 3-3Z"/>',
        'certificate' => '<circle cx="12" cy="10" r="6"/><path d="m9 16-1 5 4-2 4 2-1-5M9 10l2 2 4-4"/>',
        'target' => '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
        'book' => '<path d="M4 5a2 2 0 0 1 2-2h5v17H6a2 2 0 0 0-2 2V5ZM20 5a2 2 0 0 0-2-2h-5v17h5a2 2 0 0 1 2 2V5Z"/>',
    ];
    return '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true">' . ($paths[$type] ?? $paths['briefcase']) . '</svg>';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mitra Kerja | SMK Infokom Bogor</title>
<meta name="description" content="Mitra kerja sama pendidikan SMK Infokom Bogor dengan perguruan tinggi di Bogor dan Jakarta.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Libre+Franklin:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="page-transition" id="pageTransition"></div><div class="scroll-progress" id="scrollProgress"></div>
<div class="utility"><div class="wrap"><a href="profil.php">Kunjungi Kami</a><a href="ppdb.php">Daftar PPDB</a><a href="portal.php">Portal Siswa &amp; Orang Tua</a></div></div>
<nav class="nav" id="mainNav"><div class="wrap nav-row">
  <a href="index.php" class="brand"><span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span><span class="brand-text">SMK Infokom Bogor<span>Informatika &amp; Telekomunikasi</span></span></a>
  <div class="nav-links">
    <div class="nav-item"><a href="profil.php" class="nav-link">Profil</a><div class="mega"><div class="mega-col"><h5>Profil</h5><a href="profil.php">Profil &amp; Sejarah Sekolah</a><a href="profil.php#sambutan">Sambutan Kepala Sekolah</a><a href="profil.php#struktur">Struktur Organisasi</a><a href="visi-misi.php">Visi &amp; Misi</a></div></div></div>
    <div class="nav-item"><a href="akademik.php" class="nav-link">Akademik</a><div class="mega"><div class="mega-col"><h5>Program Keahlian</h5><a href="akademik.php">Rekayasa Perangkat Lunak</a><a href="akademik.php">Teknik Komputer &amp; Jaringan</a><a href="akademik.php">DKV (Desain Komunikasi Visual)</a><a href="akademik.php">PSPT</a></div><div class="mega-col"><h5>Penunjang</h5><a href="akademik.php">Fasilitas &amp; Laboratorium</a><a href="portal-siswa-login.php">Portal Siswa</a></div></div></div>
    <a href="bkk.php" class="nav-link">BKK</a><a href="info.php" class="nav-link">Info &amp; Berita</a><a href="galeri.php" class="nav-link">Galeri</a><a href="kontak.php" class="nav-link">Kontak</a>
  </div>
  <div class="nav-cta"><a href="admin-login.php" title="Login Admin" class="admin-icon-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="3.5" stroke="currentColor" stroke-width="1.7"/><path d="M5 20c0-3.5 3-6.5 7-6.5s7 3 7 6.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg></a><a href="portal.php" class="btn btn-line" style="padding:11px 20px;">Portal Login</a>
      <a href="ppdb.php" class="btn btn-gold" style="padding:11px 22px;">Daftar Sekarang</a><button class="burger" id="burger" aria-label="Buka menu"><span></span><span></span><span></span></button></div>
</div></nav>
<div class="scrim" id="scrim"></div><div class="mobile-panel" id="mobilePanel"><button class="mobile-close" id="mobileClose" aria-label="Tutup menu"><span></span><span></span></button><div class="m-group">Tentang Kami</div><a href="profil.php">Profil &amp; Sejarah</a><a href="profil.php#sambutan">Sambutan Kepala Sekolah</a><a href="profil.php#struktur">Struktur Organisasi</a><a href="visi-misi.php">Visi &amp; Misi</a><a href="guru.php">Guru &amp; Tenaga Pendidik</a><div class="m-group">Akademik</div><a href="akademik.php">Program Keahlian</a><a href="bkk.php">Bursa Kerja Khusus (BKK)</a><div class="m-group">Lainnya</div><a href="ppdb.php">PPDB</a><a href="admin-login.php">Login Admin</a><a href="info.php">Info &amp; Berita</a><a href="galeri.php">Galeri</a><a href="kontak.php">Kontak</a></div>

<header class="mitra-hero"><div class="wrap mitra-hero-grid"><div><div class="crumb"><a href="index.php">Beranda</a> / Mitra Kerja</div><div class="eyebrow">Kolaborasi Sekolah &amp; Perguruan Tinggi</div><h1 class="split">Mitra Kerja Sama Pendidikan</h1><p>Bersama perguruan tinggi, membuka wawasan siswa tentang pilihan studi dan mempersiapkan langkah menuju masa depan.</p></div><div class="mitra-hero-art" role="img" aria-label="Ilustrasi kolaborasi sekolah dan perguruan tinggi"><div class="hero-art-card"><span class="hero-art-mark">SMK</span><strong>Belajar. Berkarya.<br>Bersiap untuk masa depan.</strong><small>Kolaborasi sekolah dan perguruan tinggi</small></div><div class="hero-art-line"></div><div class="hero-art-node node-one"></div><div class="hero-art-node node-two"></div></div></div></header>

<section class="mitra-intro"><div class="wrap"><div class="mitra-intro-head reveal"><div><div class="eyebrow">Kolaborasi pendidikan</div><h2 class="split">Membuka Wawasan, Menyiapkan Masa Depan</h2></div><p>Kerja sama dengan perguruan tinggi membantu siswa mengenal pilihan pendidikan lanjutan, suasana akademik, dan pembelajaran vokasi. Informasi ini dapat menjadi bekal untuk merencanakan studi serta mengembangkan kompetensi setelah lulus.</p></div><div class="mitra-benefits" data-stagger><?php foreach (['Mengenal Pilihan Kampus', 'Informasi Studi Lanjutan', 'Wawasan Pembelajaran Vokasi', 'Perencanaan Masa Depan'] as $i => $benefit): ?><div class="mitra-benefit"><span><?= str_pad((string)($i + 1), 2, '0', STR_PAD_LEFT) ?></span><strong><?= h($benefit) ?></strong><p><?= ['Mengenal perguruan tinggi dan lingkungan belajar yang dapat menjadi tujuan setelah lulus.', 'Memperluas pengetahuan tentang program studi dan jalur masuk pendidikan tinggi.', 'Memahami pembelajaran terapan yang menggabungkan teori dan praktik.', 'Membantu siswa mempertimbangkan pilihan studi sesuai minat dan rencana karier.'][$i] ?></p></div><?php endforeach; ?></div></div></section>

<section class="mitra-list-section"><div class="wrap"><div class="section-head reveal"><div><div class="eyebrow">Jaringan perguruan tinggi</div><h2 class="split">Mitra Kerja Sama Pendidikan</h2></div><p class="mitra-note">Logo dan nama perguruan tinggi berikut ditampilkan sesuai materi yang tersedia. Kolaborasi pendidikan memperkenalkan siswa pada pilihan studi dan lingkungan kampus.</p></div><div class="mitra-grid" data-stagger><?php foreach ($mitra as $item): ?><article class="mitra-card"><div class="mitra-logo"><img src="<?= site_media_html($item['logo']) ?>" alt="Logo <?= h($item['nama']) ?>" loading="lazy"></div><div class="mitra-card-body"><span><?= h($item['kategori']) ?></span><h3><?= h($item['nama']) ?></h3><p><?= h($item['deskripsi']) ?></p><a href="#kerja-sama" class="mitra-card-link">Lihat bidang kolaborasi <b>→</b></a></div></article><?php endforeach; ?></div></div></section>
<?php if ($mitraMedia): ?>
<section class="mitra-list-section" style="padding-top:0;">
  <div class="wrap">
    <div class="section-head reveal"><div><div class="eyebrow">Dokumentasi mitra</div><h2 class="split">Foto Mitra Kerja Sama</h2></div></div>
    <div class="kunjungan-gallery reveal" data-stagger>
      <?php foreach ($mitraMedia as $item): ?>
        <figure class="page-media-card"><img src="<?= site_media_html($item['image_path']) ?>" alt="<?= h($item['title']) ?>" loading="lazy"><figcaption><?= h($item['title']) ?></figcaption></figure>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<section class="mitra-collab" id="kerja-sama"><div class="wrap"><div class="section-head reveal"><div><div class="eyebrow">Ruang kolaborasi</div><h2 class="split">Bidang Kerja Sama</h2></div><p>Kolaborasi dapat disesuaikan dengan kebutuhan sekolah, kompetensi siswa, dan kapasitas mitra.</p></div><div class="collab-grid" data-stagger><?php foreach ($bidang as $item): ?><article class="collab-card"><div class="collab-icon"><?= mitraIcon($item['icon']) ?></div><h3><?= h($item['judul']) ?></h3><p><?= h($item['deskripsi']) ?></p></article><?php endforeach; ?></div></div></section>

<section class="mitra-cta"><div class="wrap mitra-cta-inner reveal"><div><div class="eyebrow">Mari terhubung</div><h2 class="split">Bangun Kolaborasi Pendidikan</h2><p>Sekolah terbuka untuk menjalin kerja sama dengan perguruan tinggi dalam mendukung wawasan, kompetensi, dan rencana studi siswa.</p></div><div class="mitra-cta-actions"><a href="kontak.php" class="btn btn-gold">Ajukan Kerja Sama <svg width="16" height="16" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a><a href="kontak.php" class="btn btn-line">Hubungi Kami</a></div></div></section>

<footer class="footer"><div class="wrap"><div class="foot-top"><div class="foot-logo"><div class="brand"><span class="brand-mark"><img src="<?= site_media_html('assets/img/logo-infokom.png') ?>" alt="Logo SMK Infokom Bogor"></span><span class="brand-text" style="color:var(--white);">SMK Infokom Bogor<span style="color:#9FB0C3;">Informatika &amp; Telekomunikasi</span></span></div><p>Jl. Letjen Ibrahim Adjie No.178, RT.03/RW.08,<br>Kelurahan Sindangbarang, Kecamatan Bogor Barat,<br>Kota Bogor, Jawa Barat 16117</p><p>(0251) 837-2210</p></div><a href="kontak.php" class="btn btn-line" style="padding:12px 22px;">Kontak Kami <svg width="15" height="15" viewBox="0 0 16 16"><path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></a></div><div class="foot-cols"><div class="foot-col"><h5>Komunitas</h5><ul><li><a href="guru.php">Guru &amp; Staf</a></li></ul></div><div class="foot-col"><h5>Informasi</h5><ul><li><a href="info.php">Berita &amp; Kabar</a></li><li><a href="info-darurat.php">Info Darurat</a></li></ul></div><div class="foot-col"><h5>Akses Cepat</h5><ul><li><a href="portal-siswa-login.php">Portal Siswa</a></li><li><a href="ppdb.php">PPDB</a></li><li><a href="akademik.php">SMk Maps</a></li></ul></div></div><div class="foot-sub"><div class="foot-social"><a href="https://www.instagram.com/smk.infokom_official?utm_source=ig_web_button_share_sheet&cplk=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener" aria-label="Instagram"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="#B9C4D2" stroke-width="1.5"/><circle cx="12" cy="12" r="4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a><a href="https://youtube.com/@smkinfokomkotabogor?si=GxolHsWwt81JXlZ2" target="_blank" rel="noopener" aria-label="YouTube"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="2" y="5" width="20" height="14" rx="4" stroke="#B9C4D2" stroke-width="1.5"/><path d="M10 9l6 3-6 3V9z" fill="#B9C4D2"/></svg></a><a href="https://www.tiktok.com/@sekolahpusatkeunggulan?is_from_webapp=1&sender_device=pc" target="_blank" rel="noopener" aria-label="TikTok"><svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.5a3.5 3.5 0 11-3-3.46" stroke="#B9C4D2" stroke-width="1.5"/><path d="M14 3c.4 2.2 2 3.8 4 4" stroke="#B9C4D2" stroke-width="1.5"/></svg></a></div><a href="#top" style="font-size:13px;font-weight:600;color:#B9C4D2;">Kembali ke Atas ↑</a></div><div class="foot-bottom"><span>&copy; 2026 SMK Infokom Bogor.</span><div class="legal"><a href="privasi.php">Kebijakan Privasi</a><a href="ketentuan.php">Ketentuan Layanan</a></div></div></div></footer>
<script src="assets/main.js"></script>
</body>
</html>
